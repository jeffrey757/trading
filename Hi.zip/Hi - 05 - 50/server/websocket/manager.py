import logging
from typing import Dict, Set
from fastapi import WebSocket

logger = logging.getLogger("ws-manager")


class ConnectionManager:
    def __init__(self):
        # all connections
        self.active_connections: Set[WebSocket] = set()

        # user_id -> set of websockets
        self.user_subscriptions: Dict[int, Set[WebSocket]] = {}

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.add(websocket)
        logger.info("WS connected. Total clients: %d", len(self.active_connections))

    def disconnect(self, websocket: WebSocket):
        self.active_connections.discard(websocket)

        # remove from any user subscriptions
        for user_id, conns in list(self.user_subscriptions.items()):
            if websocket in conns:
                conns.remove(websocket)
                if not conns:
                    del self.user_subscriptions[user_id]

        logger.info("WS disconnected. Total clients: %d", len(self.active_connections))

    async def subscribe_user(self, websocket: WebSocket, user_id: int):
        if user_id not in self.user_subscriptions:
            self.user_subscriptions[user_id] = set()
        self.user_subscriptions[user_id].add(websocket)

    async def send_personal(self, user_id: int, message: dict):
        conns = self.user_subscriptions.get(user_id, set())
        for ws in list(conns):
            try:
                await ws.send_json(message)
            except Exception:
                self.disconnect(ws)

    async def broadcast(self, message: dict):
        for ws in list(self.active_connections):
            try:
                await ws.send_json(message)
            except Exception:
                self.disconnect(ws)


manager = ConnectionManager()