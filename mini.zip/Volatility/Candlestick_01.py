# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:50:56 2026

@author: Administrator
"""

"""
ADVANCED CANDLESTICK GUI (Tkinter) with:
1) Candlestick chart + pattern highlighting (Doji, Hammer)
2) Timeframe dropdown (Daily / Weekly)
3) Second panel: Predicted vs Realized Volatility (below candles)
   - Realized volatility proxy: sqrt(RV) = |r_t| (in percent) or rolling std
   - Predicted volatility: simple baseline forecast (rolling variance forecast)
     (You can later swap this with GARCH/XGB/LSTM predictions)

Install:
  pip install pandas numpy matplotlib mplfinance scikit-learn

Run:
  python candle_gui_patterns_vol.py

Data:
- Stooq (online) default: spy.us (S&P 500 ETF proxy)
- Or CSV with Date, Open, High, Low, Close (Volume optional)

Notes:
- This uses mplfinance for candles + matplotlib for the extra volatility panel.
- Pattern markers:
    Doji  -> marker 'o' at close
    Hammer -> marker '^' at low (bullish hammer)
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

import mplfinance as mpf
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor


# ============================================================
# 1) Data loading (Stooq / CSV)
# ============================================================
def load_from_stooq(symbol: str) -> pd.DataFrame:
    url = f"https://stooq.com/q/d/l/?s={symbol}&i=d"
    df = pd.read_csv(url)
    needed = {"Date", "Open", "High", "Low", "Close"}
    if not needed.issubset(set(df.columns)):
        raise ValueError(f"Stooq missing required OHLC columns. Got: {list(df.columns)}")

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date").reset_index(drop=True)

    for c in ["Open", "High", "Low", "Close", "Volume"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["Open", "High", "Low", "Close"]).copy()
    df = df.set_index("Date")
    return df


def load_from_csv(path: str) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        raise ValueError("CSV file not found.")

    df = pd.read_csv(p)
    colmap = {c.lower().strip(): c for c in df.columns}
    req = ["date", "open", "high", "low", "close"]
    for r in req:
        if r not in colmap:
            raise ValueError(f"CSV must contain Date,Open,High,Low,Close. Found: {list(df.columns)}")

    rename = {
        colmap["date"]: "Date",
        colmap["open"]: "Open",
        colmap["high"]: "High",
        colmap["low"]: "Low",
        colmap["close"]: "Close",
    }
    if "volume" in colmap:
        rename[colmap["volume"]] = "Volume"

    df = df.rename(columns=rename)
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date").reset_index(drop=True)

    for c in ["Open", "High", "Low", "Close", "Volume"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["Open", "High", "Low", "Close"]).copy()
    df = df.set_index("Date")
    return df


# ============================================================
# 2) Timeframe transform (Daily / Weekly)
# ============================================================
def to_timeframe(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    """
    Convert daily OHLC into weekly OHLC if requested.
    """
    if timeframe == "Daily":
        return df.copy()

    # Weekly OHLC aggregation
    # Open = first, High = max, Low = min, Close = last, Volume = sum (if exists)
    agg = {
        "Open": "first",
        "High": "max",
        "Low": "min",
        "Close": "last",
    }
    if "Volume" in df.columns:
        agg["Volume"] = "sum"

    w = df.resample("W-FRI").agg(agg).dropna()
    return w


# ============================================================
# 3) Candlestick pattern detection (simple academic definitions)
# ============================================================
def detect_doji(df: pd.DataFrame, body_ratio_threshold=0.10) -> pd.Series:
    """
    Doji: small body compared to total range.
    body = |Close - Open|
    range = High - Low
    Doji if body <= threshold * range
    """
    body = (df["Close"] - df["Open"]).abs()
    rng = (df["High"] - df["Low"]).replace(0, np.nan)
    doji = (body <= body_ratio_threshold * rng).fillna(False)
    return doji


def detect_hammer(df: pd.DataFrame,
                  body_to_range_max=0.35,
                  lower_shadow_min_body=2.0,
                  upper_shadow_max_body=0.5) -> pd.Series:
    """
    Bullish hammer (simple rule-based):
    - small-ish body relative to range
    - long lower shadow (>= 2 * body)
    - small upper shadow (<= 0.5 * body)

    Definitions:
    body = |C - O|
    upper shadow = High - max(O,C)
    lower shadow = min(O,C) - Low
    """
    o = df["Open"]
    c = df["Close"]
    h = df["High"]
    l = df["Low"]

    body = (c - o).abs()
    rng = (h - l).replace(0, np.nan)

    upper = h - np.maximum(o, c)
    lower = np.minimum(o, c) - l

    cond1 = (body / rng <= body_to_range_max)
    # Avoid division by zero: require body > 0
    cond2 = (body > 0) & (lower >= lower_shadow_min_body * body)
    cond3 = (body > 0) & (upper <= upper_shadow_max_body * body)

    return (cond1 & cond2 & cond3).fillna(False)


# ============================================================
# 4) Volatility series + a simple "predicted volatility"
# ============================================================
def build_volatility_series(df: pd.DataFrame) -> pd.DataFrame:
    """
    Realized volatility (daily/weekly):
    - returns in percent: r_t = 100*ln(C_t/C_{t-1})
    - realized variance proxy: RV_t = r_t^2
    - realized vol: sqrt(RV) = |r_t|  (percent)
    Predicted volatility:
    - rolling forecast: sqrt(mean(RV_{t-k...t-1}))  (k=20)
    """
    d = df.copy()
    d["r_pct"] = 100 * np.log(d["Close"] / d["Close"].shift(1))
    d["RV"] = d["r_pct"] ** 2
    d["RealizedVol_pct"] = np.sqrt(np.clip(d["RV"], 0, None))

    k = 20
    d["PredVol_pct"] = np.sqrt(np.clip(d["RV"].rolling(k).mean().shift(1), 0, None))
    return d


# ============================================================
# 5) GUI
# ============================================================
class CandlePatternVolGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Candlestick GUI: Pattern Highlight + Timeframe + Vol Panel")
        self.geometry("1260x860")

        # Inputs
        self.source = tk.StringVar(value="Stooq")
        self.symbol = tk.StringVar(value="spy.us")
        self.csv_path = tk.StringVar(value="")

        self.timeframe = tk.StringVar(value="Daily")   # Daily / Weekly
        self.style = tk.StringVar(value="yahoo")
        self.show_volume = tk.BooleanVar(value=True)

        # Pattern toggles
        self.show_doji = tk.BooleanVar(value=True)
        self.show_hammer = tk.BooleanVar(value=True)

        # Vol panel toggle
        self.show_vol_panel = tk.BooleanVar(value=True)

        # Data
        self.df_raw = None
        self.df_tf = None

        # Matplotlib objects
        self.fig = None
        self.canvas = None
        self.toolbar = None

        self._build_ui()

    def _build_ui(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")

        ttk.Label(top, text="Source:").grid(row=0, column=0, sticky="w")
        src = ttk.Combobox(top, textvariable=self.source, values=["Stooq", "CSV"], width=10, state="readonly")
        src.grid(row=0, column=1, sticky="w", padx=6)
        src.bind("<<ComboboxSelected>>", lambda e: self._toggle_source())

        ttk.Label(top, text="Stooq Symbol:").grid(row=0, column=2, sticky="w")
        ttk.Entry(top, textvariable=self.symbol, width=12).grid(row=0, column=3, sticky="w", padx=6)

        ttk.Label(top, text="CSV Path:").grid(row=0, column=4, sticky="w")
        self.csv_entry = ttk.Entry(top, textvariable=self.csv_path, width=46)
        self.csv_entry.grid(row=0, column=5, sticky="w", padx=6)
        ttk.Button(top, text="Browse", command=self._browse).grid(row=0, column=6, sticky="w")

        ttk.Label(top, text="Timeframe:").grid(row=1, column=0, sticky="w", pady=(8, 0))
        tf_cb = ttk.Combobox(top, textvariable=self.timeframe, values=["Daily", "Weekly"], width=10, state="readonly")
        tf_cb.grid(row=1, column=1, sticky="w", padx=6, pady=(8, 0))

        ttk.Label(top, text="Style:").grid(row=1, column=2, sticky="w", pady=(8, 0))
        ttk.Combobox(top, textvariable=self.style, values=["yahoo", "charles", "binance", "classic"], width=12, state="readonly")\
            .grid(row=1, column=3, sticky="w", padx=6, pady=(8, 0))

        ttk.Checkbutton(top, text="Show Volume", variable=self.show_volume).grid(row=1, column=4, sticky="w", pady=(8, 0))
        ttk.Checkbutton(top, text="Vol panel", variable=self.show_vol_panel).grid(row=1, column=5, sticky="w", pady=(8, 0))

        pat = ttk.Frame(self, padding=(10, 0, 10, 10))
        pat.pack(fill="x")
        ttk.Label(pat, text="Pattern Highlight:").pack(side="left")
        ttk.Checkbutton(pat, text="Doji", variable=self.show_doji).pack(side="left", padx=8)
        ttk.Checkbutton(pat, text="Hammer", variable=self.show_hammer).pack(side="left", padx=8)

        ttk.Button(pat, text="Load Data", command=self._load).pack(side="left", padx=12)
        ttk.Button(pat, text="Draw Chart", command=self._draw).pack(side="left")

        self.status = tk.StringVar(value="Ready.")
        ttk.Label(pat, textvariable=self.status).pack(side="right")

        # Plot area
        self.plot_frame = ttk.Frame(self, padding=10)
        self.plot_frame.pack(fill="both", expand=True)

        self._toggle_source()

    def _toggle_source(self):
        is_csv = (self.source.get() == "CSV")
        self.csv_entry.configure(state="normal" if is_csv else "disabled")

    def _browse(self):
        path = filedialog.askopenfilename(
            title="Select OHLC CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if path:
            self.csv_path.set(path)
            self.source.set("CSV")
            self._toggle_source()

    def _clear_plot(self):
        if self.toolbar:
            self.toolbar.destroy()
            self.toolbar = None
        if self.canvas:
            self.canvas.get_tk_widget().destroy()
            self.canvas = None
        self.fig = None

    def _load(self):
        try:
            self.status.set("Loading data...")
            self.update_idletasks()

            if self.source.get() == "Stooq":
                sym = self.symbol.get().strip()
                if not sym:
                    raise ValueError("Stooq symbol is empty.")
                df = load_from_stooq(sym)
            else:
                path = self.csv_path.get().strip()
                if not path:
                    raise ValueError("CSV path is empty.")
                df = load_from_csv(path)

            if df.empty:
                raise ValueError("Loaded data is empty.")

            self.df_raw = df
            self.status.set(f"Loaded {len(df)} rows.")
            messagebox.showinfo("Loaded", f"Loaded {len(df)} rows successfully.")
        except Exception as e:
            self.status.set("Error loading.")
            messagebox.showerror("Error", str(e))

    def _draw(self):
        try:
            if self.df_raw is None or self.df_raw.empty:
                raise ValueError("No data loaded. Click 'Load Data' first.")

            self.status.set("Preparing chart...")
            self.update_idletasks()

            # Timeframe conversion
            df_tf = to_timeframe(self.df_raw, self.timeframe.get())
            if df_tf.empty:
                raise ValueError("No data after timeframe conversion.")
            self.df_tf = df_tf

            # Pattern detection
            doji = detect_doji(df_tf) if self.show_doji.get() else pd.Series(False, index=df_tf.index)
            hammer = detect_hammer(df_tf) if self.show_hammer.get() else pd.Series(False, index=df_tf.index)

            # Volatility series
            vol_df = build_volatility_series(df_tf)

            self._clear_plot()

            # Figure layout: 2 panels if vol_panel enabled, else 1 panel
            if self.show_vol_panel.get():
                self.fig = plt.figure(figsize=(12, 7))
                gs = self.fig.add_gridspec(2, 1, height_ratios=[3, 1], hspace=0.05)
                ax_price = self.fig.add_subplot(gs[0, 0])
                ax_vol = self.fig.add_subplot(gs[1, 0], sharex=ax_price)
            else:
                self.fig = plt.figure(figsize=(12, 7))
                ax_price = self.fig.add_subplot(1, 1, 1)
                ax_vol = None

            # Draw candlesticks on ax_price using mplfinance
            # (Using mpf.plot with external axes)
            addplots = []

            # Pattern markers plotted as scatter via mpf.make_addplot
            # Doji: marker at Close
            if self.show_doji.get():
                doji_y = df_tf["Close"].where(doji, np.nan)
                addplots.append(mpf.make_addplot(doji_y, ax=ax_price, type="scatter", markersize=50, marker="o"))

            # Hammer: marker at Low
            if self.show_hammer.get():
                hammer_y = df_tf["Low"].where(hammer, np.nan)
                addplots.append(mpf.make_addplot(hammer_y, ax=ax_price, type="scatter", markersize=70, marker="^"))

            # MA for context (optional)
            mav = (20, 50) if len(df_tf) > 60 else (20,)

            # Volume handling:
            volume_ax = None
            use_volume = self.show_volume.get() and ("Volume" in df_tf.columns)
            # If vol panel exists, we cannot also show mplfinance volume subplot easily.
            # So: show volume only when vol panel is OFF.
            if use_volume and not self.show_vol_panel.get():
                volume_ax = True  # mplfinance will create its own volume axes
            else:
                volume_ax = False

            mpf.plot(
                df_tf,
                type="candle",
                ax=ax_price,
                addplot=addplots if addplots else None,
                style=self.style.get(),
                mav=mav,
                volume=volume_ax,
                show_nontrading=False
            )

            ax_price.set_title(f"Candlestick Chart ({self.timeframe.get()}) — {self.symbol.get() if self.source.get()=='Stooq' else 'CSV'}")

            # Volatility panel
            if ax_vol is not None:
                # Realized: |r_t| (percent)
                ax_vol.plot(vol_df.index, vol_df["RealizedVol_pct"].values, label="Realized Vol (%)")
                # Predicted: rolling forecast
                ax_vol.plot(vol_df.index, vol_df["PredVol_pct"].values, label="Predicted Vol (%)")

                ax_vol.set_ylabel("Vol (%)")
                ax_vol.legend(loc="upper left")
                ax_vol.grid(True, alpha=0.3)

                # Hide x labels on top chart to reduce clutter
                ax_price.tick_params(labelbottom=False)

            # Embed in Tkinter
            self.canvas = FigureCanvasTkAgg(self.fig, master=self.plot_frame)
            self.canvas.draw()
            self.canvas.get_tk_widget().pack(fill="both", expand=True)

            self.toolbar = NavigationToolbar2Tk(self.canvas, self.plot_frame)
            self.toolbar.update()

            self.status.set("Done.")
        except Exception as e:
            self.status.set("Error drawing.")
            messagebox.showerror("Error", str(e))


if __name__ == "__main__":
    app = CandlePatternVolGUI()
    app.mainloop()
