# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:54:52 2026

@author: Administrator
""""""
ADVANCED CANDLESTICK GUI (Tkinter) — Patterns + Timeframe + Vol Forecast Panel

✅ You asked for:
1) More pattern highlighting (Engulfing, Shooting Star, Morning Star) with checkboxes
2) Replace “Predicted Vol (%)” with model-based forecasts:
   - GARCH(1,1)
   - XGBoost (regression)
   - LSTM (GPU)
   - Transformer (GPU)

This app:
- Draws candlesticks (mplfinance) with pattern markers
- Daily/Weekly dropdown
- Volatility panel below: Realized Vol (%) vs Predicted Vol (%) from chosen model
- Training progress for deep learning models (epoch + val_loss)

INSTALL:
  pip install pandas numpy matplotlib mplfinance scikit-learn arch xgboost tensorflow

RUN:
  python candle_gui_patterns_vol_models.py

DATA:
- Stooq (default: spy.us) OR CSV with Date, Open, High, Low, Close (Volume optional)

NOTES (simple, bachelor-level):
- Patterns here are rule-based approximations (common in academic coding papers).
- "Realized volatility" proxy is |r_t| in percent.
- Forecast target is next-period variance proxy: RV_{t+1} = r_{t+1}^2.
- Predicted vol shown is sqrt(predicted RV), in percent.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import queue
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

import mplfinance as mpf

from sklearn.preprocessing import StandardScaler
from xgboost import XGBRegressor
from arch import arch_model

import tensorflow as tf
from tensorflow.keras import layers, models, callbacks


# ============================================================
# 0) Helpers
# ============================================================
def configure_gpu():
    gpus = tf.config.list_physical_devices("GPU")
    if gpus:
        try:
            for g in gpus:
                tf.config.experimental.set_memory_growth(g, True)
        except Exception:
            pass
    return gpus


# ============================================================
# 1) Data loading
# ============================================================
def load_from_stooq(symbol: str) -> pd.DataFrame:
    url = f"https://stooq.com/q/d/l/?s={symbol}&i=d"
    df = pd.read_csv(url)

    needed = {"Date", "Open", "High", "Low", "Close"}
    if not needed.issubset(set(df.columns)):
        raise ValueError(f"Stooq missing required columns. Got: {list(df.columns)}")

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date").reset_index(drop=True)

    for c in ["Open", "High", "Low", "Close", "Volume"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["Open", "High", "Low", "Close"]).copy()
    df = df.set_index("Date")
    return df


def load_from_csv(path: str) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        raise ValueError("CSV file not found.")

    df = pd.read_csv(p)
    colmap = {c.lower().strip(): c for c in df.columns}
    req = ["date", "open", "high", "low", "close"]
    for r in req:
        if r not in colmap:
            raise ValueError(f"CSV must contain Date,Open,High,Low,Close. Found: {list(df.columns)}")

    rename = {
        colmap["date"]: "Date",
        colmap["open"]: "Open",
        colmap["high"]: "High",
        colmap["low"]: "Low",
        colmap["close"]: "Close",
    }
    if "volume" in colmap:
        rename[colmap["volume"]] = "Volume"

    df = df.rename(columns=rename)
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date").reset_index(drop=True)

    for c in ["Open", "High", "Low", "Close", "Volume"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["Open", "High", "Low", "Close"]).copy()
    df = df.set_index("Date")
    return df


# ============================================================
# 2) Timeframe transform
# ============================================================
def to_timeframe(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    if timeframe == "Daily":
        return df.copy()

    agg = {"Open": "first", "High": "max", "Low": "min", "Close": "last"}
    if "Volume" in df.columns:
        agg["Volume"] = "sum"

    w = df.resample("W-FRI").agg(agg).dropna()
    return w


# ============================================================
# 3) Candlestick building blocks
# ============================================================
def candle_parts(df: pd.DataFrame):
    o, h, l, c = df["Open"], df["High"], df["Low"], df["Close"]
    body = (c - o).abs()
    rng = (h - l).replace(0, np.nan)

    upper = h - np.maximum(o, c)
    lower = np.minimum(o, c) - l

    is_bull = c > o
    is_bear = c < o

    return body, rng, upper, lower, is_bull, is_bear


# ============================================================
# 4) Pattern detection (simple rules)
# ============================================================
def detect_doji(df: pd.DataFrame, body_ratio_threshold=0.10) -> pd.Series:
    body, rng, *_ = candle_parts(df)
    return (body <= body_ratio_threshold * rng).fillna(False)

def detect_hammer(df: pd.DataFrame,
                  body_to_range_max=0.35,
                  lower_shadow_min_body=2.0,
                  upper_shadow_max_body=0.5) -> pd.Series:
    body, rng, upper, lower, *_ = candle_parts(df)
    cond1 = (body / rng <= body_to_range_max)
    cond2 = (body > 0) & (lower >= lower_shadow_min_body * body)
    cond3 = (body > 0) & (upper <= upper_shadow_max_body * body)
    return (cond1 & cond2 & cond3).fillna(False)

def detect_shooting_star(df: pd.DataFrame,
                         body_to_range_max=0.35,
                         upper_shadow_min_body=2.0,
                         lower_shadow_max_body=0.5) -> pd.Series:
    """
    Shooting star: opposite of hammer (long upper shadow).
    """
    body, rng, upper, lower, *_ = candle_parts(df)
    cond1 = (body / rng <= body_to_range_max)
    cond2 = (body > 0) & (upper >= upper_shadow_min_body * body)
    cond3 = (body > 0) & (lower <= lower_shadow_max_body * body)
    return (cond1 & cond2 & cond3).fillna(False)

def detect_bullish_engulfing(df: pd.DataFrame, min_body_ratio=0.6) -> pd.Series:
    """
    Bullish engulfing (2-candle):
    - Candle t-1 is bearish, candle t is bullish
    - Body(t) "engulfs" body(t-1): Open_t <= Close_{t-1} and Close_t >= Open_{t-1}
    - Optional: body size filter relative to range to reduce noise
    """
    o, c = df["Open"], df["Close"]
    body, rng, *_ = candle_parts(df)

    prev_o, prev_c = o.shift(1), c.shift(1)
    prev_bear = prev_c < prev_o
    curr_bull = c > o

    engulf = (o <= prev_c) & (c >= prev_o)

    body_filter = (body / rng >= min_body_ratio).fillna(False)
    out = (prev_bear & curr_bull & engulf & body_filter).fillna(False)
    return out

def detect_bearish_engulfing(df: pd.DataFrame, min_body_ratio=0.6) -> pd.Series:
    """
    Bearish engulfing:
    - Candle t-1 bullish, candle t bearish
    - Open_t >= Close_{t-1} and Close_t <= Open_{t-1}
    """
    o, c = df["Open"], df["Close"]
    body, rng, *_ = candle_parts(df)

    prev_o, prev_c = o.shift(1), c.shift(1)
    prev_bull = prev_c > prev_o
    curr_bear = c < o

    engulf = (o >= prev_c) & (c <= prev_o)
    body_filter = (body / rng >= min_body_ratio).fillna(False)

    return (prev_bull & curr_bear & engulf & body_filter).fillna(False)

def detect_morning_star(df: pd.DataFrame,
                        gap_loose=True,
                        small_body_ratio=0.30,
                        third_close_into_body=0.5) -> pd.Series:
    """
    Morning Star (3-candle bullish reversal) — simplified:
    1) First candle: bearish (down day) with decent body
    2) Second candle: "small body" (indecision)
    3) Third candle: bullish close that recovers into first candle body

    This is a simplified variant suitable for daily/weekly data (gaps may not be strong in indexes).
    """
    o, c = df["Open"], df["Close"]
    body, rng, *_ = candle_parts(df)

    # Candle t-2 (first)
    o1, c1, body1, rng1 = o.shift(2), c.shift(2), body.shift(2), rng.shift(2)
    first_bear = c1 < o1
    first_body_ok = (body1 / rng1 >= 0.5).fillna(False)

    # Candle t-1 (second): small body
    body2, rng2 = body.shift(1), rng.shift(1)
    second_small = (body2 / rng2 <= small_body_ratio).fillna(False)

    # Candle t (third): bullish, closes into body of first
    third_bull = c > o
    # "into body": close >= o1 - (portion * body1)
    # first body region: from c1 (low of body) to o1 (high of body) since bearish
    # recover threshold:
    thresh = c1 + third_close_into_body * (o1 - c1)
    third_recover = c >= thresh

    # Optional loose gap condition (often not reliable)
    if gap_loose:
        # second candle low below first close (weak "gap down")
        second_gap = df["Low"].shift(1) <= c1
    else:
        second_gap = True

    return (first_bear & first_body_ok & second_small & third_bull & third_recover & second_gap).fillna(False)


# ============================================================
# 5) Volatility series
# ============================================================
def build_vol_df(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["r_pct"] = 100 * np.log(d["Close"] / d["Close"].shift(1))
    d["RV"] = d["r_pct"] ** 2
    d["RealizedVol_pct"] = np.sqrt(np.clip(d["RV"], 0, None))
    return d


# ============================================================
# 6) Predicted volatility models
# ============================================================
def predict_vol_garch(df: pd.DataFrame, horizon_test: int) -> pd.Series:
    """
    Walk-forward GARCH(1,1) variance forecast.
    Returns a Series aligned to the last horizon_test rows (index same as df tail).
    """
    d = df.copy()
    d["r_pct"] = 100 * np.log(d["Close"] / d["Close"].shift(1))
    d = d.dropna(subset=["r_pct"]).copy()
    r = d["r_pct"]

    if len(d) <= horizon_test + 150:
        raise ValueError("Not enough data for GARCH forecast. Extend history or reduce horizon.")

    start_idx = len(d) - horizon_test
    preds = []
    idxs = []

    res_fit = None
    refit_every = 20

    for i in range(start_idx, len(d)):
        if res_fit is None or ((i - start_idx) % refit_every == 0):
            train_slice = r.iloc[:i]
            m = arch_model(train_slice, mean="Constant", vol="GARCH", p=1, q=1, dist="t")
            res_fit = m.fit(disp="off")

        f = res_fit.forecast(horizon=1, reindex=False)
        var_hat = float(f.variance.iloc[-1, 0])
        preds.append(max(var_hat, 1e-12))
        idxs.append(d.index[i])

    pred_var = pd.Series(preds, index=pd.DatetimeIndex(idxs))
    pred_vol = np.sqrt(np.clip(pred_var, 0, None))
    return pred_vol


def predict_vol_xgb(df: pd.DataFrame, horizon_test: int) -> pd.Series:
    """
    XGBoost predicts next-period RV. We convert to predicted volatility via sqrt(RV_pred).
    """
    d = df.copy()
    d["r_pct"] = 100 * np.log(d["Close"] / d["Close"].shift(1))
    d["RV"] = d["r_pct"] ** 2
    d["y_next_RV"] = d["RV"].shift(-1)

    # Basic volatility clustering features
    d["RV_lag1"] = d["RV"].shift(1)
    d["RV_lag2"] = d["RV"].shift(2)
    d["RV_roll20"] = d["RV"].rolling(20).mean()
    d["r_lag1"] = d["r_pct"].shift(1)

    feat = ["RV_lag1", "RV_lag2", "RV_roll20", "r_lag1"]
    d = d.dropna(subset=feat + ["y_next_RV"]).copy()

    if len(d) <= horizon_test + 200:
        raise ValueError("Not enough data for XGBoost. Extend history or reduce horizon.")

    train = d.iloc[:-horizon_test].copy()
    test = d.iloc[-horizon_test:].copy()

    X_train, y_train = train[feat].values, train["y_next_RV"].values
    X_test = test[feat].values

    model = XGBRegressor(
        n_estimators=1200,
        learning_rate=0.03,
        max_depth=4,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="reg:squarederror",
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)
    rv_pred = model.predict(X_test)

    vol_pred = np.sqrt(np.clip(rv_pred, 0, None))
    return pd.Series(vol_pred, index=test.index)


class GUITrainCallback(callbacks.Callback):
    def __init__(self, q: queue.Queue, total_epochs: int):
        super().__init__()
        self.q = q
        self.total_epochs = total_epochs

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        self.q.put({
            "type": "dl_epoch",
            "epoch": int(epoch) + 1,
            "total": int(self.total_epochs),
            "loss": float(logs.get("loss", np.nan)),
            "val_loss": float(logs.get("val_loss", np.nan))
        })


def build_lstm(input_shape, units1=64, units2=32, dropout=0.15):
    inp = layers.Input(shape=input_shape)
    x = layers.LSTM(units1, return_sequences=True)(inp)
    x = layers.Dropout(dropout)(x)
    x = layers.LSTM(units2, return_sequences=False)(x)
    x = layers.Dropout(dropout)(x)
    x = layers.Dense(32, activation="relu")(x)
    out = layers.Dense(1, activation="softplus")(x)  # positive RV
    return models.Model(inp, out)


def build_transformer(input_shape, d_model=64, num_heads=4, ff_dim=128, dropout=0.15):
    inp = layers.Input(shape=input_shape)
    x = layers.Dense(d_model)(inp)

    pos = tf.range(start=0, limit=input_shape[0], delta=1)
    pos_emb = layers.Embedding(input_dim=input_shape[0], output_dim=d_model)(pos)
    x = x + pos_emb

    for _ in range(2):
        attn = layers.MultiHeadAttention(num_heads=num_heads, key_dim=d_model)(x, x)
        attn = layers.Dropout(dropout)(attn)
        x = layers.LayerNormalization()(x + attn)

        ff = layers.Dense(ff_dim, activation="relu")(x)
        ff = layers.Dropout(dropout)(ff)
        ff = layers.Dense(d_model)(ff)
        x = layers.LayerNormalization()(x + ff)

    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dense(64, activation="relu")(x)
    x = layers.Dropout(0.2)(x)
    out = layers.Dense(1, activation="softplus")(x)
    return models.Model(inp, out)


def make_dl_sequences_for_rv(df: pd.DataFrame, lookback: int):
    """
    Features: r_pct, RV, RV_roll20
    Target: next RV
    """
    d = df.copy()
    d["r_pct"] = 100 * np.log(d["Close"] / d["Close"].shift(1))
    d["RV"] = d["r_pct"] ** 2
    d["y_next_RV"] = d["RV"].shift(-1)
    d["RV_roll20"] = d["RV"].rolling(20).mean()

    feat_cols = ["r_pct", "RV", "RV_roll20"]
    d = d.dropna(subset=feat_cols + ["y_next_RV"]).copy()

    X = d[feat_cols].values
    y = d["y_next_RV"].values

    Xs, ys, idxs = [], [], []
    for t in range(lookback - 1, len(d)):
        Xs.append(X[t - lookback + 1: t + 1])
        ys.append(y[t])
        idxs.append(d.index[t])

    return np.array(Xs), np.array(ys), pd.DatetimeIndex(idxs), feat_cols


def predict_vol_dl(df: pd.DataFrame, horizon_test: int, model_name: str,
                   lookback=60, epochs=40, batch=128, lr=1e-3,
                   lstm_u1=64, lstm_u2=32,
                   tr_d_model=64, tr_heads=4, tr_ff=128,
                   dropout=0.15,
                   q_gui: queue.Queue | None = None) -> pd.Series:
    """
    LSTM / Transformer predicts next RV; we output sqrt(RV_pred) as vol(%).
    """
    configure_gpu()

    X_seq, y_seq, idxs, feat_cols = make_dl_sequences_for_rv(df, lookback=lookback)

    if len(X_seq) <= horizon_test + 250:
        raise ValueError("Not enough sequences for DL. Extend history or reduce horizon/lookback.")

    X_train, X_test = X_seq[:-horizon_test], X_seq[-horizon_test:]
    y_train, y_test = y_seq[:-horizon_test], y_seq[-horizon_test:]
    idx_test = idxs[-horizon_test:]

    scaler = StandardScaler()
    X_train_flat = X_train.reshape(-1, X_train.shape[-1])
    scaler.fit(X_train_flat)
    X_train_s = scaler.transform(X_train_flat).reshape(X_train.shape)
    X_test_s = scaler.transform(X_test.reshape(-1, X_test.shape[-1])).reshape(X_test.shape)

    input_shape = (lookback, X_train.shape[-1])
    if model_name == "LSTM":
        model = build_lstm(input_shape, units1=lstm_u1, units2=lstm_u2, dropout=dropout)
    else:
        model = build_transformer(input_shape, d_model=tr_d_model, num_heads=tr_heads, ff_dim=tr_ff, dropout=dropout)

    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr), loss="mse")

    cb = [
        callbacks.EarlyStopping(monitor="val_loss", patience=8, restore_best_weights=True),
        callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=4, min_lr=1e-5),
    ]
    if q_gui is not None:
        cb.append(GUITrainCallback(q_gui, total_epochs=epochs))

    model.fit(
        X_train_s, y_train,
        validation_split=0.2,
        epochs=epochs,
        batch_size=batch,
        verbose=0,
        callbacks=cb
    )

    rv_pred = model.predict(X_test_s, verbose=0).reshape(-1)
    vol_pred = np.sqrt(np.clip(rv_pred, 0, None))
    return pd.Series(vol_pred, index=idx_test)


# ============================================================
# 7) GUI
# ============================================================
class CandleGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Candlestick GUI — Patterns + Vol Forecast Models (GPU)")
        self.geometry("1320x900")

        # Inputs
        self.source = tk.StringVar(value="Stooq")
        self.symbol = tk.StringVar(value="spy.us")
        self.csv_path = tk.StringVar(value="")
        self.timeframe = tk.StringVar(value="Daily")
        self.style = tk.StringVar(value="yahoo")

        # pattern toggles
        self.p_doji = tk.BooleanVar(value=True)
        self.p_hammer = tk.BooleanVar(value=True)
        self.p_shooting = tk.BooleanVar(value=True)
        self.p_morning = tk.BooleanVar(value=False)
        self.p_bull_engulf = tk.BooleanVar(value=True)
        self.p_bear_engulf = tk.BooleanVar(value=False)

        # vol panel + model
        self.show_vol_panel = tk.BooleanVar(value=True)
        self.vol_model = tk.StringVar(value="GARCH")
        self.test_horizon = tk.IntVar(value=252)

        # DL params
        self.dl_lookback = tk.IntVar(value=60)
        self.dl_epochs = tk.IntVar(value=40)
        self.dl_batch = tk.IntVar(value=128)
        self.dl_lr = tk.DoubleVar(value=1e-3)
        self.dl_dropout = tk.DoubleVar(value=0.15)
        self.lstm_u1 = tk.IntVar(value=64)
        self.lstm_u2 = tk.IntVar(value=32)
        self.tr_d_model = tk.IntVar(value=64)
        self.tr_heads = tk.IntVar(value=4)
        self.tr_ff = tk.IntVar(value=128)

        # Data
        self.df_raw = None
        self.df_tf = None

        # Matplotlib
        self.fig = None
        self.canvas = None
        self.toolbar = None

        # threading queue for training progress
        self.ui_queue = queue.Queue()
        self.worker_thread = None

        self._build_ui()
        self._poll_queue()

    def _build_ui(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")

        ttk.Label(top, text="Source:").grid(row=0, column=0, sticky="w")
        src = ttk.Combobox(top, textvariable=self.source, values=["Stooq", "CSV"], width=10, state="readonly")
        src.grid(row=0, column=1, sticky="w", padx=6)
        src.bind("<<ComboboxSelected>>", lambda e: self._toggle_source())

        ttk.Label(top, text="Symbol:").grid(row=0, column=2, sticky="w")
        ttk.Entry(top, textvariable=self.symbol, width=12).grid(row=0, column=3, sticky="w", padx=6)

        ttk.Label(top, text="CSV:").grid(row=0, column=4, sticky="w")
        self.csv_entry = ttk.Entry(top, textvariable=self.csv_path, width=52)
        self.csv_entry.grid(row=0, column=5, sticky="w", padx=6)
        ttk.Button(top, text="Browse", command=self._browse).grid(row=0, column=6, sticky="w")

        ttk.Label(top, text="Timeframe:").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Combobox(top, textvariable=self.timeframe, values=["Daily", "Weekly"], width=10, state="readonly")\
            .grid(row=1, column=1, sticky="w", padx=6, pady=(8, 0))

        ttk.Label(top, text="Style:").grid(row=1, column=2, sticky="w", pady=(8, 0))
        ttk.Combobox(top, textvariable=self.style, values=["yahoo", "charles", "binance", "classic"], width=12, state="readonly")\
            .grid(row=1, column=3, sticky="w", padx=6, pady=(8, 0))

        ttk.Checkbutton(top, text="Vol panel", variable=self.show_vol_panel).grid(row=1, column=4, sticky="w", pady=(8, 0))

        ttk.Label(top, text="Vol model:").grid(row=1, column=5, sticky="e", pady=(8, 0))
        vol_cb = ttk.Combobox(top, textvariable=self.vol_model,
                              values=["GARCH", "XGBoost", "LSTM", "Transformer"],
                              width=12, state="readonly")
        vol_cb.grid(row=1, column=6, sticky="w", pady=(8, 0))

        pat = ttk.LabelFrame(self, text="Pattern Highlight", padding=8)
        pat.pack(fill="x", padx=10)

        ttk.Checkbutton(pat, text="Doji", variable=self.p_doji).pack(side="left", padx=6)
        ttk.Checkbutton(pat, text="Hammer", variable=self.p_hammer).pack(side="left", padx=6)
        ttk.Checkbutton(pat, text="Shooting Star", variable=self.p_shooting).pack(side="left", padx=6)
        ttk.Checkbutton(pat, text="Morning Star", variable=self.p_morning).pack(side="left", padx=6)
        ttk.Checkbutton(pat, text="Bull Engulf", variable=self.p_bull_engulf).pack(side="left", padx=6)
        ttk.Checkbutton(pat, text="Bear Engulf", variable=self.p_bear_engulf).pack(side="left", padx=6)

        mid = ttk.Frame(self, padding=(10, 6, 10, 10))
        mid.pack(fill="x")

        ttk.Label(mid, text="Vol horizon (last N bars):").pack(side="left")
        ttk.Entry(mid, textvariable=self.test_horizon, width=8).pack(side="left", padx=6)

        ttk.Button(mid, text="Load Data", command=self._load).pack(side="left", padx=12)
        self.run_btn = ttk.Button(mid, text="Draw + Forecast", command=self._run_clicked)
        self.run_btn.pack(side="left")

        ttk.Button(mid, text="GPU status", command=self._gpu_status).pack(side="left", padx=10)

        self.status = tk.StringVar(value="Ready.")
        ttk.Label(mid, textvariable=self.status).pack(side="right")

        # DL parameters (shown always, simple)
        dl = ttk.LabelFrame(self, text="DL Params (for LSTM/Transformer vol model)", padding=8)
        dl.pack(fill="x", padx=10, pady=(0, 10))

        ttk.Label(dl, text="Lookback:").pack(side="left")
        ttk.Entry(dl, textvariable=self.dl_lookback, width=6).pack(side="left", padx=6)
        ttk.Label(dl, text="Epochs:").pack(side="left")
        ttk.Entry(dl, textvariable=self.dl_epochs, width=6).pack(side="left", padx=6)
        ttk.Label(dl, text="Batch:").pack(side="left")
        ttk.Entry(dl, textvariable=self.dl_batch, width=6).pack(side="left", padx=6)
        ttk.Label(dl, text="LR:").pack(side="left")
        ttk.Entry(dl, textvariable=self.dl_lr, width=8).pack(side="left", padx=6)
        ttk.Label(dl, text="Dropout:").pack(side="left")
        ttk.Entry(dl, textvariable=self.dl_dropout, width=6).pack(side="left", padx=6)

        ttk.Label(dl, text="LSTM u1/u2:").pack(side="left", padx=(12, 0))
        ttk.Entry(dl, textvariable=self.lstm_u1, width=6).pack(side="left", padx=4)
        ttk.Entry(dl, textvariable=self.lstm_u2, width=6).pack(side="left", padx=4)

        ttk.Label(dl, text="Transformer d/h/ff:").pack(side="left", padx=(12, 0))
        ttk.Entry(dl, textvariable=self.tr_d_model, width=6).pack(side="left", padx=4)
        ttk.Entry(dl, textvariable=self.tr_heads, width=6).pack(side="left", padx=4)
        ttk.Entry(dl, textvariable=self.tr_ff, width=6).pack(side="left", padx=4)

        # Progress bar
        prog_frame = ttk.Frame(self, padding=(10, 0, 10, 8))
        prog_frame.pack(fill="x")
        self.prog = ttk.Progressbar(prog_frame, orient="horizontal", length=420, mode="determinate")
        self.prog.pack(side="right")

        # Plot
        self.plot_frame = ttk.Frame(self, padding=10)
        self.plot_frame.pack(fill="both", expand=True)

        self._toggle_source()

    def _toggle_source(self):
        is_csv = (self.source.get() == "CSV")
        self.csv_entry.configure(state="normal" if is_csv else "disabled")

    def _browse(self):
        path = filedialog.askopenfilename(
            title="Select OHLC CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if path:
            self.csv_path.set(path)
            self.source.set("CSV")
            self._toggle_source()

    def _gpu_status(self):
        gpus = configure_gpu()
        if not gpus:
            messagebox.showinfo("GPU", "TensorFlow does NOT see a GPU (CPU mode).")
        else:
            messagebox.showinfo("GPU", "TensorFlow sees:\n" + "\n".join(map(str, gpus)))

    def _clear_plot(self):
        if self.toolbar:
            self.toolbar.destroy()
            self.toolbar = None
        if self.canvas:
            self.canvas.get_tk_widget().destroy()
            self.canvas = None
        self.fig = None

    def _load(self):
        try:
            self.status.set("Loading...")
            self.update_idletasks()

            if self.source.get() == "Stooq":
                sym = self.symbol.get().strip()
                if not sym:
                    raise ValueError("Symbol empty.")
                df = load_from_stooq(sym)
            else:
                path = self.csv_path.get().strip()
                if not path:
                    raise ValueError("CSV path empty.")
                df = load_from_csv(path)

            self.df_raw = df
            self.status.set(f"Loaded {len(df)} rows.")
            messagebox.showinfo("Loaded", f"Loaded {len(df)} rows.")
        except Exception as e:
            self.status.set("Load error.")
            messagebox.showerror("Error", str(e))

    def _run_clicked(self):
        if self.worker_thread and self.worker_thread.is_alive():
            messagebox.showwarning("Busy", "Already running.")
            return
        if self.df_raw is None or self.df_raw.empty:
            messagebox.showwarning("No data", "Click Load Data first.")
            return

        # Setup progress bar for DL
        if self.vol_model.get() in ["LSTM", "Transformer"]:
            total = int(self.dl_epochs.get())
            self.prog.configure(maximum=total)
            self.prog["value"] = 0
        else:
            self.prog.configure(maximum=100)
            self.prog["value"] = 0

        self.run_btn.configure(state="disabled")
        self.status.set("Running...")
        self.worker_thread = threading.Thread(target=self._worker, daemon=True)
        self.worker_thread.start()

    def _worker(self):
        try:
            # Timeframe
            df_tf = to_timeframe(self.df_raw, self.timeframe.get())
            if df_tf.empty:
                raise ValueError("Empty after timeframe conversion.")
            self.df_tf = df_tf

            horizon = int(self.test_horizon.get())
            vol_model = self.vol_model.get()

            # Build realized vol
            vol_df = build_vol_df(df_tf)

            # Compute predicted vol for last horizon bars
            pred_vol = None
            if vol_model == "GARCH":
                pred_vol = predict_vol_garch(df_tf, horizon_test=horizon)

            elif vol_model == "XGBoost":
                pred_vol = predict_vol_xgb(df_tf, horizon_test=horizon)

            elif vol_model in ["LSTM", "Transformer"]:
                epochs = int(self.dl_epochs.get())
                self.ui_queue.put({"type": "dl_total", "total": epochs})

                pred_vol = predict_vol_dl(
                    df_tf, horizon_test=horizon,
                    model_name=("LSTM" if vol_model == "LSTM" else "Transformer"),
                    lookback=int(self.dl_lookback.get()),
                    epochs=epochs,
                    batch=int(self.dl_batch.get()),
                    lr=float(self.dl_lr.get()),
                    lstm_u1=int(self.lstm_u1.get()),
                    lstm_u2=int(self.lstm_u2.get()),
                    tr_d_model=int(self.tr_d_model.get()),
                    tr_heads=int(self.tr_heads.get()),
                    tr_ff=int(self.tr_ff.get()),
                    dropout=float(self.dl_dropout.get()),
                    q_gui=self.ui_queue
                )

            else:
                raise ValueError("Unknown vol model.")

            self.ui_queue.put({"type": "result", "pred_vol": pred_vol, "vol_df": vol_df})

        except Exception as e:
            self.ui_queue.put({"type": "error", "message": str(e)})

    def _poll_queue(self):
        try:
            while True:
                msg = self.ui_queue.get_nowait()
                t = msg.get("type")

                if t == "dl_total":
                    self.prog.configure(maximum=int(msg["total"]))
                    self.prog["value"] = 0

                elif t == "dl_epoch":
                    ep = int(msg["epoch"])
                    total = int(msg["total"])
                    self.prog["value"] = ep
                    self.status.set(f"DL epoch {ep}/{total} | val_loss={msg.get('val_loss', np.nan):.6f}")

                elif t == "result":
                    self.prog["value"] = self.prog["maximum"]
                    self._draw_chart(pred_vol=msg["pred_vol"], vol_df=msg["vol_df"])
                    self.status.set("Done.")
                    self.run_btn.configure(state="normal")
                    messagebox.showinfo("Done", "Chart updated.")

                elif t == "error":
                    self.status.set("Error.")
                    self.run_btn.configure(state="normal")
                    messagebox.showerror("Error", msg["message"])

        except queue.Empty:
            pass

        self.after(150, self._poll_queue)

    def _draw_chart(self, pred_vol: pd.Series, vol_df: pd.DataFrame):
        df_tf = self.df_tf

        # Patterns
        doji = detect_doji(df_tf) if self.p_doji.get() else pd.Series(False, index=df_tf.index)
        hammer = detect_hammer(df_tf) if self.p_hammer.get() else pd.Series(False, index=df_tf.index)
        shooting = detect_shooting_star(df_tf) if self.p_shooting.get() else pd.Series(False, index=df_tf.index)
        morning = detect_morning_star(df_tf) if self.p_morning.get() else pd.Series(False, index=df_tf.index)
        bull_eng = detect_bullish_engulfing(df_tf) if self.p_bull_engulf.get() else pd.Series(False, index=df_tf.index)
        bear_eng = detect_bearish_engulfing(df_tf) if self.p_bear_engulf.get() else pd.Series(False, index=df_tf.index)

        # Prepare plot
        self._clear_plot()

        if self.show_vol_panel.get():
            self.fig = plt.figure(figsize=(12.6, 7.4))
            gs = self.fig.add_gridspec(2, 1, height_ratios=[3, 1], hspace=0.05)
            ax_price = self.fig.add_subplot(gs[0, 0])
            ax_vol = self.fig.add_subplot(gs[1, 0], sharex=ax_price)
        else:
            self.fig = plt.figure(figsize=(12.6, 7.4))
            ax_price = self.fig.add_subplot(1, 1, 1)
            ax_vol = None

        addplots = []

        # Marker positions:
        # - Doji at close (o)
        if self.p_doji.get():
            addplots.append(mpf.make_addplot(df_tf["Close"].where(doji, np.nan), ax=ax_price,
                                             type="scatter", markersize=50, marker="o"))
        # - Hammer at low (^)
        if self.p_hammer.get():
            addplots.append(mpf.make_addplot(df_tf["Low"].where(hammer, np.nan), ax=ax_price,
                                             type="scatter", markersize=70, marker="^"))
        # - Shooting star at high (v)
        if self.p_shooting.get():
            addplots.append(mpf.make_addplot(df_tf["High"].where(shooting, np.nan), ax=ax_price,
                                             type="scatter", markersize=70, marker="v"))
        # - Morning star mark at close (*)
        if self.p_morning.get():
            addplots.append(mpf.make_addplot(df_tf["Close"].where(morning, np.nan), ax=ax_price,
                                             type="scatter", markersize=90, marker="*"))
        # - Bull engulf at low (P)
        if self.p_bull_engulf.get():
            addplots.append(mpf.make_addplot(df_tf["Low"].where(bull_eng, np.nan), ax=ax_price,
                                             type="scatter", markersize=90, marker="P"))
        # - Bear engulf at high (X)
        if self.p_bear_engulf.get():
            addplots.append(mpf.make_addplot(df_tf["High"].where(bear_eng, np.nan), ax=ax_price,
                                             type="scatter", markersize=90, marker="X"))

        mav = (20, 50) if len(df_tf) > 60 else (20,)

        mpf.plot(
            df_tf,
            type="candle",
            ax=ax_price,
            addplot=addplots if addplots else None,
            style=self.style.get(),
            mav=mav,
            volume=False,
            show_nontrading=False
        )

        ax_price.set_title(f"Candles ({self.timeframe.get()}) | Vol model: {self.vol_model.get()}")

        # Vol panel
        if ax_vol is not None:
            ax_price.tick_params(labelbottom=False)

            # Realized vol aligned
            rv = vol_df["RealizedVol_pct"].copy()

            # Predicted vol aligned (may cover only last N bars)
            pv = pred_vol.copy()

            # Align on common index
            common_idx = rv.index.intersection(pv.index)
            rv_plot = rv.loc[common_idx]
            pv_plot = pv.loc[common_idx]

            ax_vol.plot(rv_plot.index, rv_plot.values, label="Realized Vol (%)")
            ax_vol.plot(pv_plot.index, pv_plot.values, label="Predicted Vol (%)")
            ax_vol.set_ylabel("Vol (%)")
            ax_vol.legend(loc="upper left")
            ax_vol.grid(True, alpha=0.3)

        # Embed
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.plot_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

        self.toolbar = NavigationToolbar2Tk(self.canvas, self.plot_frame)
        self.toolbar.update()


if __name__ == "__main__":
    app = CandleGUI()
    app.mainloop()


