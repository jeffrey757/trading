# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:14:14 2026

@author: Administrator
"""

"""
VOLATILITY PREDICTION WITH LSTM (Keras/TensorFlow) — Thesis-ready, simple + robust

Goal:
- Predict next-day volatility (variance proxy) using an LSTM neural network.

Target (what we predict):
- Next-day realized variance proxy: y_t = r_{t+1}^2  (percent^2)

Inputs (features):
- Past sequence (lookback window) of:
    1) returns r_t (percent log returns)
    2) squared returns r_t^2 (variance proxy)
    3) rolling variance (20-day) as a smooth volatility feature

Data:
- Primary: Stooq (spy.us) close prices (S&P 500 proxy)
- Fallback: prices.csv with columns Date, Close

Install:
  pip install pandas numpy scikit-learn tensorflow

Run:
  python lstm_volatility_prediction.py

Outputs:
- Test metrics: MSE, MAE, RMSE, R^2 + QLIKE
- CSV with predictions: lstm_vol_predictions.csv
"""

import numpy as np
import pandas as pd
from pathlib import Path

from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

import tensorflow as tf
from tensorflow.keras import layers, models, callbacks

# ----------------------------
# 1) Settings
# ----------------------------
START_DATE = "2014-01-01"
END_DATE = "2024-01-01"                 # exclusive end
STOOQ_SYMBOL = "spy.us"
STOOQ_URL = f"https://stooq.com/q/d/l/?s={STOOQ_SYMBOL}&i=d"

CSV_FALLBACK = Path("prices.csv")       # must contain Date, Close (at least)

TEST_SIZE = 252                         # last ~1 year test
LOOKBACK = 30                           # sequence length (e.g., 30 days)
BATCH_SIZE = 32
EPOCHS = 80
RANDOM_SEED = 42

OUT_PRED_CSV = Path("lstm_vol_predictions.csv")

# Reproducibility (best-effort)
np.random.seed(RANDOM_SEED)
tf.random.set_seed(RANDOM_SEED)

# ----------------------------
# 2) Load prices (Stooq -> CSV)
# ----------------------------
def load_prices() -> pd.DataFrame:
    # --- Stooq ---
    try:
        print(f"Loading from Stooq: {STOOQ_URL}")
        df = pd.read_csv(STOOQ_URL)
        if df is None or df.empty:
            raise ValueError("Stooq returned empty.")
        if "Date" not in df.columns or "Close" not in df.columns:
            raise ValueError(f"Unexpected columns: {list(df.columns)}")

        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df.dropna(subset=["Date"]).sort_values("Date")
        df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]
        df = df[["Date", "Close"]].dropna()

        if df.empty:
            raise ValueError("No rows in date range.")
        print(f"✅ Loaded {len(df)} rows from Stooq ({STOOQ_SYMBOL})")
        return df.reset_index(drop=True)

    except Exception as e:
        print(f"⚠ Stooq failed: {e}")
        print("Falling back to local CSV...")

    # --- CSV fallback ---
    if not CSV_FALLBACK.exists():
        raise ValueError(
            f"[FATAL] Could not load from Stooq and CSV fallback not found.\n"
            f"Create {CSV_FALLBACK.name} with columns: Date, Close"
        )

    df = pd.read_csv(CSV_FALLBACK)
    colmap = {c.lower().strip(): c for c in df.columns}
    if "date" not in colmap or "close" not in colmap:
        raise ValueError(f"[FATAL] CSV must contain Date and Close. Found: {list(df.columns)}")

    df = df.rename(columns={colmap["date"]: "Date", colmap["close"]: "Close"})
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]
    df = df[["Date", "Close"]].dropna()

    if df.empty:
        raise ValueError("[FATAL] CSV loaded but no rows in date range.")
    print(f"✅ Loaded {len(df)} rows from CSV fallback ({CSV_FALLBACK})")
    return df.reset_index(drop=True)


df = load_prices()
df["Close"] = pd.to_numeric(df["Close"], errors="coerce")
df = df.dropna(subset=["Close"]).copy()

# ----------------------------
# 3) Build returns and target
# ----------------------------
# Percent log return
df["r_pct"] = 100 * np.log(df["Close"] / df["Close"].shift(1))
df["rv"] = df["r_pct"] ** 2                           # realized variance proxy (percent^2)
df["rv_next"] = df["rv"].shift(-1)                    # target: next day's variance

# Rolling variance feature (smooth volatility)
df["rv_roll20"] = df["rv"].rolling(20).mean()

# Drop NaNs
df = df.dropna(subset=["r_pct", "rv", "rv_next", "rv_roll20"]).reset_index(drop=True)

if len(df) <= TEST_SIZE + LOOKBACK + 50:
    raise ValueError("[FATAL] Not enough data after cleaning. Reduce TEST_SIZE or LOOKBACK.")

# ----------------------------
# 4) Build sequences for LSTM
# ----------------------------
feature_cols = ["r_pct", "rv", "rv_roll20"]

X_all = df[feature_cols].values
y_all = df["rv_next"].values
dates_all = df["Date"].values
close_all = df["Close"].values

def make_sequences(X, y, dates, close, lookback: int):
    """
    Convert (X_t, y_t) into sequences:
      Input: X[t-lookback+1 ... t]  -> predicts y[t]
    We align such that each sample ends at time t.
    """
    X_seq, y_seq, d_seq, c_seq = [], [], [], []
    for t in range(lookback - 1, len(X)):
        X_seq.append(X[t - lookback + 1 : t + 1])
        y_seq.append(y[t])
        d_seq.append(dates[t])
        c_seq.append(close[t])
    return np.array(X_seq), np.array(y_seq), np.array(d_seq), np.array(c_seq)

X_seq, y_seq, d_seq, c_seq = make_sequences(X_all, y_all, dates_all, close_all, LOOKBACK)

# Time-series split: last TEST_SIZE samples are test
X_train, X_test = X_seq[:-TEST_SIZE], X_seq[-TEST_SIZE:]
y_train, y_test = y_seq[:-TEST_SIZE], y_seq[-TEST_SIZE:]
d_test = d_seq[-TEST_SIZE:]
c_test = c_seq[-TEST_SIZE:]

print(f"\nSequences: train={len(X_train)} test={len(X_test)}")
print(f"Input shape: {X_train.shape} (samples, lookback, features)")

# ----------------------------
# 5) Scale features (important for neural nets)
# ----------------------------
"""
We scale features using training data only to avoid look-ahead bias.
We use StandardScaler on the feature dimension.
For sequences, we flatten -> scale -> reshape back.
"""
scaler = StandardScaler()

# Fit on training data flattened
X_train_flat = X_train.reshape(-1, X_train.shape[-1])
scaler.fit(X_train_flat)

# Transform train/test
X_train_scaled = scaler.transform(X_train_flat).reshape(X_train.shape)
X_test_scaled = scaler.transform(X_test.reshape(-1, X_test.shape[-1])).reshape(X_test.shape)

# ----------------------------
# 6) Build LSTM model
# ----------------------------
"""
A simple LSTM regression:
- LSTM learns patterns in volatility clustering from sequences
- Output is a single number: predicted next-day variance (percent^2)

We predict variance directly (non-negative). To encourage non-negativity,
we can use 'softplus' activation in the final layer.
"""
model = models.Sequential([
    layers.Input(shape=(LOOKBACK, len(feature_cols))),

    layers.LSTM(64, return_sequences=True),
    layers.Dropout(0.2),

    layers.LSTM(32, return_sequences=False),
    layers.Dropout(0.2),

    layers.Dense(32, activation="relu"),
    layers.Dense(1, activation="softplus")   # softplus ensures output > 0
])

model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
    loss="mse"
)

cb = [
    callbacks.EarlyStopping(monitor="val_loss", patience=10, restore_best_weights=True),
    callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=5, min_lr=1e-5)
]

history = model.fit(
    X_train_scaled, y_train,
    validation_split=0.2,
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    callbacks=cb,
    verbose=1
)

# ----------------------------
# 7) Predict and evaluate
# ----------------------------
y_pred = model.predict(X_test_scaled, verbose=0).reshape(-1)

mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

# Baseline: naive variance forecast = yesterday's variance (rv at end of sequence)
# That is: last element of 'rv' feature in each test sequence
rv_last_in_seq = X_test[:, -1, feature_cols.index("rv")]
mse_b = mean_squared_error(y_test, rv_last_in_seq)
mae_b = mean_absolute_error(y_test, rv_last_in_seq)
rmse_b = np.sqrt(mse_b)
r2_b = r2_score(y_test, rv_last_in_seq)

# QLIKE (lower is better)
eps = 1e-12
y_pred_clip = np.clip(y_pred, eps, None)
y_test_clip = np.clip(y_test, eps, None)
qlike_lstm = float(np.mean(np.log(y_pred_clip) + (y_test_clip / y_pred_clip)))

base_clip = np.clip(rv_last_in_seq, eps, None)
qlike_base = float(np.mean(np.log(base_clip) + (y_test_clip / base_clip)))

print("\n=== LSTM Volatility Prediction (Target = next-day r^2) ===")
print(f"LSTM  MSE : {mse:.6f} | MAE : {mae:.6f} | RMSE : {rmse:.6f} | R^2 : {r2:.4f} | QLIKE: {qlike_lstm:.6f}")
print(f"BASE  MSE : {mse_b:.6f} | MAE : {mae_b:.6f} | RMSE : {rmse_b:.6f} | R^2 : {r2_b:.4f} | QLIKE: {qlike_base:.6f}")

# ----------------------------
# 8) Save predictions
# ----------------------------
out = pd.DataFrame({
    "Date": pd.to_datetime(d_test),
    "Close": c_test,
    "RV_true": y_test,
    "RV_pred_LSTM": y_pred,
    "RV_pred_Baseline": rv_last_in_seq,
})

# Convert variance -> daily volatility (%)
out["Vol_true_pct"] = np.sqrt(np.clip(out["RV_true"].values, 0, None))
out["Vol_pred_LSTM_pct"] = np.sqrt(np.clip(out["RV_pred_LSTM"].values, 0, None))
out["Vol_pred_Base_pct"] = np.sqrt(np.clip(out["RV_pred_Baseline"].values, 0, None))

out.to_csv(OUT_PRED_CSV, index=False)
print(f"\n✅ Saved predictions to: {OUT_PRED_CSV.resolve()}")
