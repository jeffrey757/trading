# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:44:04 2026

@author: Administrator
"""

"""
Candlestick Chart GUI (Python HUI = Human UI)

Features:
- Load OHLC data from:
    1) Stooq (online, default: spy.us)
    2) Local CSV (offline)
- Draw candlestick chart using mplfinance
- Optional volume
- Interactive zoom/pan via Matplotlib toolbar

CSV format:
- Required columns: Date, Open, High, Low, Close
- Optional: Volume
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
from pathlib import Path

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

import mplfinance as mpf


# ----------------------------
# Data loading
# ----------------------------
def load_from_stooq(symbol: str, start: str, end: str) -> pd.DataFrame:
    """
    Stooq daily OHLCV CSV.
    Example symbol: spy.us (S&P 500 proxy ETF), aapl.us, etc.
    """
    url = f"https://stooq.com/q/d/l/?s={symbol}&i=d"
    df = pd.read_csv(url)

    needed = {"Date", "Open", "High", "Low", "Close"}
    if not needed.issubset(set(df.columns)):
        raise ValueError(f"Stooq data missing required columns. Got: {list(df.columns)}")

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= start) & (df["Date"] < end)]

    for c in ["Open", "High", "Low", "Close", "Volume"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["Open", "High", "Low", "Close"]).copy()

    # mplfinance requires Date index
    df = df.set_index("Date")
    return df


def load_from_csv(path: str, start: str, end: str) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        raise ValueError("CSV file not found.")

    df = pd.read_csv(p)
    colmap = {c.lower().strip(): c for c in df.columns}

    required = ["date", "open", "high", "low", "close"]
    for r in required:
        if r not in colmap:
            raise ValueError(f"CSV must contain columns: Date, Open, High, Low, Close. Found: {list(df.columns)}")

    rename = {
        colmap["date"]: "Date",
        colmap["open"]: "Open",
        colmap["high"]: "High",
        colmap["low"]: "Low",
        colmap["close"]: "Close",
    }
    if "volume" in colmap:
        rename[colmap["volume"]] = "Volume"

    df = df.rename(columns=rename)
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= start) & (df["Date"] < end)]

    for c in ["Open", "High", "Low", "Close", "Volume"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["Open", "High", "Low", "Close"]).copy()
    df = df.set_index("Date")
    return df


# ----------------------------
# GUI App
# ----------------------------
class CandleGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Candlestick Chart GUI (mplfinance + Tkinter)")
        self.geometry("1200x800")

        # Inputs
        self.source = tk.StringVar(value="Stooq")
        self.symbol = tk.StringVar(value="spy.us")
        self.csv_path = tk.StringVar(value="")
        self.start_date = tk.StringVar(value="2019-01-01")
        self.end_date = tk.StringVar(value="2024-01-01")

        self.show_volume = tk.BooleanVar(value=True)
        self.style = tk.StringVar(value="yahoo")  # mplfinance styles: yahoo, charles, binance, etc.
        self.ma_1 = tk.IntVar(value=20)           # moving average lines
        self.ma_2 = tk.IntVar(value=50)

        # Data/figure references
        self.df = None
        self.fig = None
        self.canvas = None
        self.toolbar = None

        self._build_ui()

    def _build_ui(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")

        ttk.Label(top, text="Source:").grid(row=0, column=0, sticky="w")
        src = ttk.Combobox(top, textvariable=self.source, values=["Stooq", "CSV"], width=10, state="readonly")
        src.grid(row=0, column=1, sticky="w", padx=6)
        src.bind("<<ComboboxSelected>>", lambda e: self._toggle_source())

        ttk.Label(top, text="Stooq Symbol:").grid(row=0, column=2, sticky="w")
        ttk.Entry(top, textvariable=self.symbol, width=12).grid(row=0, column=3, sticky="w", padx=6)

        ttk.Label(top, text="CSV Path:").grid(row=0, column=4, sticky="w")
        self.csv_entry = ttk.Entry(top, textvariable=self.csv_path, width=45)
        self.csv_entry.grid(row=0, column=5, sticky="w", padx=6)
        ttk.Button(top, text="Browse", command=self._browse).grid(row=0, column=6, sticky="w")

        ttk.Label(top, text="Start:").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.start_date, width=12).grid(row=1, column=1, sticky="w", padx=6, pady=(8, 0))

        ttk.Label(top, text="End:").grid(row=1, column=2, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.end_date, width=12).grid(row=1, column=3, sticky="w", padx=6, pady=(8, 0))

        ttk.Label(top, text="Style:").grid(row=1, column=4, sticky="w", pady=(8, 0))
        ttk.Combobox(top, textvariable=self.style, values=["yahoo", "charles", "binance", "classic"], width=12, state="readonly")\
            .grid(row=1, column=5, sticky="w", padx=6, pady=(8, 0))

        ttk.Checkbutton(top, text="Show Volume", variable=self.show_volume).grid(row=1, column=6, sticky="w", pady=(8, 0))

        mid = ttk.Frame(self, padding=(10, 0, 10, 10))
        mid.pack(fill="x")

        ttk.Label(mid, text="MA1:").pack(side="left")
        ttk.Entry(mid, textvariable=self.ma_1, width=6).pack(side="left", padx=6)
        ttk.Label(mid, text="MA2:").pack(side="left")
        ttk.Entry(mid, textvariable=self.ma_2, width=6).pack(side="left", padx=6)

        ttk.Button(mid, text="Load Data", command=self._load_data).pack(side="left", padx=10)
        ttk.Button(mid, text="Draw Candles", command=self._draw).pack(side="left")

        self.status = tk.StringVar(value="Ready.")
        ttk.Label(mid, textvariable=self.status).pack(side="right")

        # Plot area
        self.plot_frame = ttk.Frame(self, padding=10)
        self.plot_frame.pack(fill="both", expand=True)

        self._toggle_source()

    def _toggle_source(self):
        is_csv = (self.source.get() == "CSV")
        self.csv_entry.configure(state="normal" if is_csv else "disabled")

    def _browse(self):
        path = filedialog.askopenfilename(
            title="Select OHLC CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if path:
            self.csv_path.set(path)
            self.source.set("CSV")
            self._toggle_source()

    def _clear_plot(self):
        if self.toolbar:
            self.toolbar.destroy()
            self.toolbar = None
        if self.canvas:
            self.canvas.get_tk_widget().destroy()
            self.canvas = None
        self.fig = None

    def _load_data(self):
        try:
            self.status.set("Loading data...")
            self.update_idletasks()

            start = self.start_date.get().strip()
            end = self.end_date.get().strip()

            if self.source.get() == "Stooq":
                sym = self.symbol.get().strip()
                if not sym:
                    raise ValueError("Stooq symbol is empty.")
                df = load_from_stooq(sym, start, end)
            else:
                path = self.csv_path.get().strip()
                if not path:
                    raise ValueError("CSV path is empty.")
                df = load_from_csv(path, start, end)

            if df.empty:
                raise ValueError("No rows loaded. Check dates or data source.")

            self.df = df
            self.status.set(f"Loaded {len(df)} rows. (from {self.source.get()})")
            messagebox.showinfo("Loaded", f"Loaded {len(df)} rows successfully.")

        except Exception as e:
            self.status.set("Error loading.")
            messagebox.showerror("Error", str(e))

    def _draw(self):
        try:
            if self.df is None or self.df.empty:
                raise ValueError("No data loaded. Click 'Load Data' first.")

            self.status.set("Drawing chart...")
            self.update_idletasks()
            self._clear_plot()

            # Moving averages (ignore invalid values)
            ma1 = int(self.ma_1.get())
            ma2 = int(self.ma_2.get())
            mav = tuple([x for x in [ma1, ma2] if x and x > 0]) or None

            # mplfinance plot (returns fig + axes if returnfig=True)
            fig, axes = mpf.plot(
                self.df,
                type="candle",
                style=self.style.get(),
                volume=self.show_volume.get() and ("Volume" in self.df.columns),
                mav=mav,
                title="Candlestick Chart",
                ylabel="Price",
                ylabel_lower="Volume" if ("Volume" in self.df.columns and self.show_volume.get()) else "",
                returnfig=True
            )

            self.fig = fig

            # Embed in Tkinter
            self.canvas = FigureCanvasTkAgg(self.fig, master=self.plot_frame)
            self.canvas.draw()
            self.canvas.get_tk_widget().pack(fill="both", expand=True)

            self.toolbar = NavigationToolbar2Tk(self.canvas, self.plot_frame)
            self.toolbar.update()

            self.status.set("Done.")
        except Exception as e:
            self.status.set("Error drawing.")
            messagebox.showerror("Error", str(e))


if __name__ == "__main__":
    app = CandleGUI()
    app.mainloop()
