# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:10:39 2026

@author: Administrator
"""

"""
VOLATILITY PREDICTION WITH RANDOM FOREST (Regression) — Thesis-ready

Goal:
- Predict next-day volatility using a Random Forest regression model.

Key ideas:
- Volatility target (what we predict): next-day realized variance proxy = r_{t+1}^2
  where r_t is daily log return in percent.
- Features (inputs): lagged returns, lagged squared returns, rolling volatility,
  rolling mean returns, range-based measures, etc.

Data source:
- Primary: Stooq (spy.us) — reliable proxy for S&P 500
- Fallback: prices.csv with columns: Date, Open, High, Low, Close (at least Date, Close)

Install:
  pip install pandas numpy scikit-learn

Run:
  python rf_volatility_prediction.py

Outputs:
- Accuracy metrics on test set: MSE, MAE, RMSE, R^2
- Baseline comparison: "naive" forecast = yesterday's volatility
- CSV file with predictions: rf_vol_predictions.csv
"""

import numpy as np
import pandas as pd
from pathlib import Path

from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# ----------------------------
# 1) Settings
# ----------------------------
START_DATE = "2014-01-01"
END_DATE = "2024-01-01"                   # exclusive end
STOOQ_SYMBOL = "spy.us"
STOOQ_URL = f"https://stooq.com/q/d/l/?s={STOOQ_SYMBOL}&i=d"

CSV_FALLBACK = Path("prices.csv")         # Date, Open, High, Low, Close (or at least Date, Close)

TEST_SIZE = 252                           # last ~1 year as test set
RANDOM_STATE = 42

# Rolling windows
VOL_WIN_5 = 5
VOL_WIN_20 = 20
VOL_WIN_60 = 60

# Random Forest hyperparameters (simple but strong baseline)
RF_PARAMS = dict(
    n_estimators=500,
    max_depth=None,
    min_samples_split=10,
    min_samples_leaf=5,
    max_features="sqrt",
    bootstrap=True,
    n_jobs=-1,
    random_state=RANDOM_STATE
)

OUT_PRED_CSV = Path("rf_vol_predictions.csv")

# ----------------------------
# 2) Load data (Stooq -> CSV)
# ----------------------------
def load_ohlc() -> pd.DataFrame:
    # ---- Try Stooq ----
    try:
        print(f"Loading from Stooq: {STOOQ_URL}")
        df = pd.read_csv(STOOQ_URL)
        if df is None or df.empty:
            raise ValueError("Stooq returned empty.")

        # Stooq usually has Date, Open, High, Low, Close, Volume
        if "Date" not in df.columns or "Close" not in df.columns:
            raise ValueError(f"Unexpected Stooq columns: {list(df.columns)}")

        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df.dropna(subset=["Date"]).sort_values("Date")
        df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]

        # Keep what we have; if OHLC exists, keep all; else keep Date/Close
        cols = ["Date"]
        for c in ["Open", "High", "Low", "Close"]:
            if c in df.columns:
                cols.append(c)

        df = df[cols].dropna()

        if df.empty:
            raise ValueError("No rows in requested date range.")

        print(f"✅ Loaded {len(df)} rows from Stooq ({STOOQ_SYMBOL})")
        return df.reset_index(drop=True)

    except Exception as e:
        print(f"⚠ Stooq failed: {e}")
        print("Falling back to local CSV...")

    # ---- CSV fallback ----
    if not CSV_FALLBACK.exists():
        raise ValueError(
            f"[FATAL] Stooq failed and CSV fallback not found.\n"
            f"Create {CSV_FALLBACK.name} with columns: Date, Close (and optionally Open,High,Low)."
        )

    df = pd.read_csv(CSV_FALLBACK)
    colmap = {c.lower().strip(): c for c in df.columns}

    if "date" not in colmap or "close" not in colmap:
        raise ValueError(f"[FATAL] CSV must contain Date and Close. Found: {list(df.columns)}")

    rename = {colmap["date"]: "Date", colmap["close"]: "Close"}
    for k in ["open", "high", "low"]:
        if k in colmap:
            rename[colmap[k]] = k.capitalize()

    df = df.rename(columns=rename)
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]

    # Ensure required cols present
    keep = ["Date", "Close"] + [c for c in ["Open", "High", "Low"] if c in df.columns]
    df = df[keep].dropna()

    if df.empty:
        raise ValueError("[FATAL] CSV loaded but no rows in requested date range.")

    print(f"✅ Loaded {len(df)} rows from CSV fallback ({CSV_FALLBACK})")
    return df.reset_index(drop=True)


df = load_ohlc()

# Ensure numeric
for c in ["Open", "High", "Low", "Close"]:
    if c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.dropna(subset=["Close"]).copy()

# ----------------------------
# 3) Build returns and target volatility
# ----------------------------
# Percent log return: r_t = 100 * ln(C_t / C_{t-1})
df["r_pct"] = 100 * np.log(df["Close"] / df["Close"].shift(1))

# Realized variance proxy: RV_t = r_t^2 (percent^2)
df["rv"] = df["r_pct"] ** 2

# Target: next-day realized variance (predict rv_{t+1})
df["y_next_rv"] = df["rv"].shift(-1)

# ----------------------------
# 4) Build features (X)
# ----------------------------
# Lagged returns
df["r_lag1"] = df["r_pct"].shift(1)
df["r_lag2"] = df["r_pct"].shift(2)
df["r_lag5"] = df["r_pct"].shift(5)

# Lagged squared returns (captures volatility clustering)
df["rv_lag1"] = df["rv"].shift(1)
df["rv_lag2"] = df["rv"].shift(2)
df["rv_lag5"] = df["rv"].shift(5)

# Rolling volatility (std of returns) -> convert to variance proxy (std^2) to match scale
df["vol5"] = df["r_pct"].rolling(VOL_WIN_5).std(ddof=1)
df["vol20"] = df["r_pct"].rolling(VOL_WIN_20).std(ddof=1)
df["vol60"] = df["r_pct"].rolling(VOL_WIN_60).std(ddof=1)

df["vol5_sq"] = df["vol5"] ** 2
df["vol20_sq"] = df["vol20"] ** 2
df["vol60_sq"] = df["vol60"] ** 2

# Rolling mean return (market drift)
df["mean5"] = df["r_pct"].rolling(5).mean()
df["mean20"] = df["r_pct"].rolling(20).mean()

# Range-based features (only if OHLC available)
if all(c in df.columns for c in ["Open", "High", "Low", "Close"]):
    # True Range approx: High - Low (simple for daily)
    df["range"] = df["High"] - df["Low"]
    # Range scaled by close (percent)
    df["range_pct"] = 100 * (df["range"] / df["Close"])

    # Candle body (optional)
    df["body"] = (df["Close"] - df["Open"]).abs()
    df["body_pct"] = 100 * (df["body"] / df["Close"])

# Drop rows with any NaN in features or target
feature_cols = [
    "r_lag1", "r_lag2", "r_lag5",
    "rv_lag1", "rv_lag2", "rv_lag5",
    "vol5_sq", "vol20_sq", "vol60_sq",
    "mean5", "mean20"
]

if "range_pct" in df.columns:
    feature_cols += ["range_pct", "body_pct"]

df_model = df.dropna(subset=feature_cols + ["y_next_rv"]).copy()

if len(df_model) <= TEST_SIZE + 50:
    raise ValueError("[FATAL] Not enough rows after feature engineering. Reduce TEST_SIZE or shorten windows.")

# ----------------------------
# 5) Train/test split (time series)
# ----------------------------
train = df_model.iloc[:-TEST_SIZE].copy()
test = df_model.iloc[-TEST_SIZE:].copy()

X_train = train[feature_cols].values
y_train = train["y_next_rv"].values

X_test = test[feature_cols].values
y_test = test["y_next_rv"].values

print(f"\nTrain rows: {len(train)} | Test rows: {len(test)}")
print("Features used:", feature_cols)

# ----------------------------
# 6) Fit Random Forest model
# ----------------------------
rf = RandomForestRegressor(**RF_PARAMS)
rf.fit(X_train, y_train)

# Predict next-day variance
y_pred = rf.predict(X_test)

# ----------------------------
# 7) Evaluation (accuracy)
# ----------------------------
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

# Baseline: naive forecast = yesterday's variance (rv_lag1)
baseline_pred = test["rv_lag1"].values
mse_b = mean_squared_error(y_test, baseline_pred)
mae_b = mean_absolute_error(y_test, baseline_pred)
rmse_b = np.sqrt(mse_b)
r2_b = r2_score(y_test, baseline_pred)

print("\n=== RANDOM FOREST VOLATILITY PREDICTION (Target = next-day r^2) ===")
print(f"RF   MSE : {mse:.6f} | MAE : {mae:.6f} | RMSE : {rmse:.6f} | R^2 : {r2:.4f}")
print(f"BASE MSE : {mse_b:.6f} | MAE : {mae_b:.6f} | RMSE : {rmse_b:.6f} | R^2 : {r2_b:.4f}")

# Optional: QLIKE (commonly used in volatility forecasting)
# QLIKE = log(sigma^2_hat) + RV / sigma^2_hat
eps = 1e-12
rf_hat = np.clip(y_pred, eps, None)
base_hat = np.clip(baseline_pred, eps, None)

qlike_rf = float(np.mean(np.log(rf_hat) + (y_test / rf_hat)))
qlike_base = float(np.mean(np.log(base_hat) + (y_test / base_hat)))

print(f"RF   QLIKE: {qlike_rf:.6f}")
print(f"BASE QLIKE: {qlike_base:.6f}")

# ----------------------------
# 8) Save predictions
# ----------------------------
out = test[["Date", "Close"]].copy()
out["RV_true"] = y_test
out["RV_pred_RF"] = y_pred
out["RV_pred_Baseline"] = baseline_pred

# Convert variance (percent^2) -> daily volatility (percent) for interpretation
out["Vol_true_pct"] = np.sqrt(np.clip(out["RV_true"].values, 0, None))
out["Vol_pred_RF_pct"] = np.sqrt(np.clip(out["RV_pred_RF"].values, 0, None))
out["Vol_pred_Base_pct"] = np.sqrt(np.clip(out["RV_pred_Baseline"].values, 0, None))

out.to_csv(OUT_PRED_CSV, index=False)
print(f"\n✅ Saved predictions to: {OUT_PRED_CSV.resolve()}")

# ----------------------------
# 9) Feature importance (interpretation)
# ----------------------------
importances = pd.Series(rf.feature_importances_, index=feature_cols).sort_values(ascending=False)

print("\n=== Feature Importances (Random Forest) ===")
print(importances.round(4).to_string())
