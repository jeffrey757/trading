# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 08:59:24 2026

@author: Administrator
"""

"""
GARCH VOLATILITY FORECASTING (Practical, Thesis-ready)

This script:
1) Loads daily price data (Stooq first; CSV fallback)
2) Builds log returns
3) Fits a GARCH(1,1) model
4) Forecasts next N-day volatility (annualized + daily)
5) Prints results and optionally saves to CSV

INSTALL:
  pip install pandas numpy arch

DATA SOURCE:
- Primary: Stooq (direct CSV)
- Fallback: local CSV with columns: Date, Close  (or Date, Open, High, Low, Close)

NOTE:
- GARCH models are for volatility (conditional variance), NOT for price direction.
"""

import numpy as np
import pandas as pd
from pathlib import Path

from arch import arch_model

# ----------------------------
# 1) Settings
# ----------------------------
START_DATE = "2014-01-01"
END_DATE = "2024-01-01"  # exclusive end

# Use SPY (S&P 500 proxy) from Stooq; you can change to other Stooq symbols (e.g., 'eurusd', 'gold', etc.)
STOOQ_SYMBOL = "spy.us"
STOOQ_URL = f"https://stooq.com/q/d/l/?s={STOOQ_SYMBOL}&i=d"

# Local fallback CSV (only needed if Stooq is blocked)
# Must have at least: Date, Close
CSV_FALLBACK = Path("prices.csv")

# Forecast horizon
FORECAST_DAYS = 10

# ----------------------------
# 2) Data loading helpers
# ----------------------------
def load_prices() -> pd.DataFrame:
    """
    Returns DataFrame with columns: Date, Close
    Tries Stooq first; if blocked, loads from CSV_FALLBACK.
    """
    # ---- Try Stooq ----
    try:
        print(f"Loading from Stooq: {STOOQ_URL}")
        df = pd.read_csv(STOOQ_URL)
        if df is None or df.empty:
            raise ValueError("Stooq returned empty data.")

        # Stooq usually provides: Date, Open, High, Low, Close, Volume
        if "Date" not in df.columns or "Close" not in df.columns:
            raise ValueError(f"Stooq format unexpected. Columns: {list(df.columns)}")

        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df.dropna(subset=["Date"]).sort_values("Date")

        df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]
        df = df[["Date", "Close"]].dropna()

        if df.empty:
            raise ValueError("No rows in requested date range.")

        print(f"✅ Loaded {len(df)} rows from Stooq ({STOOQ_SYMBOL})")
        return df

    except Exception as e:
        print(f"⚠ Stooq failed: {e}")
        print("Falling back to local CSV...")

    # ---- Fallback CSV ----
    if not CSV_FALLBACK.exists():
        raise ValueError(
            f"[FATAL] Could not load from Stooq and CSV fallback not found.\n"
            f"Create {CSV_FALLBACK.name} with columns: Date, Close"
        )

    df = pd.read_csv(CSV_FALLBACK)
    # Flexible column matching
    colmap = {c.lower().strip(): c for c in df.columns}
    if "date" not in colmap or "close" not in colmap:
        raise ValueError(f"[FATAL] CSV must contain Date and Close. Found: {list(df.columns)}")

    df = df.rename(columns={colmap["date"]: "Date", colmap["close"]: "Close"})
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")

    df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]
    df = df[["Date", "Close"]].dropna()

    if df.empty:
        raise ValueError("[FATAL] CSV loaded but no rows in the requested date range.")

    print(f"✅ Loaded {len(df)} rows from CSV fallback ({CSV_FALLBACK})")
    return df


# ----------------------------
# 3) Build returns
# ----------------------------
prices = load_prices()

# Log returns: r_t = 100 * ln(Close_t / Close_{t-1})
# (Multiply by 100 because arch package often works well with returns in percent units.)
prices["log_return_pct"] = 100 * np.log(prices["Close"] / prices["Close"].shift(1))

# Drop first NaN return
rets = prices.dropna(subset=["log_return_pct"]).copy()
r = rets["log_return_pct"]

print("\nReturn series summary (percent log returns):")
print(r.describe())

# ----------------------------
# 4) Fit GARCH model
# ----------------------------
"""
Model choice:
- Mean: constant (mu)
- Volatility: GARCH(1,1) -> variance_t = omega + alpha * eps_{t-1}^2 + beta * variance_{t-1}
- Error distribution: Student's t (often fits fat tails better than Normal)
"""
model = arch_model(
    r,
    mean="Constant",     # constant mean
    vol="GARCH",         # GARCH family
    p=1, q=1,            # GARCH(1,1)
    dist="t"             # Student-t innovations
)

res = model.fit(disp="off")  # disp="off" hides optimizer output

print("\n=== GARCH(1,1) Fit Summary ===")
print(res.summary())

# ----------------------------
# 5) Forecast volatility
# ----------------------------
"""
Forecast returns:
- We forecast conditional variance for next FORECAST_DAYS.
- res.forecast(horizon=N) gives variance forecasts.
- Because returns are in percent units, variance is in (percent^2),
  and volatility (std dev) is in percent.
"""
fcst = res.forecast(horizon=FORECAST_DAYS, reindex=False)

# Extract the last row of variance forecasts (the most recent forecast origin)
# Result is a 1 x N DataFrame of variances
var_forecast = fcst.variance.iloc[-1]

# Convert variance -> daily volatility (std dev) in percent
daily_vol_pct = np.sqrt(var_forecast)

# Convert daily vol -> annualized vol using sqrt(252)
annualized_vol_pct = daily_vol_pct * np.sqrt(252)

# Build a nice output table
out = pd.DataFrame({
    "horizon_day": np.arange(1, FORECAST_DAYS + 1),
    "forecast_variance_(pct^2)": var_forecast.values,
    "forecast_daily_vol_(pct)": daily_vol_pct.values,
    "forecast_annualized_vol_(pct)": annualized_vol_pct.values
})

print("\n=== Volatility Forecast (GARCH) ===")
print(out.round(4).to_string(index=False))

# Optional: save forecast to CSV
OUT_CSV = Path("garch_vol_forecast.csv")
out.to_csv(OUT_CSV, index=False)
print(f"\n✅ Saved forecast table to: {OUT_CSV.resolve()}")

# ----------------------------
# 6) One-number forecast (common thesis reporting)
# ----------------------------
"""
Often you report the 1-day ahead annualized volatility estimate.
"""
one_day_ann_vol = float(out.loc[out["horizon_day"] == 1, "forecast_annualized_vol_(pct)"])
print(f"\n1-day ahead annualized volatility forecast: {one_day_ann_vol:.4f}%")
