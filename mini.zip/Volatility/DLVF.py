# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:31:14 2026

@author: Administrator
"""

"""
DEEP LEARNING VOLATILITY FORECASTING (GPU) — Temporal Convolutional Network (TCN)

Why TCN for volatility:
- Strong deep-learning baseline for time series forecasting
- Often trains faster and more stably than LSTM
- Captures long memory using dilated causal convolutions (good for volatility clustering)

Target:
- Next-day realized variance proxy: RV_{t+1} = r_{t+1}^2  (percent^2)

Inputs (sequence features):
- r_t (percent log return)
- r_t^2 (variance proxy)
- rolling variance (20-day mean of r^2)
- rolling volatility (20-day std of r)
- (optional) range_pct if OHLC exists

Evaluation:
- MSE / MAE / RMSE / R^2 on RV
- QLIKE (common volatility loss)
- Baseline: yesterday's RV (persistence model)

Install:
  pip install pandas numpy scikit-learn tensorflow

Data:
- Primary: Stooq (spy.us)
- Fallback: prices.csv with Date, Close (optional OHLC)

Run:
  python tcn_vol_forecast.py

Output:
- prints metrics
- saves predictions: tcn_vol_predictions.csv
"""

import numpy as np
import pandas as pd
from pathlib import Path

from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

import tensorflow as tf
from tensorflow.keras import layers, models, callbacks

# ----------------------------
# 1) Settings
# ----------------------------
START_DATE = "2014-01-01"
END_DATE = "2024-01-01"          # exclusive end
STOOQ_SYMBOL = "spy.us"
STOOQ_URL = f"https://stooq.com/q/d/l/?s={STOOQ_SYMBOL}&i=d"

CSV_FALLBACK = Path("prices.csv")

TEST_SIZE = 252                  # last ~1 year
LOOKBACK = 60                    # input sequence length
EPOCHS = 80
BATCH_SIZE = 128
RANDOM_SEED = 42

OUT_CSV = Path("tcn_vol_predictions.csv")

np.random.seed(RANDOM_SEED)
tf.random.set_seed(RANDOM_SEED)

# ----------------------------
# 2) GPU config (safe)
# ----------------------------
def configure_gpu():
    gpus = tf.config.list_physical_devices("GPU")
    if gpus:
        try:
            for g in gpus:
                tf.config.experimental.set_memory_growth(g, True)
        except Exception:
            pass
    return gpus

gpus = configure_gpu()
print("GPU detected by TensorFlow:" if gpus else "No GPU detected by TensorFlow (will use CPU).", gpus)

# ----------------------------
# 3) Load data (Stooq -> CSV)
# ----------------------------
def load_prices() -> pd.DataFrame:
    # --- Stooq ---
    try:
        print(f"Loading from Stooq: {STOOQ_URL}")
        df = pd.read_csv(STOOQ_URL)
        if df is None or df.empty:
            raise ValueError("Stooq returned empty.")
        if "Date" not in df.columns or "Close" not in df.columns:
            raise ValueError(f"Unexpected columns: {list(df.columns)}")

        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df.dropna(subset=["Date"]).sort_values("Date")
        df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]

        cols = ["Date"]
        for c in ["Open", "High", "Low", "Close"]:
            if c in df.columns:
                cols.append(c)
        df = df[cols].dropna().reset_index(drop=True)

        for c in ["Open", "High", "Low", "Close"]:
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="coerce")
        df = df.dropna(subset=["Close"]).reset_index(drop=True)

        if df.empty:
            raise ValueError("No rows after filtering / cleaning.")
        print(f"✅ Loaded {len(df)} rows from Stooq ({STOOQ_SYMBOL})")
        return df

    except Exception as e:
        print(f"⚠ Stooq failed: {e}")
        print("Falling back to local CSV...")

    # --- CSV fallback ---
    if not CSV_FALLBACK.exists():
        raise ValueError(
            f"[FATAL] Stooq failed and CSV fallback not found.\n"
            f"Create {CSV_FALLBACK.name} with columns: Date, Close (optional Open,High,Low)."
        )

    df = pd.read_csv(CSV_FALLBACK)
    colmap = {c.lower().strip(): c for c in df.columns}
    if "date" not in colmap or "close" not in colmap:
        raise ValueError(f"[FATAL] CSV must include Date and Close. Found: {list(df.columns)}")

    rename = {colmap["date"]: "Date", colmap["close"]: "Close"}
    for k in ["open", "high", "low"]:
        if k in colmap:
            rename[colmap[k]] = k.capitalize()
    df = df.rename(columns=rename)

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]

    keep = ["Date", "Close"] + [c for c in ["Open", "High", "Low"] if c in df.columns]
    df = df[keep].dropna().reset_index(drop=True)

    for c in ["Open", "High", "Low", "Close"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["Close"]).reset_index(drop=True)

    if df.empty:
        raise ValueError("[FATAL] CSV loaded but no rows in requested date range.")
    print(f"✅ Loaded {len(df)} rows from CSV fallback ({CSV_FALLBACK})")
    return df

df = load_prices()

# ----------------------------
# 4) Build features + target
# ----------------------------
df["r_pct"] = 100 * np.log(df["Close"] / df["Close"].shift(1))
df["rv"] = df["r_pct"] ** 2                       # RV proxy (percent^2)
df["rv_next"] = df["rv"].shift(-1)                # target

# Smooth / auxiliary volatility features
df["rv_roll20"] = df["rv"].rolling(20).mean()
df["vol_roll20"] = df["r_pct"].rolling(20).std(ddof=1)   # percent
df["vol_roll20_sq"] = df["vol_roll20"] ** 2              # percent^2

feature_cols = ["r_pct", "rv", "rv_roll20", "vol_roll20_sq"]

# Optional OHLC range feature
if all(c in df.columns for c in ["Open", "High", "Low", "Close"]):
    df["range"] = df["High"] - df["Low"]
    df["range_pct"] = 100 * (df["range"] / df["Close"])
    feature_cols += ["range_pct"]

df = df.dropna(subset=feature_cols + ["rv_next"]).reset_index(drop=True)

if len(df) <= TEST_SIZE + LOOKBACK + 200:
    raise ValueError("[FATAL] Not enough rows after feature engineering. Reduce TEST_SIZE/LOOKBACK or extend history.")

X = df[feature_cols].values
y = df["rv_next"].values
dates = df["Date"].values
closes = df["Close"].values

# ----------------------------
# 5) Build sequences
# ----------------------------
def make_sequences(X, y, dates, closes, lookback: int):
    Xs, ys, ds, cs = [], [], [], []
    for t in range(lookback - 1, len(X)):
        Xs.append(X[t - lookback + 1: t + 1])
        ys.append(y[t])
        ds.append(dates[t])
        cs.append(closes[t])
    return np.array(Xs), np.array(ys), np.array(ds), np.array(cs)

X_seq, y_seq, d_seq, c_seq = make_sequences(X, y, dates, closes, LOOKBACK)

# Time split
X_train, X_test = X_seq[:-TEST_SIZE], X_seq[-TEST_SIZE:]
y_train, y_test = y_seq[:-TEST_SIZE], y_seq[-TEST_SIZE:]
d_test = d_seq[-TEST_SIZE:]
c_test = c_seq[-TEST_SIZE:]

print(f"\nSequences: train={len(X_train)} test={len(X_test)} | shape={X_train.shape}")

# Scale features using train only
scaler = StandardScaler()
X_train_flat = X_train.reshape(-1, X_train.shape[-1])
scaler.fit(X_train_flat)

X_train_scaled = scaler.transform(X_train_flat).reshape(X_train.shape)
X_test_scaled = scaler.transform(X_test.reshape(-1, X_test.shape[-1])).reshape(X_test.shape)

# Baseline: persistence = last rv in sequence (feature index 1 is rv)
baseline_pred = X_test[:, -1, feature_cols.index("rv")]

# ----------------------------
# 6) Build a TCN-like model (causal dilated CNN)
# ----------------------------
def tcn_block(x, filters, kernel_size, dilation_rate, dropout):
    """
    One residual TCN block:
      - causal Conv1D with dilation
      - normalization + dropout
      - residual connection
    """
    prev = x

    x = layers.Conv1D(filters, kernel_size, padding="causal", dilation_rate=dilation_rate)(x)
    x = layers.LayerNormalization()(x)
    x = layers.Activation("relu")(x)
    x = layers.Dropout(dropout)(x)

    x = layers.Conv1D(filters, kernel_size, padding="causal", dilation_rate=dilation_rate)(x)
    x = layers.LayerNormalization()(x)
    x = layers.Activation("relu")(x)
    x = layers.Dropout(dropout)(x)

    # Match channels for residual if needed
    if prev.shape[-1] != filters:
        prev = layers.Conv1D(filters, 1, padding="same")(prev)

    x = layers.Add()([x, prev])
    x = layers.Activation("relu")(x)
    return x

inputs = layers.Input(shape=(LOOKBACK, X_train.shape[-1]))
x = inputs

# Dilations: 1,2,4,8,16,... gives long memory
for d_rate in [1, 2, 4, 8, 16]:
    x = tcn_block(x, filters=64, kernel_size=3, dilation_rate=d_rate, dropout=0.15)

x = layers.GlobalAveragePooling1D()(x)
x = layers.Dense(64, activation="relu")(x)
x = layers.Dropout(0.20)(x)

# Output must be positive variance -> softplus
outputs = layers.Dense(1, activation="softplus")(x)

model = models.Model(inputs, outputs)
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3), loss="mse")

cb = [
    callbacks.EarlyStopping(monitor="val_loss", patience=10, restore_best_weights=True),
    callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=5, min_lr=1e-5),
]

history = model.fit(
    X_train_scaled, y_train,
    validation_split=0.2,
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    verbose=1,
    callbacks=cb
)

# ----------------------------
# 7) Predict + evaluate
# ----------------------------
y_pred = model.predict(X_test_scaled, verbose=0).reshape(-1)

mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
rmse = float(np.sqrt(mse))
r2 = r2_score(y_test, y_pred)

mse_b = mean_squared_error(y_test, baseline_pred)
mae_b = mean_absolute_error(y_test, baseline_pred)
rmse_b = float(np.sqrt(mse_b))
r2_b = r2_score(y_test, baseline_pred)

# QLIKE
eps = 1e-12
y_pred_clip = np.clip(y_pred, eps, None)
y_test_clip = np.clip(y_test, eps, None)
qlike_tcn = float(np.mean(np.log(y_pred_clip) + (y_test_clip / y_pred_clip)))

base_clip = np.clip(baseline_pred, eps, None)
qlike_base = float(np.mean(np.log(base_clip) + (y_test_clip / base_clip)))

print("\n=== Deep Learning Volatility Forecast (TCN) ===")
print(f"TCN   MSE : {mse:.6f} | MAE : {mae:.6f} | RMSE : {rmse:.6f} | R^2 : {r2:.4f} | QLIKE: {qlike_tcn:.6f}")
print(f"BASE  MSE : {mse_b:.6f} | MAE : {mae_b:.6f} | RMSE : {rmse_b:.6f} | R^2 : {r2_b:.4f} | QLIKE: {qlike_base:.6f}")

# ----------------------------
# 8) Save predictions
# ----------------------------
out = pd.DataFrame({
    "Date": pd.to_datetime(d_test),
    "Close": c_test,
    "RV_true": y_test,
    "RV_pred_TCN": y_pred,
    "RV_pred_Baseline": baseline_pred
})

# Convert variance -> daily volatility (%)
out["Vol_true_pct"] = np.sqrt(np.clip(out["RV_true"].values, 0, None))
out["Vol_pred_TCN_pct"] = np.sqrt(np.clip(out["RV_pred_TCN"].values, 0, None))
out["Vol_pred_Base_pct"] = np.sqrt(np.clip(out["RV_pred_Baseline"].values, 0, None))

out.to_csv(OUT_CSV, index=False)
print(f"\n✅ Saved predictions to: {OUT_CSV.resolve()}")
