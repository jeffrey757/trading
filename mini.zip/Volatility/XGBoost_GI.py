# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:18:48 2026

@author: Administrator
"""

"""
VOLATILITY FORECASTING GUI (INPUT + OUTPUT) — Tkinter Desktop App

This GUI lets you:
- Choose a data source (Stooq symbol OR local CSV)
- Choose a model (ARCH, GARCH, Random Forest, XGBoost)
- Set key parameters (test size, lookback windows, etc.)
- Run the model and see:
    * Metrics table (MSE/MAE/RMSE/R2/QLIKE) vs baseline
    * A preview of predictions (Date, RV_true, RV_pred, Vol_true, Vol_pred)
- Export predictions to CSV

✅ Works offline if you use a CSV.
✅ Does NOT require yfinance.

INSTALL:
  pip install pandas numpy scikit-learn arch xgboost

RUN:
  python volatility_gui.py
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np
import pandas as pd
from pathlib import Path

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.ensemble import RandomForestRegressor

from arch import arch_model
from xgboost import XGBRegressor


# =========================
# Core utilities
# =========================
def qlike(y_true, y_hat, eps=1e-12):
    y_hat = np.clip(np.asarray(y_hat, dtype=float), eps, None)
    y_true = np.clip(np.asarray(y_true, dtype=float), eps, None)
    return float(np.mean(np.log(y_hat) + (y_true / y_hat)))

def make_features(df: pd.DataFrame,
                  vol_win_5=5, vol_win_20=20, vol_win_60=60) -> tuple[pd.DataFrame, list]:
    """
    Builds supervised dataset for ML models:
    Target: y_next_rv = r_{t+1}^2 (percent^2)
    Features: lags + rolling var/mean + optional range/body if OHLC exists.
    """
    df = df.copy()
    df["r_pct"] = 100 * np.log(df["Close"] / df["Close"].shift(1))
    df["rv"] = df["r_pct"] ** 2
    df["y_next_rv"] = df["rv"].shift(-1)

    # Lags
    df["r_lag1"] = df["r_pct"].shift(1)
    df["r_lag2"] = df["r_pct"].shift(2)
    df["r_lag5"] = df["r_pct"].shift(5)

    df["rv_lag1"] = df["rv"].shift(1)
    df["rv_lag2"] = df["rv"].shift(2)
    df["rv_lag5"] = df["rv"].shift(5)

    # Rolling vol -> variance proxy
    df["vol5"] = df["r_pct"].rolling(vol_win_5).std(ddof=1)
    df["vol20"] = df["r_pct"].rolling(vol_win_20).std(ddof=1)
    df["vol60"] = df["r_pct"].rolling(vol_win_60).std(ddof=1)

    df["vol5_sq"] = df["vol5"] ** 2
    df["vol20_sq"] = df["vol20"] ** 2
    df["vol60_sq"] = df["vol60"] ** 2

    df["mean5"] = df["r_pct"].rolling(5).mean()
    df["mean20"] = df["r_pct"].rolling(20).mean()

    feature_cols = [
        "r_lag1", "r_lag2", "r_lag5",
        "rv_lag1", "rv_lag2", "rv_lag5",
        "vol5_sq", "vol20_sq", "vol60_sq",
        "mean5", "mean20"
    ]

    # Optional OHLC features
    if all(c in df.columns for c in ["Open", "High", "Low", "Close"]):
        df["range"] = df["High"] - df["Low"]
        df["range_pct"] = 100 * (df["range"] / df["Close"])
        df["body"] = (df["Close"] - df["Open"]).abs()
        df["body_pct"] = 100 * (df["body"] / df["Close"])
        feature_cols += ["range_pct", "body_pct"]

    df_model = df.dropna(subset=feature_cols + ["y_next_rv"]).copy()
    return df_model, feature_cols

def load_data_stooq(symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
    """
    Loads from Stooq direct CSV.
    Example symbol: spy.us, ^spx, etc.
    """
    url = f"https://stooq.com/q/d/l/?s={symbol}&i=d"
    df = pd.read_csv(url)

    if df is None or df.empty:
        raise ValueError("Stooq returned empty data.")

    if "Date" not in df.columns or "Close" not in df.columns:
        raise ValueError(f"Unexpected Stooq columns: {list(df.columns)}")

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= start_date) & (df["Date"] < end_date)]

    cols = ["Date"]
    for c in ["Open", "High", "Low", "Close"]:
        if c in df.columns:
            cols.append(c)

    df = df[cols].dropna().reset_index(drop=True)

    for c in ["Open", "High", "Low", "Close"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["Close"]).reset_index(drop=True)

    if df.empty:
        raise ValueError("No rows after filtering date range / cleaning.")

    return df

def load_data_csv(csv_path: str, start_date: str, end_date: str) -> pd.DataFrame:
    """
    CSV must include at least: Date, Close
    Optional: Open, High, Low
    """
    p = Path(csv_path)
    if not p.exists():
        raise ValueError("CSV file not found.")

    df = pd.read_csv(p)
    colmap = {c.lower().strip(): c for c in df.columns}

    if "date" not in colmap or "close" not in colmap:
        raise ValueError(f"CSV must include Date and Close. Found: {list(df.columns)}")

    rename = {
        colmap["date"]: "Date",
        colmap["close"]: "Close"
    }
    for k in ["open", "high", "low"]:
        if k in colmap:
            rename[colmap[k]] = k.capitalize()

    df = df.rename(columns=rename)

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= start_date) & (df["Date"] < end_date)]

    keep = ["Date", "Close"] + [c for c in ["Open", "High", "Low"] if c in df.columns]
    df = df[keep].dropna().reset_index(drop=True)

    for c in ["Open", "High", "Low", "Close"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["Close"]).reset_index(drop=True)

    if df.empty:
        raise ValueError("No rows after filtering date range / cleaning.")

    return df


# =========================
# Model runners
# =========================
def run_arch_garch(df: pd.DataFrame, model_name: str, test_size: int, refit_every: int,
                   arch_q: int = 5) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Walk-forward 1-step-ahead variance forecasts.
    RV proxy = r^2 (percent^2).
    Models: ARCH(q) or GARCH(1,1)
    """
    d = df.copy()
    d["r_pct"] = 100 * np.log(d["Close"] / d["Close"].shift(1))
    d = d.dropna(subset=["r_pct"]).reset_index(drop=True)
    d["rv"] = d["r_pct"] ** 2

    if len(d) <= test_size + 100:
        raise ValueError("Not enough data for this test_size. Reduce test_size or use longer history.")

    start_test_idx = len(d) - test_size
    r = d["r_pct"]
    rv = d["rv"]
    dates = d["Date"]
    closes = d["Close"]

    def fit_model(train_returns: pd.Series):
        if model_name == "ARCH":
            m = arch_model(train_returns, mean="Constant", vol="ARCH", p=arch_q, dist="t")
        else:
            m = arch_model(train_returns, mean="Constant", vol="GARCH", p=1, q=1, dist="t")
        return m.fit(disp="off")

    def one_step_var(res):
        f = res.forecast(horizon=1, reindex=False)
        return float(f.variance.iloc[-1, 0])

    res_fit = None
    rows = []
    eps = 1e-12

    for i in range(start_test_idx, len(d)):
        train_slice = r.iloc[:i]
        if res_fit is None or ((i - start_test_idx) % refit_every == 0):
            res_fit = fit_model(train_slice)

        var_hat = one_step_var(res_fit)
        var_hat = max(var_hat, eps)

        rows.append({
            "Date": dates.iloc[i],
            "Close": closes.iloc[i],
            "RV_true": float(rv.iloc[i]),
            "RV_pred": var_hat,
        })

    pred = pd.DataFrame(rows)

    # Baseline: yesterday variance
    pred["RV_pred_baseline"] = pred["RV_true"].shift(1)
    pred = pred.dropna(subset=["RV_pred_baseline"]).reset_index(drop=True)

    # Convert to vol (%) for display
    pred["Vol_true_pct"] = np.sqrt(np.clip(pred["RV_true"], 0, None))
    pred["Vol_pred_pct"] = np.sqrt(np.clip(pred["RV_pred"], 0, None))
    pred["Vol_base_pct"] = np.sqrt(np.clip(pred["RV_pred_baseline"], 0, None))

    y = pred["RV_true"].values
    yhat = pred["RV_pred"].values
    ybase = pred["RV_pred_baseline"].values

    metrics = pd.DataFrame([{
        "Model": model_name,
        "MSE": mean_squared_error(y, yhat),
        "MAE": mean_absolute_error(y, yhat),
        "RMSE": float(np.sqrt(mean_squared_error(y, yhat))),
        "R2": r2_score(y, yhat),
        "QLIKE": qlike(y, yhat)
    }, {
        "Model": "Baseline (RV_{t-1})",
        "MSE": mean_squared_error(y, ybase),
        "MAE": mean_absolute_error(y, ybase),
        "RMSE": float(np.sqrt(mean_squared_error(y, ybase))),
        "R2": r2_score(y, ybase),
        "QLIKE": qlike(y, ybase)
    }])

    return metrics, pred


def run_ml(df: pd.DataFrame, model_name: str, test_size: int,
           rf_estimators: int = 500,
           xgb_estimators: int = 1500,
           xgb_lr: float = 0.03,
           xgb_depth: int = 4) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Train/test (time split) for Random Forest or XGBoost.
    Target: next-day RV (r_{t+1}^2).
    Baseline: RV_lag1
    """
    df_model, feat_cols = make_features(df)

    if len(df_model) <= test_size + 50:
        raise ValueError("Not enough rows after feature engineering. Reduce test_size or shorten windows.")

    train = df_model.iloc[:-test_size].copy()
    test = df_model.iloc[-test_size:].copy()

    X_train = train[feat_cols].values
    y_train = train["y_next_rv"].values

    X_test = test[feat_cols].values
    y_test = test["y_next_rv"].values

    if model_name == "RandomForest":
        model = RandomForestRegressor(
            n_estimators=rf_estimators,
            max_depth=None,
            min_samples_split=10,
            min_samples_leaf=5,
            max_features="sqrt",
            bootstrap=True,
            n_jobs=-1,
            random_state=42
        )
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

    elif model_name == "XGBoost":
        model = XGBRegressor(
            n_estimators=xgb_estimators,
            learning_rate=xgb_lr,
            max_depth=xgb_depth,
            subsample=0.8,
            colsample_bytree=0.8,
            objective="reg:squarederror",
            random_state=42,
            n_jobs=-1
        )
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

    else:
        raise ValueError("Unknown ML model.")

    baseline_pred = test["rv_lag1"].values

    # predictions table
    pred = pd.DataFrame({
        "Date": test["Date"].values,
        "Close": test["Close"].values,
        "RV_true": y_test,
        "RV_pred": y_pred,
        "RV_pred_baseline": baseline_pred
    })

    pred["Vol_true_pct"] = np.sqrt(np.clip(pred["RV_true"], 0, None))
    pred["Vol_pred_pct"] = np.sqrt(np.clip(pred["RV_pred"], 0, None))
    pred["Vol_base_pct"] = np.sqrt(np.clip(pred["RV_pred_baseline"], 0, None))

    # metrics
    metrics = pd.DataFrame([{
        "Model": model_name,
        "MSE": mean_squared_error(y_test, y_pred),
        "MAE": mean_absolute_error(y_test, y_pred),
        "RMSE": float(np.sqrt(mean_squared_error(y_test, y_pred))),
        "R2": r2_score(y_test, y_pred),
        "QLIKE": qlike(y_test, y_pred)
    }, {
        "Model": "Baseline (RV_{t-1})",
        "MSE": mean_squared_error(y_test, baseline_pred),
        "MAE": mean_absolute_error(y_test, baseline_pred),
        "RMSE": float(np.sqrt(mean_squared_error(y_test, baseline_pred))),
        "R2": r2_score(y_test, baseline_pred),
        "QLIKE": qlike(y_test, baseline_pred)
    }])

    return metrics, pred


# =========================
# GUI App
# =========================
class VolatilityGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Volatility Prediction GUI (ARCH/GARCH/RF/XGBoost)")
        self.geometry("1180x720")

        self.csv_path = tk.StringVar(value="")
        self.data_source = tk.StringVar(value="Stooq")
        self.stooq_symbol = tk.StringVar(value="spy.us")
        self.start_date = tk.StringVar(value="2014-01-01")
        self.end_date = tk.StringVar(value="2024-01-01")

        self.model_choice = tk.StringVar(value="GARCH")
        self.test_size = tk.IntVar(value=252)
        self.refit_every = tk.IntVar(value=20)
        self.arch_q = tk.IntVar(value=5)

        self.rf_estimators = tk.IntVar(value=500)
        self.xgb_estimators = tk.IntVar(value=1500)
        self.xgb_lr = tk.DoubleVar(value=0.03)
        self.xgb_depth = tk.IntVar(value=4)

        self.pred_df = None
        self.metrics_df = None

        self._build_ui()

    def _build_ui(self):
        # ---- Top controls ----
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")

        # Data source
        ttk.Label(top, text="Data Source:").grid(row=0, column=0, sticky="w")
        ds = ttk.Combobox(top, textvariable=self.data_source, values=["Stooq", "CSV"], width=10, state="readonly")
        ds.grid(row=0, column=1, sticky="w", padx=6)
        ds.bind("<<ComboboxSelected>>", lambda e: self._toggle_data_inputs())

        ttk.Label(top, text="Stooq Symbol:").grid(row=0, column=2, sticky="w")
        ttk.Entry(top, textvariable=self.stooq_symbol, width=12).grid(row=0, column=3, sticky="w", padx=6)

        ttk.Label(top, text="CSV File:").grid(row=0, column=4, sticky="w")
        self.csv_entry = ttk.Entry(top, textvariable=self.csv_path, width=40)
        self.csv_entry.grid(row=0, column=5, sticky="w", padx=6)
        ttk.Button(top, text="Browse", command=self._browse_csv).grid(row=0, column=6, sticky="w")

        ttk.Label(top, text="Start:").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.start_date, width=12).grid(row=1, column=1, sticky="w", padx=6, pady=(8, 0))

        ttk.Label(top, text="End:").grid(row=1, column=2, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.end_date, width=12).grid(row=1, column=3, sticky="w", padx=6, pady=(8, 0))

        ttk.Label(top, text="Model:").grid(row=1, column=4, sticky="w", pady=(8, 0))
        model_cb = ttk.Combobox(top, textvariable=self.model_choice,
                                values=["ARCH", "GARCH", "RandomForest", "XGBoost"],
                                width=14, state="readonly")
        model_cb.grid(row=1, column=5, sticky="w", padx=6, pady=(8, 0))
        model_cb.bind("<<ComboboxSelected>>", lambda e: self._toggle_model_inputs())

        ttk.Button(top, text="Run", command=self._run).grid(row=1, column=6, sticky="w", pady=(8, 0))

        # ---- Parameter panel ----
        params = ttk.LabelFrame(self, text="Parameters", padding=10)
        params.pack(fill="x", padx=10)

        ttk.Label(params, text="Test size (days):").grid(row=0, column=0, sticky="w")
        ttk.Entry(params, textvariable=self.test_size, width=10).grid(row=0, column=1, sticky="w", padx=6)

        # ARCH/GARCH params
        self.arch_frame = ttk.Frame(params)
        self.arch_frame.grid(row=0, column=2, columnspan=4, sticky="w")

        ttk.Label(self.arch_frame, text="ARCH q:").grid(row=0, column=0, sticky="w")
        ttk.Entry(self.arch_frame, textvariable=self.arch_q, width=6).grid(row=0, column=1, sticky="w", padx=6)

        ttk.Label(self.arch_frame, text="Refit every (days):").grid(row=0, column=2, sticky="w")
        ttk.Entry(self.arch_frame, textvariable=self.refit_every, width=6).grid(row=0, column=3, sticky="w", padx=6)

        # RF params
        self.rf_frame = ttk.Frame(params)
        self.rf_frame.grid(row=1, column=0, columnspan=6, sticky="w", pady=(8, 0))

        ttk.Label(self.rf_frame, text="RF estimators:").grid(row=0, column=0, sticky="w")
        ttk.Entry(self.rf_frame, textvariable=self.rf_estimators, width=8).grid(row=0, column=1, sticky="w", padx=6)

        # XGB params
        self.xgb_frame = ttk.Frame(params)
        self.xgb_frame.grid(row=2, column=0, columnspan=6, sticky="w", pady=(8, 0))

        ttk.Label(self.xgb_frame, text="XGB estimators:").grid(row=0, column=0, sticky="w")
        ttk.Entry(self.xgb_frame, textvariable=self.xgb_estimators, width=8).grid(row=0, column=1, sticky="w", padx=6)

        ttk.Label(self.xgb_frame, text="Learning rate:").grid(row=0, column=2, sticky="w")
        ttk.Entry(self.xgb_frame, textvariable=self.xgb_lr, width=8).grid(row=0, column=3, sticky="w", padx=6)

        ttk.Label(self.xgb_frame, text="Max depth:").grid(row=0, column=4, sticky="w")
        ttk.Entry(self.xgb_frame, textvariable=self.xgb_depth, width=8).grid(row=0, column=5, sticky="w", padx=6)

        # ---- Output area ----
        out = ttk.Frame(self, padding=10)
        out.pack(fill="both", expand=True)

        # Metrics table
        metrics_box = ttk.LabelFrame(out, text="Metrics (Lower is better for MSE/MAE/RMSE/QLIKE)", padding=8)
        metrics_box.pack(fill="x")

        self.metrics_tree = ttk.Treeview(metrics_box, columns=("Model", "MSE", "MAE", "RMSE", "R2", "QLIKE"),
                                         show="headings", height=4)
        for col in ("Model", "MSE", "MAE", "RMSE", "R2", "QLIKE"):
            self.metrics_tree.heading(col, text=col)
            self.metrics_tree.column(col, width=160 if col == "Model" else 130, anchor="center")
        self.metrics_tree.pack(fill="x")

        # Predictions table
        pred_box = ttk.LabelFrame(out, text="Predictions preview (first 40 rows of test output)", padding=8)
        pred_box.pack(fill="both", expand=True, pady=(10, 0))

        self.pred_tree = ttk.Treeview(
            pred_box,
            columns=("Date", "Close", "RV_true", "RV_pred", "Vol_true_pct", "Vol_pred_pct"),
            show="headings",
            height=14
        )
        for col, w in [("Date", 160), ("Close", 120), ("RV_true", 140), ("RV_pred", 140), ("Vol_true_pct", 140), ("Vol_pred_pct", 140)]:
            self.pred_tree.heading(col, text=col)
            self.pred_tree.column(col, width=w, anchor="center")
        self.pred_tree.pack(fill="both", expand=True)

        # Buttons
        btns = ttk.Frame(out)
        btns.pack(fill="x", pady=8)
        ttk.Button(btns, text="Export predictions to CSV", command=self._export_predictions).pack(side="left")
        ttk.Button(btns, text="Clear output", command=self._clear_output).pack(side="left", padx=8)

        self._toggle_data_inputs()
        self._toggle_model_inputs()

    def _toggle_data_inputs(self):
        is_csv = (self.data_source.get() == "CSV")
        self.csv_entry.configure(state="normal" if is_csv else "disabled")

    def _toggle_model_inputs(self):
        m = self.model_choice.get()

        # Show ARCH/GARCH params only when relevant
        show_arch = m in ["ARCH", "GARCH"]
        show_rf = m == "RandomForest"
        show_xgb = m == "XGBoost"

        self.arch_frame.grid_remove() if not show_arch else self.arch_frame.grid()
        self.rf_frame.grid_remove() if not show_rf else self.rf_frame.grid()
        self.xgb_frame.grid_remove() if not show_xgb else self.xgb_frame.grid()

    def _browse_csv(self):
        path = filedialog.askopenfilename(
            title="Select CSV file",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if path:
            self.csv_path.set(path)
            self.data_source.set("CSV")
            self._toggle_data_inputs()

    def _clear_output(self):
        for t in self.metrics_tree.get_children():
            self.metrics_tree.delete(t)
        for t in self.pred_tree.get_children():
            self.pred_tree.delete(t)
        self.pred_df = None
        self.metrics_df = None

    def _load_data(self) -> pd.DataFrame:
        start = self.start_date.get().strip()
        end = self.end_date.get().strip()

        if self.data_source.get() == "Stooq":
            sym = self.stooq_symbol.get().strip()
            if not sym:
                raise ValueError("Stooq symbol is empty.")
            return load_data_stooq(sym, start, end)

        # CSV
        path = self.csv_path.get().strip()
        if not path:
            raise ValueError("CSV path is empty.")
        return load_data_csv(path, start, end)

    def _run(self):
        self._clear_output()

        try:
            df = self._load_data()
            model = self.model_choice.get()
            test_size = int(self.test_size.get())

            if model in ["ARCH", "GARCH"]:
                refit_every = int(self.refit_every.get())
                arch_q = int(self.arch_q.get())
                metrics, pred = run_arch_garch(df, model, test_size, refit_every, arch_q=arch_q)
            elif model == "RandomForest":
                metrics, pred = run_ml(df, "RandomForest", test_size, rf_estimators=int(self.rf_estimators.get()))
            else:  # XGBoost
                metrics, pred = run_ml(
                    df, "XGBoost", test_size,
                    xgb_estimators=int(self.xgb_estimators.get()),
                    xgb_lr=float(self.xgb_lr.get()),
                    xgb_depth=int(self.xgb_depth.get())
                )

            self.metrics_df = metrics
            self.pred_df = pred

            self._render_metrics(metrics)
            self._render_predictions(pred)

            messagebox.showinfo("Done", "Model run completed successfully.")

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _render_metrics(self, metrics: pd.DataFrame):
        for _, row in metrics.iterrows():
            self.metrics_tree.insert("", "end", values=(
                str(row["Model"]),
                f"{row['MSE']:.6f}",
                f"{row['MAE']:.6f}",
                f"{row['RMSE']:.6f}",
                f"{row['R2']:.4f}",
                f"{row['QLIKE']:.6f}",
            ))

    def _render_predictions(self, pred: pd.DataFrame):
        show = pred.head(40).copy()
        show["Date"] = pd.to_datetime(show["Date"]).dt.strftime("%Y-%m-%d")

        for _, row in show.iterrows():
            self.pred_tree.insert("", "end", values=(
                row["Date"],
                f"{row['Close']:.2f}",
                f"{row['RV_true']:.6f}",
                f"{row['RV_pred']:.6f}",
                f"{row['Vol_true_pct']:.4f}",
                f"{row['Vol_pred_pct']:.4f}",
            ))

    def _export_predictions(self):
        if self.pred_df is None or self.pred_df.empty:
            messagebox.showwarning("No data", "Run a model first to generate predictions.")
            return

        path = filedialog.asksaveasfilename(
            title="Save predictions CSV",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")]
        )
        if not path:
            return

        try:
            self.pred_df.to_csv(path, index=False)
            messagebox.showinfo("Saved", f"Predictions saved to:\n{path}")
        except Exception as e:
            messagebox.showerror("Error", str(e))


if __name__ == "__main__":
    app = VolatilityGUI()
    app.mainloop()
