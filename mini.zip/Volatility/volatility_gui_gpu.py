# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:22:35 2026

@author: Administrator
"""

"""
VOLATILITY PREDICTION GUI (GPU-READY) — Tkinter App
Models: ARCH, GARCH, RandomForest, XGBoost, LSTM (GPU)

What you get:
- Input controls (data source, dates, model, parameters)
- Output tables (metrics + prediction preview)
- Export predictions to CSV
- LSTM training runs on GPU automatically (if TensorFlow sees your GPU)
- Training progress bar + live status (epoch/val_loss)

INSTALL (GPU):
  pip install pandas numpy scikit-learn arch xgboost tensorflow

RUN:
  python volatility_gui_gpu.py

DATA:
- Stooq symbol (default: spy.us) OR local CSV.
- CSV must include: Date, Close (optional: Open, High, Low)
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import queue
from dataclasses import dataclass

import numpy as np
import pandas as pd
from pathlib import Path

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.ensemble import RandomForestRegressor

from arch import arch_model
from xgboost import XGBRegressor

# TensorFlow (GPU if available)
import tensorflow as tf
from tensorflow.keras import layers, models, callbacks
from sklearn.preprocessing import StandardScaler


# =========================
# Math utilities
# =========================
def qlike(y_true, y_hat, eps=1e-12):
    y_hat = np.clip(np.asarray(y_hat, dtype=float), eps, None)
    y_true = np.clip(np.asarray(y_true, dtype=float), eps, None)
    return float(np.mean(np.log(y_hat) + (y_true / y_hat)))


# =========================
# Data loading
# =========================
def load_data_stooq(symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
    url = f"https://stooq.com/q/d/l/?s={symbol}&i=d"
    df = pd.read_csv(url)

    if df is None or df.empty:
        raise ValueError("Stooq returned empty data.")
    if "Date" not in df.columns or "Close" not in df.columns:
        raise ValueError(f"Unexpected Stooq columns: {list(df.columns)}")

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= start_date) & (df["Date"] < end_date)]

    cols = ["Date"]
    for c in ["Open", "High", "Low", "Close"]:
        if c in df.columns:
            cols.append(c)
    df = df[cols].dropna().reset_index(drop=True)

    for c in ["Open", "High", "Low", "Close"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["Close"]).reset_index(drop=True)

    if df.empty:
        raise ValueError("No rows after filtering date range / cleaning.")
    return df


def load_data_csv(csv_path: str, start_date: str, end_date: str) -> pd.DataFrame:
    p = Path(csv_path)
    if not p.exists():
        raise ValueError("CSV file not found.")

    df = pd.read_csv(p)
    colmap = {c.lower().strip(): c for c in df.columns}
    if "date" not in colmap or "close" not in colmap:
        raise ValueError(f"CSV must include Date and Close. Found: {list(df.columns)}")

    rename = {colmap["date"]: "Date", colmap["close"]: "Close"}
    for k in ["open", "high", "low"]:
        if k in colmap:
            rename[colmap[k]] = k.capitalize()

    df = df.rename(columns=rename)
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= start_date) & (df["Date"] < end_date)]

    keep = ["Date", "Close"] + [c for c in ["Open", "High", "Low"] if c in df.columns]
    df = df[keep].dropna().reset_index(drop=True)

    for c in ["Open", "High", "Low", "Close"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["Close"]).reset_index(drop=True)

    if df.empty:
        raise ValueError("No rows after filtering date range / cleaning.")
    return df


# =========================
# Feature engineering (ML/LSTM)
# =========================
def make_features(df: pd.DataFrame,
                  vol_win_5=5, vol_win_20=20, vol_win_60=60) -> tuple[pd.DataFrame, list]:
    """
    Supervised dataset for ML models:
    - returns in percent: r_t = 100 * ln(C_t/C_{t-1})
    - realized variance proxy: rv_t = r_t^2
    - target: y_next_rv = rv_{t+1}
    """
    d = df.copy()
    d["r_pct"] = 100 * np.log(d["Close"] / d["Close"].shift(1))
    d["rv"] = d["r_pct"] ** 2
    d["y_next_rv"] = d["rv"].shift(-1)

    d["r_lag1"] = d["r_pct"].shift(1)
    d["r_lag2"] = d["r_pct"].shift(2)
    d["r_lag5"] = d["r_pct"].shift(5)

    d["rv_lag1"] = d["rv"].shift(1)
    d["rv_lag2"] = d["rv"].shift(2)
    d["rv_lag5"] = d["rv"].shift(5)

    d["vol5"] = d["r_pct"].rolling(vol_win_5).std(ddof=1)
    d["vol20"] = d["r_pct"].rolling(vol_win_20).std(ddof=1)
    d["vol60"] = d["r_pct"].rolling(vol_win_60).std(ddof=1)

    d["vol5_sq"] = d["vol5"] ** 2
    d["vol20_sq"] = d["vol20"] ** 2
    d["vol60_sq"] = d["vol60"] ** 2

    d["mean5"] = d["r_pct"].rolling(5).mean()
    d["mean20"] = d["r_pct"].rolling(20).mean()

    feature_cols = [
        "r_lag1", "r_lag2", "r_lag5",
        "rv_lag1", "rv_lag2", "rv_lag5",
        "vol5_sq", "vol20_sq", "vol60_sq",
        "mean5", "mean20"
    ]

    if all(c in d.columns for c in ["Open", "High", "Low", "Close"]):
        d["range"] = d["High"] - d["Low"]
        d["range_pct"] = 100 * (d["range"] / d["Close"])
        d["body"] = (d["Close"] - d["Open"]).abs()
        d["body_pct"] = 100 * (d["body"] / d["Close"])
        feature_cols += ["range_pct", "body_pct"]

    d_model = d.dropna(subset=feature_cols + ["y_next_rv"]).copy()
    return d_model, feature_cols


def make_lstm_sequences(df: pd.DataFrame, lookback: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    LSTM features:
      - r_pct, rv, rv_roll20
    Target:
      - rv_next
    """
    d = df.copy()
    d["r_pct"] = 100 * np.log(d["Close"] / d["Close"].shift(1))
    d["rv"] = d["r_pct"] ** 2
    d["rv_next"] = d["rv"].shift(-1)
    d["rv_roll20"] = d["rv"].rolling(20).mean()
    d = d.dropna(subset=["r_pct", "rv", "rv_next", "rv_roll20"]).reset_index(drop=True)

    feats = d[["r_pct", "rv", "rv_roll20"]].values
    y = d["rv_next"].values
    dates = d["Date"].values
    closes = d["Close"].values

    X_seq, y_seq, d_seq, c_seq = [], [], [], []
    for t in range(lookback - 1, len(d)):
        X_seq.append(feats[t - lookback + 1: t + 1])
        y_seq.append(y[t])
        d_seq.append(dates[t])
        c_seq.append(closes[t])

    return np.array(X_seq), np.array(y_seq), np.array(d_seq), np.array(c_seq)


# =========================
# Model runners
# =========================
def run_arch_garch(df: pd.DataFrame, model_name: str, test_size: int, refit_every: int, arch_q: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    d = df.copy()
    d["r_pct"] = 100 * np.log(d["Close"] / d["Close"].shift(1))
    d = d.dropna(subset=["r_pct"]).reset_index(drop=True)
    d["rv"] = d["r_pct"] ** 2

    if len(d) <= test_size + 120:
        raise ValueError("Not enough data. Reduce test_size or extend history.")

    start_test_idx = len(d) - test_size
    r = d["r_pct"]
    rv = d["rv"]
    dates = d["Date"]
    closes = d["Close"]

    def fit_model(train_returns: pd.Series):
        if model_name == "ARCH":
            m = arch_model(train_returns, mean="Constant", vol="ARCH", p=arch_q, dist="t")
        else:
            m = arch_model(train_returns, mean="Constant", vol="GARCH", p=1, q=1, dist="t")
        return m.fit(disp="off")

    def one_step_var(res):
        f = res.forecast(horizon=1, reindex=False)
        return float(f.variance.iloc[-1, 0])

    eps = 1e-12
    res_fit = None
    rows = []

    for i in range(start_test_idx, len(d)):
        train_slice = r.iloc[:i]
        if res_fit is None or ((i - start_test_idx) % refit_every == 0):
            res_fit = fit_model(train_slice)

        var_hat = max(one_step_var(res_fit), eps)

        rows.append({
            "Date": dates.iloc[i],
            "Close": closes.iloc[i],
            "RV_true": float(rv.iloc[i]),
            "RV_pred": var_hat,
        })

    pred = pd.DataFrame(rows)
    pred["RV_pred_baseline"] = pred["RV_true"].shift(1)
    pred = pred.dropna(subset=["RV_pred_baseline"]).reset_index(drop=True)

    pred["Vol_true_pct"] = np.sqrt(np.clip(pred["RV_true"], 0, None))
    pred["Vol_pred_pct"] = np.sqrt(np.clip(pred["RV_pred"], 0, None))
    pred["Vol_base_pct"] = np.sqrt(np.clip(pred["RV_pred_baseline"], 0, None))

    y = pred["RV_true"].values
    yhat = pred["RV_pred"].values
    ybase = pred["RV_pred_baseline"].values

    metrics = pd.DataFrame([{
        "Model": model_name,
        "MSE": mean_squared_error(y, yhat),
        "MAE": mean_absolute_error(y, yhat),
        "RMSE": float(np.sqrt(mean_squared_error(y, yhat))),
        "R2": r2_score(y, yhat),
        "QLIKE": qlike(y, yhat)
    }, {
        "Model": "Baseline (RV_{t-1})",
        "MSE": mean_squared_error(y, ybase),
        "MAE": mean_absolute_error(y, ybase),
        "RMSE": float(np.sqrt(mean_squared_error(y, ybase))),
        "R2": r2_score(y, ybase),
        "QLIKE": qlike(y, ybase)
    }])

    return metrics, pred


def run_ml(df: pd.DataFrame, model_name: str, test_size: int,
           rf_estimators: int, xgb_estimators: int, xgb_lr: float, xgb_depth: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    d_model, feat_cols = make_features(df)

    if len(d_model) <= test_size + 80:
        raise ValueError("Not enough data after feature engineering. Reduce test_size or shorten windows.")

    train = d_model.iloc[:-test_size].copy()
    test = d_model.iloc[-test_size:].copy()

    X_train = train[feat_cols].values
    y_train = train["y_next_rv"].values
    X_test = test[feat_cols].values
    y_test = test["y_next_rv"].values

    if model_name == "RandomForest":
        model = RandomForestRegressor(
            n_estimators=rf_estimators,
            max_depth=None,
            min_samples_split=10,
            min_samples_leaf=5,
            max_features="sqrt",
            bootstrap=True,
            n_jobs=-1,
            random_state=42
        )
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

    elif model_name == "XGBoost":
        model = XGBRegressor(
            n_estimators=xgb_estimators,
            learning_rate=xgb_lr,
            max_depth=xgb_depth,
            subsample=0.8,
            colsample_bytree=0.8,
            objective="reg:squarederror",
            random_state=42,
            n_jobs=-1
        )
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
    else:
        raise ValueError("Unknown ML model.")

    baseline_pred = test["rv_lag1"].values

    pred = pd.DataFrame({
        "Date": test["Date"].values,
        "Close": test["Close"].values,
        "RV_true": y_test,
        "RV_pred": y_pred,
        "RV_pred_baseline": baseline_pred
    })

    pred["Vol_true_pct"] = np.sqrt(np.clip(pred["RV_true"], 0, None))
    pred["Vol_pred_pct"] = np.sqrt(np.clip(pred["RV_pred"], 0, None))
    pred["Vol_base_pct"] = np.sqrt(np.clip(pred["RV_pred_baseline"], 0, None))

    metrics = pd.DataFrame([{
        "Model": model_name,
        "MSE": mean_squared_error(y_test, y_pred),
        "MAE": mean_absolute_error(y_test, y_pred),
        "RMSE": float(np.sqrt(mean_squared_error(y_test, y_pred))),
        "R2": r2_score(y_test, y_pred),
        "QLIKE": qlike(y_test, y_pred)
    }, {
        "Model": "Baseline (RV_{t-1})",
        "MSE": mean_squared_error(y_test, baseline_pred),
        "MAE": mean_absolute_error(y_test, baseline_pred),
        "RMSE": float(np.sqrt(mean_squared_error(y_test, baseline_pred))),
        "R2": r2_score(y_test, baseline_pred),
        "QLIKE": qlike(y_test, baseline_pred)
    }])

    return metrics, pred


class GUITrainCallback(callbacks.Callback):
    """
    Sends epoch progress to the GUI via a queue (thread-safe).
    """
    def __init__(self, q: queue.Queue, total_epochs: int):
        super().__init__()
        self.q = q
        self.total_epochs = total_epochs

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        self.q.put({
            "type": "lstm_epoch",
            "epoch": int(epoch) + 1,
            "total": int(self.total_epochs),
            "loss": float(logs.get("loss", np.nan)),
            "val_loss": float(logs.get("val_loss", np.nan)),
        })


def configure_gpu():
    """
    Best practice: enable memory growth so TF doesn't grab all VRAM at once.
    """
    gpus = tf.config.list_physical_devices("GPU")
    if gpus:
        try:
            for gpu in gpus:
                tf.config.experimental.set_memory_growth(gpu, True)
        except Exception:
            pass
    return gpus


def run_lstm(df: pd.DataFrame,
             test_size: int,
             lookback: int,
             epochs: int,
             batch_size: int,
             units1: int,
             units2: int,
             dropout: float,
             lr: float,
             q_gui: queue.Queue | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    LSTM predicts next-day RV (variance proxy).
    Baseline: last RV in the sequence (yesterday variance).
    """
    # GPU config (safe even on CPU)
    gpus = configure_gpu()

    X_seq, y_seq, d_seq, c_seq = make_lstm_sequences(df, lookback=lookback)

    if len(X_seq) <= test_size + 200:
        raise ValueError("Not enough sequences. Reduce test_size or lookback, or extend data range.")

    X_train, X_test = X_seq[:-test_size], X_seq[-test_size:]
    y_train, y_test = y_seq[:-test_size], y_seq[-test_size:]
    d_test = d_seq[-test_size:]
    c_test = c_seq[-test_size:]

    # Scale features using training data only
    scaler = StandardScaler()
    X_train_flat = X_train.reshape(-1, X_train.shape[-1])
    scaler.fit(X_train_flat)

    X_train_scaled = scaler.transform(X_train_flat).reshape(X_train.shape)
    X_test_scaled = scaler.transform(X_test.reshape(-1, X_test.shape[-1])).reshape(X_test.shape)

    # Baseline: last rv in sequence (feature index 1 is rv)
    baseline_pred = X_test[:, -1, 1]

    # Build model
    model = models.Sequential([
        layers.Input(shape=(lookback, X_train.shape[-1])),
        layers.LSTM(units1, return_sequences=True),
        layers.Dropout(dropout),
        layers.LSTM(units2, return_sequences=False),
        layers.Dropout(dropout),
        layers.Dense(32, activation="relu"),
        layers.Dense(1, activation="softplus")  # > 0
    ])
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr), loss="mse")

    cb_list = [
        callbacks.EarlyStopping(monitor="val_loss", patience=10, restore_best_weights=True),
        callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=5, min_lr=1e-5),
    ]
    if q_gui is not None:
        cb_list.append(GUITrainCallback(q_gui, total_epochs=epochs))

    # Fit (still in worker thread)
    model.fit(
        X_train_scaled, y_train,
        validation_split=0.2,
        epochs=epochs,
        batch_size=batch_size,
        verbose=0,
        callbacks=cb_list
    )

    # Predict
    y_pred = model.predict(X_test_scaled, verbose=0).reshape(-1)

    # Metrics
    mse = mean_squared_error(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = float(np.sqrt(mse))
    r2 = r2_score(y_test, y_pred)
    ql = qlike(y_test, y_pred)

    mse_b = mean_squared_error(y_test, baseline_pred)
    mae_b = mean_absolute_error(y_test, baseline_pred)
    rmse_b = float(np.sqrt(mse_b))
    r2_b = r2_score(y_test, baseline_pred)
    ql_b = qlike(y_test, baseline_pred)

    metrics = pd.DataFrame([{
        "Model": f"LSTM ({'GPU' if gpus else 'CPU'})",
        "MSE": mse,
        "MAE": mae,
        "RMSE": rmse,
        "R2": r2,
        "QLIKE": ql
    }, {
        "Model": "Baseline (RV_{t-1})",
        "MSE": mse_b,
        "MAE": mae_b,
        "RMSE": rmse_b,
        "R2": r2_b,
        "QLIKE": ql_b
    }])

    pred = pd.DataFrame({
        "Date": pd.to_datetime(d_test),
        "Close": c_test,
        "RV_true": y_test,
        "RV_pred": y_pred,
        "RV_pred_baseline": baseline_pred
    })

    pred["Vol_true_pct"] = np.sqrt(np.clip(pred["RV_true"], 0, None))
    pred["Vol_pred_pct"] = np.sqrt(np.clip(pred["RV_pred"], 0, None))
    pred["Vol_base_pct"] = np.sqrt(np.clip(pred["RV_pred_baseline"], 0, None))

    return metrics, pred


# =========================
# GUI
# =========================
class VolatilityGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Volatility Prediction GUI (ARCH/GARCH/RF/XGB/LSTM GPU)")
        self.geometry("1220x780")

        self.csv_path = tk.StringVar(value="")
        self.data_source = tk.StringVar(value="Stooq")
        self.stooq_symbol = tk.StringVar(value="spy.us")
        self.start_date = tk.StringVar(value="2014-01-01")
        self.end_date = tk.StringVar(value="2024-01-01")

        self.model_choice = tk.StringVar(value="GARCH")
        self.test_size = tk.IntVar(value=252)

        # ARCH/GARCH
        self.refit_every = tk.IntVar(value=20)
        self.arch_q = tk.IntVar(value=5)

        # RF
        self.rf_estimators = tk.IntVar(value=500)

        # XGB
        self.xgb_estimators = tk.IntVar(value=1500)
        self.xgb_lr = tk.DoubleVar(value=0.03)
        self.xgb_depth = tk.IntVar(value=4)

        # LSTM
        self.lstm_lookback = tk.IntVar(value=30)
        self.lstm_epochs = tk.IntVar(value=60)
        self.lstm_batch = tk.IntVar(value=64)
        self.lstm_units1 = tk.IntVar(value=64)
        self.lstm_units2 = tk.IntVar(value=32)
        self.lstm_dropout = tk.DoubleVar(value=0.20)
        self.lstm_lr = tk.DoubleVar(value=1e-3)

        self.pred_df = None
        self.metrics_df = None

        # threading/queue for progress updates
        self.ui_queue = queue.Queue()
        self.worker_thread = None

        self._build_ui()
        self._poll_queue()

    def _build_ui(self):
        # --- Top controls
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")

        ttk.Label(top, text="Data Source:").grid(row=0, column=0, sticky="w")
        ds = ttk.Combobox(top, textvariable=self.data_source, values=["Stooq", "CSV"], width=10, state="readonly")
        ds.grid(row=0, column=1, sticky="w", padx=6)
        ds.bind("<<ComboboxSelected>>", lambda e: self._toggle_data_inputs())

        ttk.Label(top, text="Stooq Symbol:").grid(row=0, column=2, sticky="w")
        ttk.Entry(top, textvariable=self.stooq_symbol, width=12).grid(row=0, column=3, sticky="w", padx=6)

        ttk.Label(top, text="CSV File:").grid(row=0, column=4, sticky="w")
        self.csv_entry = ttk.Entry(top, textvariable=self.csv_path, width=44)
        self.csv_entry.grid(row=0, column=5, sticky="w", padx=6)
        ttk.Button(top, text="Browse", command=self._browse_csv).grid(row=0, column=6, sticky="w")

        ttk.Label(top, text="Start:").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.start_date, width=12).grid(row=1, column=1, sticky="w", padx=6, pady=(8, 0))

        ttk.Label(top, text="End:").grid(row=1, column=2, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.end_date, width=12).grid(row=1, column=3, sticky="w", padx=6, pady=(8, 0))

        ttk.Label(top, text="Model:").grid(row=1, column=4, sticky="w", pady=(8, 0))
        model_cb = ttk.Combobox(
            top, textvariable=self.model_choice,
            values=["ARCH", "GARCH", "RandomForest", "XGBoost", "LSTM (GPU)"],
            width=14, state="readonly"
        )
        model_cb.grid(row=1, column=5, sticky="w", padx=6, pady=(8, 0))
        model_cb.bind("<<ComboboxSelected>>", lambda e: self._toggle_model_inputs())

        self.run_btn = ttk.Button(top, text="Run", command=self._run_clicked)
        self.run_btn.grid(row=1, column=6, sticky="w", pady=(8, 0))

        # --- Status + progress
        stat = ttk.Frame(self, padding=(10, 0, 10, 10))
        stat.pack(fill="x")
        self.status_var = tk.StringVar(value="Ready.")
        ttk.Label(stat, textvariable=self.status_var).pack(side="left")

        self.prog = ttk.Progressbar(stat, orient="horizontal", length=340, mode="determinate")
        self.prog.pack(side="right")

        # --- Parameters
        params = ttk.LabelFrame(self, text="Parameters", padding=10)
        params.pack(fill="x", padx=10)

        ttk.Label(params, text="Test size (days):").grid(row=0, column=0, sticky="w")
        ttk.Entry(params, textvariable=self.test_size, width=10).grid(row=0, column=1, sticky="w", padx=6)

        # ARCH/GARCH panel
        self.arch_frame = ttk.LabelFrame(params, text="ARCH / GARCH", padding=8)
        self.arch_frame.grid(row=0, column=2, sticky="w", padx=10)

        ttk.Label(self.arch_frame, text="ARCH q:").grid(row=0, column=0, sticky="w")
        ttk.Entry(self.arch_frame, textvariable=self.arch_q, width=6).grid(row=0, column=1, sticky="w", padx=6)

        ttk.Label(self.arch_frame, text="Refit every:").grid(row=0, column=2, sticky="w")
        ttk.Entry(self.arch_frame, textvariable=self.refit_every, width=6).grid(row=0, column=3, sticky="w", padx=6)
        ttk.Label(self.arch_frame, text="days").grid(row=0, column=4, sticky="w")

        # RF panel
        self.rf_frame = ttk.LabelFrame(params, text="Random Forest", padding=8)
        self.rf_frame.grid(row=1, column=0, sticky="w", pady=(10, 0))
        ttk.Label(self.rf_frame, text="Estimators:").grid(row=0, column=0, sticky="w")
        ttk.Entry(self.rf_frame, textvariable=self.rf_estimators, width=8).grid(row=0, column=1, sticky="w", padx=6)

        # XGB panel
        self.xgb_frame = ttk.LabelFrame(params, text="XGBoost", padding=8)
        self.xgb_frame.grid(row=1, column=1, columnspan=2, sticky="w", padx=10, pady=(10, 0))
        ttk.Label(self.xgb_frame, text="Estimators:").grid(row=0, column=0, sticky="w")
        ttk.Entry(self.xgb_frame, textvariable=self.xgb_estimators, width=8).grid(row=0, column=1, sticky="w", padx=6)
        ttk.Label(self.xgb_frame, text="LR:").grid(row=0, column=2, sticky="w")
        ttk.Entry(self.xgb_frame, textvariable=self.xgb_lr, width=8).grid(row=0, column=3, sticky="w", padx=6)
        ttk.Label(self.xgb_frame, text="Depth:").grid(row=0, column=4, sticky="w")
        ttk.Entry(self.xgb_frame, textvariable=self.xgb_depth, width=8).grid(row=0, column=5, sticky="w", padx=6)

        # LSTM panel
        self.lstm_frame = ttk.LabelFrame(params, text="LSTM (GPU)", padding=8)
        self.lstm_frame.grid(row=2, column=0, columnspan=3, sticky="w", pady=(10, 0))

        r = 0
        ttk.Label(self.lstm_frame, text="Lookback:").grid(row=r, column=0, sticky="w")
        ttk.Entry(self.lstm_frame, textvariable=self.lstm_lookback, width=6).grid(row=r, column=1, sticky="w", padx=6)
        ttk.Label(self.lstm_frame, text="Epochs:").grid(row=r, column=2, sticky="w")
        ttk.Entry(self.lstm_frame, textvariable=self.lstm_epochs, width=6).grid(row=r, column=3, sticky="w", padx=6)
        ttk.Label(self.lstm_frame, text="Batch:").grid(row=r, column=4, sticky="w")
        ttk.Entry(self.lstm_frame, textvariable=self.lstm_batch, width=6).grid(row=r, column=5, sticky="w", padx=6)

        r = 1
        ttk.Label(self.lstm_frame, text="Units1:").grid(row=r, column=0, sticky="w")
        ttk.Entry(self.lstm_frame, textvariable=self.lstm_units1, width=6).grid(row=r, column=1, sticky="w", padx=6)
        ttk.Label(self.lstm_frame, text="Units2:").grid(row=r, column=2, sticky="w")
        ttk.Entry(self.lstm_frame, textvariable=self.lstm_units2, width=6).grid(row=r, column=3, sticky="w", padx=6)
        ttk.Label(self.lstm_frame, text="Dropout:").grid(row=r, column=4, sticky="w")
        ttk.Entry(self.lstm_frame, textvariable=self.lstm_dropout, width=6).grid(row=r, column=5, sticky="w", padx=6)

        r = 2
        ttk.Label(self.lstm_frame, text="LR:").grid(row=r, column=0, sticky="w")
        ttk.Entry(self.lstm_frame, textvariable=self.lstm_lr, width=10).grid(row=r, column=1, sticky="w", padx=6)

        # --- Outputs
        out = ttk.Frame(self, padding=10)
        out.pack(fill="both", expand=True)

        metrics_box = ttk.LabelFrame(out, text="Metrics", padding=8)
        metrics_box.pack(fill="x")

        self.metrics_tree = ttk.Treeview(metrics_box, columns=("Model", "MSE", "MAE", "RMSE", "R2", "QLIKE"),
                                         show="headings", height=4)
        for col in ("Model", "MSE", "MAE", "RMSE", "R2", "QLIKE"):
            self.metrics_tree.heading(col, text=col)
            self.metrics_tree.column(col, width=220 if col == "Model" else 140, anchor="center")
        self.metrics_tree.pack(fill="x")

        pred_box = ttk.LabelFrame(out, text="Predictions preview (first 40 rows)", padding=8)
        pred_box.pack(fill="both", expand=True, pady=(10, 0))

        self.pred_tree = ttk.Treeview(
            pred_box,
            columns=("Date", "Close", "RV_true", "RV_pred", "Vol_true_pct", "Vol_pred_pct"),
            show="headings",
            height=14
        )
        for col, w in [("Date", 160), ("Close", 120), ("RV_true", 150), ("RV_pred", 150), ("Vol_true_pct", 150), ("Vol_pred_pct", 150)]:
            self.pred_tree.heading(col, text=col)
            self.pred_tree.column(col, width=w, anchor="center")
        self.pred_tree.pack(fill="both", expand=True)

        btns = ttk.Frame(out)
        btns.pack(fill="x", pady=8)
        ttk.Button(btns, text="Export predictions to CSV", command=self._export_predictions).pack(side="left")
        ttk.Button(btns, text="Clear output", command=self._clear_output).pack(side="left", padx=8)
        ttk.Button(btns, text="Show GPU status", command=self._show_gpu_status).pack(side="left", padx=8)

        self._toggle_data_inputs()
        self._toggle_model_inputs()

    def _toggle_data_inputs(self):
        is_csv = (self.data_source.get() == "CSV")
        self.csv_entry.configure(state="normal" if is_csv else "disabled")

    def _toggle_model_inputs(self):
        m = self.model_choice.get()

        # show/hide parameter panels
        show_arch = m in ["ARCH", "GARCH"]
        show_rf = m == "RandomForest"
        show_xgb = m == "XGBoost"
        show_lstm = m == "LSTM (GPU)"

        self.arch_frame.grid_remove() if not show_arch else self.arch_frame.grid()
        self.rf_frame.grid_remove() if not show_rf else self.rf_frame.grid()
        self.xgb_frame.grid_remove() if not show_xgb else self.xgb_frame.grid()
        self.lstm_frame.grid_remove() if not show_lstm else self.lstm_frame.grid()

    def _browse_csv(self):
        path = filedialog.askopenfilename(
            title="Select CSV file",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if path:
            self.csv_path.set(path)
            self.data_source.set("CSV")
            self._toggle_data_inputs()

    def _clear_output(self):
        for t in self.metrics_tree.get_children():
            self.metrics_tree.delete(t)
        for t in self.pred_tree.get_children():
            self.pred_tree.delete(t)
        self.pred_df = None
        self.metrics_df = None

    def _load_data(self) -> pd.DataFrame:
        start = self.start_date.get().strip()
        end = self.end_date.get().strip()

        if self.data_source.get() == "Stooq":
            sym = self.stooq_symbol.get().strip()
            if not sym:
                raise ValueError("Stooq symbol is empty.")
            return load_data_stooq(sym, start, end)

        path = self.csv_path.get().strip()
        if not path:
            raise ValueError("CSV path is empty.")
        return load_data_csv(path, start, end)

    def _render_metrics(self, metrics: pd.DataFrame):
        for _, row in metrics.iterrows():
            self.metrics_tree.insert("", "end", values=(
                str(row["Model"]),
                f"{row['MSE']:.6f}",
                f"{row['MAE']:.6f}",
                f"{row['RMSE']:.6f}",
                f"{row['R2']:.4f}",
                f"{row['QLIKE']:.6f}",
            ))

    def _render_predictions(self, pred: pd.DataFrame):
        show = pred.head(40).copy()
        show["Date"] = pd.to_datetime(show["Date"]).dt.strftime("%Y-%m-%d")

        for _, row in show.iterrows():
            self.pred_tree.insert("", "end", values=(
                row["Date"],
                f"{row['Close']:.2f}",
                f"{row['RV_true']:.6f}",
                f"{row['RV_pred']:.6f}",
                f"{row['Vol_true_pct']:.4f}",
                f"{row['Vol_pred_pct']:.4f}",
            ))

    def _export_predictions(self):
        if self.pred_df is None or self.pred_df.empty:
            messagebox.showwarning("No data", "Run a model first to generate predictions.")
            return

        path = filedialog.asksaveasfilename(
            title="Save predictions CSV",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")]
        )
        if not path:
            return

        try:
            self.pred_df.to_csv(path, index=False)
            messagebox.showinfo("Saved", f"Predictions saved to:\n{path}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _show_gpu_status(self):
        gpus = tf.config.list_physical_devices("GPU")
        if not gpus:
            messagebox.showinfo("GPU status", "TensorFlow does NOT see a GPU.\n(Training will run on CPU.)")
        else:
            msg = "TensorFlow GPU detected:\n" + "\n".join([str(g) for g in gpus])
            messagebox.showinfo("GPU status", msg)

    def _set_running(self, running: bool):
        self.run_btn.configure(state="disabled" if running else "normal")
        if running:
            self.prog["value"] = 0
        self.update_idletasks()

    def _run_clicked(self):
        if self.worker_thread and self.worker_thread.is_alive():
            messagebox.showwarning("Busy", "A model is already running.")
            return

        self._clear_output()
        self._set_running(True)
        self.status_var.set("Running...")

        # start worker thread
        self.worker_thread = threading.Thread(target=self._run_worker, daemon=True)
        self.worker_thread.start()

    def _run_worker(self):
        try:
            df = self._load_data()
            model = self.model_choice.get()
            test_size = int(self.test_size.get())

            if model in ["ARCH", "GARCH"]:
                metrics, pred = run_arch_garch(
                    df=df,
                    model_name=model,
                    test_size=test_size,
                    refit_every=int(self.refit_every.get()),
                    arch_q=int(self.arch_q.get())
                )

            elif model == "RandomForest":
                metrics, pred = run_ml(
                    df=df,
                    model_name="RandomForest",
                    test_size=test_size,
                    rf_estimators=int(self.rf_estimators.get()),
                    xgb_estimators=int(self.xgb_estimators.get()),
                    xgb_lr=float(self.xgb_lr.get()),
                    xgb_depth=int(self.xgb_depth.get())
                )

            elif model == "XGBoost":
                metrics, pred = run_ml(
                    df=df,
                    model_name="XGBoost",
                    test_size=test_size,
                    rf_estimators=int(self.rf_estimators.get()),
                    xgb_estimators=int(self.xgb_estimators.get()),
                    xgb_lr=float(self.xgb_lr.get()),
                    xgb_depth=int(self.xgb_depth.get())
                )

            else:  # LSTM (GPU)
                # Let progressbar be based on epochs
                epochs = int(self.lstm_epochs.get())
                self.ui_queue.put({"type": "lstm_total_epochs", "total": epochs})

                metrics, pred = run_lstm(
                    df=df,
                    test_size=test_size,
                    lookback=int(self.lstm_lookback.get()),
                    epochs=epochs,
                    batch_size=int(self.lstm_batch.get()),
                    units1=int(self.lstm_units1.get()),
                    units2=int(self.lstm_units2.get()),
                    dropout=float(self.lstm_dropout.get()),
                    lr=float(self.lstm_lr.get()),
                    q_gui=self.ui_queue
                )

            # send results back to GUI
            self.ui_queue.put({"type": "done", "metrics": metrics, "pred": pred})

        except Exception as e:
            self.ui_queue.put({"type": "error", "message": str(e)})

    def _poll_queue(self):
        try:
            while True:
                msg = self.ui_queue.get_nowait()
                mtype = msg.get("type")

                if mtype == "lstm_total_epochs":
                    total = int(msg["total"])
                    self.prog.configure(maximum=total)
                    self.prog["value"] = 0
                    self.status_var.set(f"LSTM training started (epochs={total})...")

                elif mtype == "lstm_epoch":
                    ep = int(msg["epoch"])
                    total = int(msg["total"])
                    loss = msg.get("loss", np.nan)
                    val_loss = msg.get("val_loss", np.nan)

                    self.prog["value"] = ep
                    self.status_var.set(f"LSTM epoch {ep}/{total} | loss={loss:.6f} | val_loss={val_loss:.6f}")

                elif mtype == "done":
                    self.metrics_df = msg["metrics"]
                    self.pred_df = msg["pred"]
                    self._render_metrics(self.metrics_df)
                    self._render_predictions(self.pred_df)
                    self.status_var.set("Done.")
                    self._set_running(False)
                    messagebox.showinfo("Done", "Model run completed successfully.")

                elif mtype == "error":
                    self.status_var.set("Error.")
                    self._set_running(False)
                    messagebox.showerror("Error", msg["message"])

        except queue.Empty:
            pass

        self.after(150, self._poll_queue)


if __name__ == "__main__":
    app = VolatilityGUI()
    app.mainloop()
