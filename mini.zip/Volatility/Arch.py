# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:00:32 2026

@author: Administrator
"""

"""
ARCH VOLATILITY FORECASTING (Thesis-ready, simple + robust)

This script:
1) Loads daily Close prices (Stooq first; CSV fallback)
2) Computes log returns (in percent)
3) Fits an ARCH(q) model (default q=5)
4) Forecasts next N-day volatility (daily + annualized)
5) Prints results and saves them to CSV

INSTALL:
  pip install pandas numpy arch

DATA SOURCE:
- Primary: Stooq (direct CSV)
- Fallback: local CSV "prices.csv" with columns: Date, Close

NOTE:
- ARCH models volatility (conditional variance), not price direction.
"""

import numpy as np
import pandas as pd
from pathlib import Path
from arch import arch_model

# ----------------------------
# 1) Settings
# ----------------------------
START_DATE = "2014-01-01"
END_DATE = "2024-01-01"        # exclusive end (covers 2014–2023)

# Stooq symbol: SPY ETF (S&P 500 proxy). Change if you want another asset.
STOOQ_SYMBOL = "spy.us"
STOOQ_URL = f"https://stooq.com/q/d/l/?s={STOOQ_SYMBOL}&i=d"

# Local fallback if Stooq blocked
CSV_FALLBACK = Path("prices.csv")

# ARCH settings
ARCH_Q = 5                      # ARCH(q). Typical small q: 1–10 (try 5 as a starting point)
FORECAST_DAYS = 10              # forecast horizon
TRADING_DAYS = 252              # annualization factor for daily data

# Output
OUT_CSV = Path("arch_vol_forecast.csv")

# ----------------------------
# 2) Load data (Stooq -> CSV)
# ----------------------------
def load_prices() -> pd.DataFrame:
    """Return DataFrame with Date, Close. Tries Stooq first; then CSV."""
    # ---- Try Stooq ----
    try:
        print(f"Loading from Stooq: {STOOQ_URL}")
        df = pd.read_csv(STOOQ_URL)

        if df is None or df.empty:
            raise ValueError("Stooq returned empty.")

        if "Date" not in df.columns or "Close" not in df.columns:
            raise ValueError(f"Unexpected Stooq columns: {list(df.columns)}")

        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df.dropna(subset=["Date"]).sort_values("Date")

        df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]
        df = df[["Date", "Close"]].dropna()

        if df.empty:
            raise ValueError("No rows in requested date range.")

        print(f"✅ Loaded {len(df)} rows from Stooq ({STOOQ_SYMBOL})")
        return df

    except Exception as e:
        print(f"⚠ Stooq failed: {e}")
        print("Falling back to local CSV...")

    # ---- CSV fallback ----
    if not CSV_FALLBACK.exists():
        raise ValueError(
            f"[FATAL] Could not load from Stooq and CSV fallback not found.\n"
            f"Create {CSV_FALLBACK.name} with columns: Date, Close"
        )

    df = pd.read_csv(CSV_FALLBACK)

    # Flexible mapping (case-insensitive)
    colmap = {c.lower().strip(): c for c in df.columns}
    if "date" not in colmap or "close" not in colmap:
        raise ValueError(f"[FATAL] CSV must include Date and Close. Found: {list(df.columns)}")

    df = df.rename(columns={colmap["date"]: "Date", colmap["close"]: "Close"})
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")

    df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]
    df = df[["Date", "Close"]].dropna()

    if df.empty:
        raise ValueError("[FATAL] CSV loaded but no rows in the requested date range.")

    print(f"✅ Loaded {len(df)} rows from CSV fallback ({CSV_FALLBACK})")
    return df

prices = load_prices()

# ----------------------------
# 3) Compute returns
# ----------------------------
# Percent log returns: r_t = 100 * ln(C_t / C_{t-1})
prices["r_pct"] = 100 * np.log(prices["Close"] / prices["Close"].shift(1))

# Drop the first NaN
rets = prices.dropna(subset=["r_pct"]).copy()
r = rets["r_pct"]

print("\nReturn series summary (percent log returns):")
print(r.describe())

# ----------------------------
# 4) Fit ARCH(q)
# ----------------------------
"""
ARCH(q) specification:
  variance_t = omega + alpha_1 * eps_{t-1}^2 + ... + alpha_q * eps_{t-q}^2

Choices:
- mean="Constant": simple constant mean return
- vol="ARCH": ARCH family
- p=ARCH_Q: number of lagged squared residual terms (q)
- dist="t": Student-t errors (fat tails) often better for financial returns
"""
model = arch_model(
    r,
    mean="Constant",
    vol="ARCH",
    p=ARCH_Q,
    dist="t"
)

res = model.fit(disp="off")
print("\n=== ARCH Fit Summary ===")
print(res.summary())

# ----------------------------
# 5) Forecast volatility
# ----------------------------
"""
res.forecast(horizon=N) returns variance forecasts (in percent^2).
Daily volatility = sqrt(variance), still in percent units.
Annualized volatility = daily_vol * sqrt(TRADING_DAYS).
"""
fcst = res.forecast(horizon=FORECAST_DAYS, reindex=False)

# Take the last forecast origin (latest date)
var_forecast = fcst.variance.iloc[-1]              # Series length N
daily_vol_pct = np.sqrt(var_forecast)              # volatility in percent
annual_vol_pct = daily_vol_pct * np.sqrt(TRADING_DAYS)

out = pd.DataFrame({
    "horizon_day": np.arange(1, FORECAST_DAYS + 1),
    "forecast_variance_(pct^2)": var_forecast.values,
    "forecast_daily_vol_(pct)": daily_vol_pct.values,
    "forecast_annualized_vol_(pct)": annual_vol_pct.values
})

print("\n=== ARCH Volatility Forecast ===")
print(out.round(4).to_string(index=False))

# Save to CSV
out.to_csv(OUT_CSV, index=False)
print(f"\n✅ Saved forecast table to: {OUT_CSV.resolve()}")

# ----------------------------
# 6) One-number headline forecast
# ----------------------------
one_day_ann = float(out.loc[out["horizon_day"] == 1, "forecast_annualized_vol_(pct)"])
print(f"\n1-day ahead annualized volatility forecast (ARCH): {one_day_ann:.4f}%")
