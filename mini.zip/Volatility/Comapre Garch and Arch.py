# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:05:25 2026

@author: Administrator
"""

"""
COMPARE ARCH vs GARCH VOLATILITY FORECAST ACCURACY (Out-of-sample)

What this script does (thesis-ready):
1) Loads daily Close data (Stooq SPY proxy; CSV fallback)
2) Builds log returns (percent)
3) Splits data into train/test (walk-forward / rolling refit)
4) Produces 1-step-ahead volatility forecasts using:
      - ARCH(q)
      - GARCH(1,1)
5) Compares forecast accuracy using common loss functions:
      - MSE on variance:   (sigma^2_hat - r^2)^2
      - MAE on variance:   |sigma^2_hat - r^2|
      - QLIKE:             log(sigma^2_hat) + r^2 / sigma^2_hat
6) Prints a results table + saves to CSV

INSTALL:
  pip install pandas numpy arch

DATA:
- Primary: Stooq (spy.us)
- Fallback: prices.csv with columns Date, Close

NOTES:
- We use r_t^2 as a standard proxy for "realized variance" at daily frequency.
- For more advanced work, replace r_t^2 with realized variance from intraday data.
"""

import numpy as np
import pandas as pd
from pathlib import Path
from arch import arch_model

# ----------------------------
# 1) Settings
# ----------------------------
START_DATE = "2014-01-01"
END_DATE = "2024-01-01"          # exclusive end
STOOQ_SYMBOL = "spy.us"
STOOQ_URL = f"https://stooq.com/q/d/l/?s={STOOQ_SYMBOL}&i=d"

CSV_FALLBACK = Path("prices.csv")

ARCH_Q = 5                       # ARCH(q) order
TEST_SIZE = 252                  # last ~1 trading year as test set
REFIT_EVERY = 20                 # re-fit models every 20 days (monthly-ish)

OUT_CSV = Path("arch_vs_garch_accuracy.csv")


# ----------------------------
# 2) Load data (Stooq -> CSV)
# ----------------------------
def load_prices() -> pd.DataFrame:
    try:
        print(f"Loading from Stooq: {STOOQ_URL}")
        df = pd.read_csv(STOOQ_URL)
        if df is None or df.empty:
            raise ValueError("Stooq empty.")
        if "Date" not in df.columns or "Close" not in df.columns:
            raise ValueError(f"Unexpected columns: {list(df.columns)}")

        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df.dropna(subset=["Date"]).sort_values("Date")
        df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]
        df = df[["Date", "Close"]].dropna()

        if df.empty:
            raise ValueError("No rows in date range.")
        print(f"✅ Loaded {len(df)} rows from Stooq ({STOOQ_SYMBOL})")
        return df

    except Exception as e:
        print(f"⚠ Stooq failed: {e}")
        print("Falling back to local CSV...")

    if not CSV_FALLBACK.exists():
        raise ValueError(
            f"[FATAL] Stooq failed and CSV fallback not found.\n"
            f"Create {CSV_FALLBACK.name} with columns: Date, Close"
        )

    df = pd.read_csv(CSV_FALLBACK)
    colmap = {c.lower().strip(): c for c in df.columns}
    if "date" not in colmap or "close" not in colmap:
        raise ValueError(f"[FATAL] CSV must contain Date and Close. Found: {list(df.columns)}")
    df = df.rename(columns={colmap["date"]: "Date", colmap["close"]: "Close"})
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]
    df = df[["Date", "Close"]].dropna()

    if df.empty:
        raise ValueError("[FATAL] CSV loaded but no rows in date range.")
    print(f"✅ Loaded {len(df)} rows from CSV fallback ({CSV_FALLBACK})")
    return df


prices = load_prices()

# ----------------------------
# 3) Returns + realized variance proxy
# ----------------------------
# Percent log returns
prices["r_pct"] = 100 * np.log(prices["Close"] / prices["Close"].shift(1))
prices = prices.dropna(subset=["r_pct"]).reset_index(drop=True)

# Realized variance proxy for daily data: RV_t = r_t^2  (in percent^2)
prices["rv"] = prices["r_pct"] ** 2

# ----------------------------
# 4) Train/Test split
# ----------------------------
if len(prices) <= TEST_SIZE + 50:
    raise ValueError("[FATAL] Not enough data for the chosen TEST_SIZE. Reduce TEST_SIZE or extend history.")

train = prices.iloc[:-TEST_SIZE].copy()
test = prices.iloc[-TEST_SIZE:].copy()

print(f"\nTrain size: {len(train)} | Test size: {len(test)}")

# ----------------------------
# 5) Forecasting loop (rolling / walk-forward)
# ----------------------------
def fit_arch(train_returns: pd.Series):
    """Fit ARCH(q) model on return series (percent units)."""
    m = arch_model(train_returns, mean="Constant", vol="ARCH", p=ARCH_Q, dist="t")
    return m.fit(disp="off")

def fit_garch(train_returns: pd.Series):
    """Fit GARCH(1,1) model on return series (percent units)."""
    m = arch_model(train_returns, mean="Constant", vol="GARCH", p=1, q=1, dist="t")
    return m.fit(disp="off")

def one_step_variance_forecast(res):
    """Return 1-step-ahead variance forecast (percent^2)."""
    f = res.forecast(horizon=1, reindex=False)
    return float(f.variance.iloc[-1, 0])

# Prepare storage
rows = []

# Initial training window: all train data
full_returns = prices["r_pct"]
full_dates = prices["Date"]
full_rv = prices["rv"]

# We’ll walk forward over the test indices
start_test_idx = len(prices) - TEST_SIZE

arch_res = None
garch_res = None

for i in range(start_test_idx, len(prices)):
    # Define training slice up to (but not including) i
    train_slice = full_returns.iloc[:i]

    # Refit models every REFIT_EVERY steps, or on first iteration
    if (arch_res is None) or ((i - start_test_idx) % REFIT_EVERY == 0):
        arch_res = fit_arch(train_slice)
        garch_res = fit_garch(train_slice)

    # 1-step-ahead variance forecasts
    arch_var_hat = one_step_variance_forecast(arch_res)
    garch_var_hat = one_step_variance_forecast(garch_res)

    # Realized variance proxy for day i
    rv_i = float(full_rv.iloc[i])

    rows.append({
        "Date": full_dates.iloc[i],
        "RV (r^2)": rv_i,
        "ARCH_var_hat": arch_var_hat,
        "GARCH_var_hat": garch_var_hat,
    })

fc = pd.DataFrame(rows).reset_index(drop=True)

# Guard against any numerical issues
eps = 1e-12
fc["ARCH_var_hat"] = fc["ARCH_var_hat"].clip(lower=eps)
fc["GARCH_var_hat"] = fc["GARCH_var_hat"].clip(lower=eps)

# ----------------------------
# 6) Accuracy metrics
# ----------------------------
def mse(y, yhat):
    return float(np.mean((yhat - y) ** 2))

def mae(y, yhat):
    return float(np.mean(np.abs(yhat - y)))

def qlike(y, yhat):
    # QLIKE = log(yhat) + y/yhat  (lower is better)
    return float(np.mean(np.log(yhat) + (y / yhat)))

y = fc["RV (r^2)"].values

arch_hat = fc["ARCH_var_hat"].values
garch_hat = fc["GARCH_var_hat"].values

results = pd.DataFrame({
    "Model": ["ARCH(q)", "GARCH(1,1)"],
    "MSE (variance)": [mse(y, arch_hat), mse(y, garch_hat)],
    "MAE (variance)": [mae(y, arch_hat), mae(y, garch_hat)],
    "QLIKE": [qlike(y, arch_hat), qlike(y, garch_hat)],
})

# Add "winner" flags (lower is better)
for metric in ["MSE (variance)", "MAE (variance)", "QLIKE"]:
    best = results[metric].min()
    results[f"Best_{metric}"] = results[metric].apply(lambda v: "Yes" if np.isclose(v, best) else "")

# ----------------------------
# 7) Print + export
# ----------------------------
print("\n=== Forecast Accuracy (Lower is Better) ===")
print(results.to_string(index=False))

# Save forecast series + accuracy table
fc_out = fc.copy()
results_out = results.copy()

# Export both to CSVs
fc_out.to_csv("arch_vs_garch_forecasts.csv", index=False)
results_out.to_csv(OUT_CSV, index=False)

print("\n✅ Saved daily forecast comparison to: arch_vs_garch_forecasts.csv")
print(f"✅ Saved accuracy summary to: {OUT_CSV.resolve()}")

# Optional: show first few forecast rows
print("\nSample of forecast vs realized variance:")
print(fc.head(10).round(6).to_string(index=False))
