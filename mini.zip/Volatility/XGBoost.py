# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 09:15:27 2026

@author: Administrator
"""

"""
VOLATILITY PREDICTION WITH XGBOOST (Regression) — Thesis-ready, robust

Goal:
- Predict next-day volatility (variance proxy) using XGBoost regression.

Target:
- y_t = RV_{t+1} = r_{t+1}^2  (percent^2), where r_t is percent log return.

Features:
- Lagged returns and squared returns (volatility clustering)
- Rolling variances and means
- Optional OHLC range/body features (if available)

Data:
- Primary: Stooq (spy.us) (S&P 500 proxy)
- Fallback: prices.csv with columns Date, Close (and optional Open,High,Low)

Install:
  pip install pandas numpy scikit-learn xgboost

Run:
  python xgb_volatility_prediction.py

Outputs:
- Metrics on test set: MSE, MAE, RMSE, R^2, QLIKE
- Baseline comparison: yesterday's variance
- CSV with predictions: xgb_vol_predictions.csv
"""

import numpy as np
import pandas as pd
from pathlib import Path

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# XGBoost
from xgboost import XGBRegressor

# ----------------------------
# 1) Settings
# ----------------------------
START_DATE = "2014-01-01"
END_DATE = "2024-01-01"                    # exclusive end
STOOQ_SYMBOL = "spy.us"
STOOQ_URL = f"https://stooq.com/q/d/l/?s={STOOQ_SYMBOL}&i=d"

CSV_FALLBACK = Path("prices.csv")          # Date, Close (optional OHLC)

TEST_SIZE = 252                            # last ~1 year as test
RANDOM_STATE = 42

# Rolling windows
VOL_WIN_5 = 5
VOL_WIN_20 = 20
VOL_WIN_60 = 60

# XGBoost hyperparameters (good default baseline)
XGB_PARAMS = dict(
    n_estimators=1500,
    learning_rate=0.03,
    max_depth=4,
    subsample=0.8,
    colsample_bytree=0.8,
    reg_alpha=0.0,
    reg_lambda=1.0,
    objective="reg:squarederror",
    random_state=RANDOM_STATE,
    n_jobs=-1
)

OUT_PRED_CSV = Path("xgb_vol_predictions.csv")

# ----------------------------
# 2) Load data (Stooq -> CSV)
# ----------------------------
def load_ohlc() -> pd.DataFrame:
    # ---- Try Stooq ----
    try:
        print(f"Loading from Stooq: {STOOQ_URL}")
        df = pd.read_csv(STOOQ_URL)
        if df is None or df.empty:
            raise ValueError("Stooq returned empty.")

        if "Date" not in df.columns or "Close" not in df.columns:
            raise ValueError(f"Unexpected Stooq columns: {list(df.columns)}")

        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df.dropna(subset=["Date"]).sort_values("Date")
        df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]

        # Keep OHLC if present
        cols = ["Date"]
        for c in ["Open", "High", "Low", "Close"]:
            if c in df.columns:
                cols.append(c)

        df = df[cols].dropna()
        if df.empty:
            raise ValueError("No rows in requested date range.")

        print(f"✅ Loaded {len(df)} rows from Stooq ({STOOQ_SYMBOL})")
        return df.reset_index(drop=True)

    except Exception as e:
        print(f"⚠ Stooq failed: {e}")
        print("Falling back to local CSV...")

    # ---- CSV fallback ----
    if not CSV_FALLBACK.exists():
        raise ValueError(
            f"[FATAL] Stooq failed and CSV fallback not found.\n"
            f"Create {CSV_FALLBACK.name} with columns: Date, Close (and optionally Open,High,Low)."
        )

    df = pd.read_csv(CSV_FALLBACK)
    colmap = {c.lower().strip(): c for c in df.columns}
    if "date" not in colmap or "close" not in colmap:
        raise ValueError(f"[FATAL] CSV must contain Date and Close. Found: {list(df.columns)}")

    rename = {colmap["date"]: "Date", colmap["close"]: "Close"}
    for k in ["open", "high", "low"]:
        if k in colmap:
            rename[colmap[k]] = k.capitalize()

    df = df.rename(columns=rename)
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]

    keep = ["Date", "Close"] + [c for c in ["Open", "High", "Low"] if c in df.columns]
    df = df[keep].dropna()

    if df.empty:
        raise ValueError("[FATAL] CSV loaded but no rows in requested date range.")

    print(f"✅ Loaded {len(df)} rows from CSV fallback ({CSV_FALLBACK})")
    return df.reset_index(drop=True)


df = load_ohlc()

# Ensure numeric
for c in ["Open", "High", "Low", "Close"]:
    if c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.dropna(subset=["Close"]).copy()

# ----------------------------
# 3) Build returns + target
# ----------------------------
df["r_pct"] = 100 * np.log(df["Close"] / df["Close"].shift(1))
df["rv"] = df["r_pct"] ** 2                 # realized variance proxy (percent^2)
df["y_next_rv"] = df["rv"].shift(-1)        # target: next day's variance

# ----------------------------
# 4) Build features
# ----------------------------
df["r_lag1"] = df["r_pct"].shift(1)
df["r_lag2"] = df["r_pct"].shift(2)
df["r_lag5"] = df["r_pct"].shift(5)

df["rv_lag1"] = df["rv"].shift(1)
df["rv_lag2"] = df["rv"].shift(2)
df["rv_lag5"] = df["rv"].shift(5)

# Rolling volatility (std) -> variance proxy
df["vol5"] = df["r_pct"].rolling(VOL_WIN_5).std(ddof=1)
df["vol20"] = df["r_pct"].rolling(VOL_WIN_20).std(ddof=1)
df["vol60"] = df["r_pct"].rolling(VOL_WIN_60).std(ddof=1)

df["vol5_sq"] = df["vol5"] ** 2
df["vol20_sq"] = df["vol20"] ** 2
df["vol60_sq"] = df["vol60"] ** 2

# Rolling mean returns
df["mean5"] = df["r_pct"].rolling(5).mean()
df["mean20"] = df["r_pct"].rolling(20).mean()

# Optional OHLC-based features
if all(c in df.columns for c in ["Open", "High", "Low", "Close"]):
    df["range"] = df["High"] - df["Low"]
    df["range_pct"] = 100 * (df["range"] / df["Close"])
    df["body"] = (df["Close"] - df["Open"]).abs()
    df["body_pct"] = 100 * (df["body"] / df["Close"])

feature_cols = [
    "r_lag1", "r_lag2", "r_lag5",
    "rv_lag1", "rv_lag2", "rv_lag5",
    "vol5_sq", "vol20_sq", "vol60_sq",
    "mean5", "mean20"
]
if "range_pct" in df.columns:
    feature_cols += ["range_pct", "body_pct"]

df_model = df.dropna(subset=feature_cols + ["y_next_rv"]).copy()

if len(df_model) <= TEST_SIZE + 50:
    raise ValueError("[FATAL] Not enough rows after feature engineering. Reduce TEST_SIZE or shorten windows.")

# ----------------------------
# 5) Time-series split
# ----------------------------
train = df_model.iloc[:-TEST_SIZE].copy()
test = df_model.iloc[-TEST_SIZE:].copy()

X_train = train[feature_cols].values
y_train = train["y_next_rv"].values

X_test = test[feature_cols].values
y_test = test["y_next_rv"].values

print(f"\nTrain rows: {len(train)} | Test rows: {len(test)}")
print("Features used:", feature_cols)

# ----------------------------
# 6) Fit XGBoost model
# ----------------------------
xgb = XGBRegressor(**XGB_PARAMS)

# (Optional) Early stopping:
# We'll use the first 20% of the test set as a validation set (still time-ordered).
val_size = max(30, int(0.2 * len(X_test)))
X_val, y_val = X_test[:val_size], y_test[:val_size]
X_test_final, y_test_final = X_test[val_size:], y_test[val_size:]
test_final_dates = test["Date"].iloc[val_size:].values
test_final_close = test["Close"].iloc[val_size:].values

xgb.fit(
    X_train, y_train,
    eval_set=[(X_val, y_val)],
    verbose=False
)

# Predict on final test segment (after validation portion)
y_pred = xgb.predict(X_test_final)

# ----------------------------
# 7) Evaluate accuracy
# ----------------------------
mse = mean_squared_error(y_test_final, y_pred)
mae = mean_absolute_error(y_test_final, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test_final, y_pred)

# Baseline: yesterday's variance
baseline_pred = test["rv_lag1"].iloc[val_size:].values
mse_b = mean_squared_error(y_test_final, baseline_pred)
mae_b = mean_absolute_error(y_test_final, baseline_pred)
rmse_b = np.sqrt(mse_b)
r2_b = r2_score(y_test_final, baseline_pred)

# QLIKE
eps = 1e-12
y_pred_clip = np.clip(y_pred, eps, None)
y_test_clip = np.clip(y_test_final, eps, None)
qlike_xgb = float(np.mean(np.log(y_pred_clip) + (y_test_clip / y_pred_clip)))

base_clip = np.clip(baseline_pred, eps, None)
qlike_base = float(np.mean(np.log(base_clip) + (y_test_clip / base_clip)))

print("\n=== XGBOOST VOLATILITY PREDICTION (Target = next-day r^2) ===")
print(f"XGB  MSE : {mse:.6f} | MAE : {mae:.6f} | RMSE : {rmse:.6f} | R^2 : {r2:.4f} | QLIKE: {qlike_xgb:.6f}")
print(f"BASE MSE : {mse_b:.6f} | MAE : {mae_b:.6f} | RMSE : {rmse_b:.6f} | R^2 : {r2_b:.4f} | QLIKE: {qlike_base:.6f}")

# ----------------------------
# 8) Save predictions
# ----------------------------
out = pd.DataFrame({
    "Date": pd.to_datetime(test_final_dates),
    "Close": test_final_close,
    "RV_true": y_test_final,
    "RV_pred_XGB": y_pred,
    "RV_pred_Baseline": baseline_pred
})

# Convert variance -> daily volatility (%)
out["Vol_true_pct"] = np.sqrt(np.clip(out["RV_true"].values, 0, None))
out["Vol_pred_XGB_pct"] = np.sqrt(np.clip(out["RV_pred_XGB"].values, 0, None))
out["Vol_pred_Base_pct"] = np.sqrt(np.clip(out["RV_pred_Baseline"].values, 0, None))

out.to_csv(OUT_PRED_CSV, index=False)
print(f"\n✅ Saved predictions to: {OUT_PRED_CSV.resolve()}")

# ----------------------------
# 9) Feature importance (interpretation)
# ----------------------------
importances = pd.Series(xgb.feature_importances_, index=feature_cols).sort_values(ascending=False)
print("\n=== Feature Importances (XGBoost) ===")
print(importances.round(4).to_string())
