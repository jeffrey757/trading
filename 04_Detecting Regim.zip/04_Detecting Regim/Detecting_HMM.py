import pandas as pd
import numpy as np
from scipy import stats
from hmmlearn.hmm import GaussianHMM

# 1) LOAD CSV (Yahoo Finance format)
df = pd.read_csv("AAPL.csv")  # <-- change path if needed
df["time"] = pd.to_datetime(df["time"])
df = df.sort_values("time").set_index("time")

# 2) Use adjusted prices if available
price_col = "Adj Close" if "Adj Close" in df.columns else "close"
df = df[[price_col]].dropna()
df.rename(columns={price_col: "Price"}, inplace=True)

print("Rows loaded:", len(df))
print(df.head())

# 3) Compute log returns
df["r"] = np.log(df["Price"] / df["Price"].shift(1))
df = df.dropna()

# -----------------------------
# TABLE 4.1 Descriptive Stats
# -----------------------------
print("\nTABLE 4.1 (Descriptive stats)")
print("Mean:", df["r"].mean())
print("Std Dev:", df["r"].std())
print("Skewness:", stats.skew(df["r"]))
print("Kurtosis:", stats.kurtosis(df["r"], fisher=False))
print("Min:", df["r"].min())
print("Max:", df["r"].max())

# -----------------------------
# HMM (2-state Gaussian)
# -----------------------------
X = df["r"].values.reshape(-1, 1)

model = GaussianHMM(
    n_components=2,
    covariance_type="full",
    n_iter=2000,
    random_state=42
)
model.fit(X)

states = model.predict(X)
df["Regime"] = states

# Determine which regime is "High Vol" based on variance
vars_ = np.array([model.covars_[i][0][0] for i in range(2)])
high_vol = int(np.argmax(vars_))
low_vol  = 1 - high_vol

# -----------------------------
# TABLE 4.2 Regime parameters
# -----------------------------
print("\nTABLE 4.2 (HMM Regime parameters)")
for i in range(2):
    mu = model.means_[i][0]
    var = model.covars_[i][0][0]
    sig = np.sqrt(var)
    p_ii = model.transmat_[i][i]
    label = "High-Vol (Volatile Market)" if i == high_vol else "Low-Vol (Trending/Stable Market)"
    print(f"Regime {i} [{label}] -> mean={mu}, std={sig}, p_ii={p_ii}")

# -----------------------------
# TABLE 4.3 Transition matrix
# -----------------------------
print("\nTABLE 4.3 (Transition matrix)")
print(model.transmat_)

# -----------------------------
# TABLE 4.4 Frequency
# -----------------------------
print("\nTABLE 4.4 (Regime frequency %)")
print(df["Regime"].value_counts(normalize=True) * 100)

# -----------------------------
# TABLE 4.5 Avg durations
# -----------------------------
print("\nTABLE 4.5 (Average duration in days)")
for i in range(2):
    p_ii = model.transmat_[i][i]
    duration = 1 / (1 - p_ii)
    print(f"Regime {i}: p_ii={p_ii:.6f}, avg_duration={duration:.2f} days")

# -----------------------------
# TABLE 4.6 Mean difference test (Welch)
# -----------------------------
r0 = df[df["Regime"] == 0]["r"]
r1 = df[df["Regime"] == 1]["r"]
t_stat, p_val = stats.ttest_ind(r0, r1, equal_var=False)

print("\nTABLE 4.6 (Welch t-test: mean difference)")
print("t-stat:", t_stat)
print("p-value:", p_val)

# -----------------------------
# TABLE 4.7 Variance ratio
# -----------------------------
f_stat = r0.var(ddof=1) / r1.var(ddof=1)
print("\nTABLE 4.7 (Variance ratio)")
print("F-stat:", f_stat)
print("n0, n1:", len(r0), len(r1))
