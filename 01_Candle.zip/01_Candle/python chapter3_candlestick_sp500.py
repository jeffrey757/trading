"""
CHAPTER 3 — FULL UPDATED, FAILSAFE CODE (S&P 500 / SPY proxy, 2014–2023)

DATA SOURCES (automatic fallback order):
  1) yfinance (Yahoo Finance)     -> may fail / blocked
  2) Stooq direct CSV (robust)    -> tries SPX index, then SPY ETF proxy
  3) Local CSV fallback

If Yahoo + Stooq are blocked on your network, ONLY CSV will work.

INSTALL:
  pip install pandas numpy scipy yfinance openpyxl

RUN:
  python chapter3_sp500_candles.py
"""

import pandas as pd
import numpy as np
from scipy import stats
from pathlib import Path

# yfinance optional (may be blocked)
try:
    import yfinance as yf
except Exception:
    yf = None

# -----------------------------
# 1) Settings
# -----------------------------
START_DATE = "2014-01-01"
END_DATE = "2024-01-01"  # exclusive end; covers 2014–2023

# Yahoo Finance symbol for S&P 500 Index
TICKER_YF = "^GSPC"

# CSV fallback (offline)
CSV_FALLBACK = Path("sp500_2014_2023.csv")  # Date,Open,High,Low,Close

TX_COST = 0.0015
VOL_WINDOW = 20
MA_WINDOW = 200

# Strict thesis thresholds
HAMMER_LOWER_SHADOW_MIN = 0.60
HAMMER_UPPER_SHADOW_MAX = 0.10
HAMMER_BODY_MAX = 0.30

STAR_UPPER_SHADOW_MIN = 0.60
STAR_LOWER_SHADOW_MAX = 0.10
STAR_BODY_MAX = 0.30

# Auto-relax thresholds (if strict yields 0 signals)
RELAX_HAMMER_LOWER_SHADOW_MIN = 0.50
RELAX_HAMMER_UPPER_SHADOW_MAX = 0.20
RELAX_HAMMER_BODY_MAX = 0.40

RELAX_STAR_UPPER_SHADOW_MIN = 0.50
RELAX_STAR_LOWER_SHADOW_MAX = 0.20
RELAX_STAR_BODY_MAX = 0.40

OUT_DIR = Path("chapter3_outputs")
OUT_DIR.mkdir(exist_ok=True)
OUT_XLSX = OUT_DIR / "chapter3_tables_sp500.xlsx"

# -----------------------------
# 2) Helpers
# -----------------------------
def flatten_yfinance_columns(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df

def safe_mean(s: pd.Series) -> float:
    return float(s.mean()) if s is not None and len(s) > 0 else float("nan")

def safe_std(s: pd.Series) -> float:
    return float(s.std(ddof=1)) if s is not None and len(s) > 1 else float("nan")

def safe_rate(s: pd.Series) -> float:
    return float(s.mean()) if s is not None and len(s) > 0 else float("nan")

def one_sample_ttest(sample: pd.Series, popmean: float):
    sample = sample.dropna()
    if len(sample) < 2 or np.isnan(popmean):
        return float("nan"), float("nan")
    res = stats.ttest_1samp(sample, popmean=popmean)
    return float(res.statistic), float(res.pvalue)

def require_columns(df: pd.DataFrame, cols: list, name: str):
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"[FATAL] {name} missing columns: {missing}. Found: {list(df.columns)}")

def apply_patterns(df_in: pd.DataFrame,
                   hammer_lower_min: float, hammer_upper_max: float, hammer_body_max: float,
                   star_upper_min: float, star_lower_max: float, star_body_max: float) -> pd.DataFrame:
    out = df_in.copy()
    out["Hammer"] = (
        (out["LowerShadowRatio"] > hammer_lower_min) &
        (out["UpperShadowRatio"] < hammer_upper_max) &
        (out["BodyRatio"] < hammer_body_max) &
        (out["Downtrend"])
    )
    out["ShootingStar"] = (
        (out["UpperShadowRatio"] > star_upper_min) &
        (out["LowerShadowRatio"] < star_lower_max) &
        (out["BodyRatio"] < star_body_max) &
        (out["Uptrend"])
    )
    return out

# -----------------------------
# 3) Loaders
# -----------------------------
def load_from_yfinance() -> pd.DataFrame | None:
    if yf is None:
        print("yfinance not available. Skipping Yahoo Finance.")
        return None

    print("Attempting download via yfinance (Yahoo Finance)...")
    try:
        raw = yf.download(TICKER_YF, start=START_DATE, end=END_DATE, auto_adjust=False, progress=False)
        if raw is None or raw.empty:
            print("⚠ yfinance returned empty.")
            return None

        raw = flatten_yfinance_columns(raw)
        if not all(c in raw.columns for c in ["Open", "High", "Low", "Close"]):
            print("⚠ yfinance missing OHLC columns.")
            return None

        df = raw[["Open", "High", "Low", "Close"]].copy().dropna()
        if df.empty:
            print("⚠ yfinance OHLC empty after dropna.")
            return None

        df.reset_index(inplace=True)  # Date becomes column
        df.rename(columns={"Date": "Date"}, inplace=True)
        print(f"✅ yfinance success: {len(df)} rows")
        return df

    except Exception as e:
        print(f"⚠ yfinance failed: {e}")
        return None


def load_from_stooq() -> pd.DataFrame | None:
    """
    Stooq symbols:
      - ^spx or spx may work for S&P 500 index
      - spy.us is very reliable and tracks S&P 500 closely (ETF proxy)
    """
    print("Attempting download via Stooq (direct CSV)...")

    # Most reliable fallback: SPY ETF on Stooq (tracks S&P 500)
    symbols = ["^spx", "spx", "spy.us"]

    for sym in symbols:
        url = f"https://stooq.com/q/d/l/?s={sym}&i=d"
        try:
            s = pd.read_csv(url)
            if s is None or s.empty:
                print(f"⚠ Stooq empty for {sym}")
                continue

            require_columns(s, ["Date", "Open", "High", "Low", "Close"], f"Stooq {sym}")
            s["Date"] = pd.to_datetime(s["Date"], errors="coerce")
            s = s.dropna(subset=["Date"]).sort_values("Date")

            s = s[(s["Date"] >= START_DATE) & (s["Date"] < END_DATE)]
            s = s[["Date", "Open", "High", "Low", "Close"]].dropna()

            if not s.empty:
                print(f"✅ Stooq success: symbol={sym} rows={len(s)}")
                if sym == "spy.us":
                    print("ℹ Using SPY (ETF proxy for S&P 500). Mention as data-source proxy in Chapter 3.")
                return s

        except Exception as e:
            print(f"⚠ Stooq failed for {sym}: {e}")
            continue

    return None


def load_from_csv() -> pd.DataFrame | None:
    print("Attempting local CSV fallback...")
    if not CSV_FALLBACK.exists():
        return None

    df = pd.read_csv(CSV_FALLBACK)
    colmap = {c.lower().strip(): c for c in df.columns}
    needed = ["date", "open", "high", "low", "close"]
    if not all(k in colmap for k in needed):
        raise ValueError(
            f"[FATAL] CSV exists but missing required columns.\n"
            f"Need: {needed}\nFound: {list(df.columns)}"
        )

    df = df.rename(columns={
        colmap["date"]: "Date",
        colmap["open"]: "Open",
        colmap["high"]: "High",
        colmap["low"]: "Low",
        colmap["close"]: "Close",
    })

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date")
    df = df[(df["Date"] >= START_DATE) & (df["Date"] < END_DATE)]
    df = df[["Date", "Open", "High", "Low", "Close"]].dropna()

    if df.empty:
        raise ValueError("[FATAL] CSV loaded but no rows within date range.")

    print(f"✅ CSV success: rows={len(df)} file={CSV_FALLBACK}")
    return df


def load_ohlc() -> pd.DataFrame:
    df = load_from_yfinance()
    if df is not None and not df.empty:
        return df

    df = load_from_stooq()
    if df is not None and not df.empty:
        return df

    df = load_from_csv()
    if df is not None and not df.empty:
        return df

    raise ValueError(
        "[FATAL] Could not load data from any source.\n"
        "Yahoo (yfinance) failed/blocked AND Stooq failed/blocked AND CSV not found.\n"
        "Fix: Create sp500_2014_2023.csv with columns: Date,Open,High,Low,Close."
    )

# -----------------------------
# 4) Main pipeline
# -----------------------------
df = load_ohlc()
require_columns(df, ["Date", "Open", "High", "Low", "Close"], "OHLC dataset")

# Ensure numeric types
for c in ["Open", "High", "Low", "Close"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df.dropna(subset=["Open", "High", "Low", "Close"], inplace=True)

# Sort
df = df.sort_values("Date").reset_index(drop=True)

# Returns + candle components
df["Return"] = df["Close"].pct_change()
df["Range"] = df["High"] - df["Low"]
df["Body"] = (df["Close"] - df["Open"]).abs()
df["LowerShadow"] = np.minimum(df["Open"], df["Close"]) - df["Low"]
df["UpperShadow"] = df["High"] - np.maximum(df["Open"], df["Close"])

# Avoid Range==0 division
df.loc[df["Range"] == 0, "Range"] = np.nan

df["LowerShadowRatio"] = df["LowerShadow"] / df["Range"]
df["UpperShadowRatio"] = df["UpperShadow"] / df["Range"]
df["BodyRatio"] = df["Body"] / df["Range"]

# Trend filters (3-day)
df["Downtrend"] = (
    (df["Close"] < df["Close"].shift(1)) &
    (df["Close"].shift(1) < df["Close"].shift(2)) &
    (df["Close"].shift(2) < df["Close"].shift(3))
)
df["Uptrend"] = (
    (df["Close"] > df["Close"].shift(1)) &
    (df["Close"].shift(1) > df["Close"].shift(2)) &
    (df["Close"].shift(2) > df["Close"].shift(3))
)

# Forward returns
df["Forward_5"] = df["Close"].shift(-5) / df["Close"] - 1
df["Forward_10"] = df["Close"].shift(-10) / df["Close"] - 1

# Range percent for descriptive stats
df["RangePct"] = (df["High"] - df["Low"]) / df["Close"].shift(1)

# Drop NaNs created by shifts/pct_change
df.dropna(inplace=True)
if df.empty:
    raise ValueError("[FATAL] Data became empty after feature engineering.")

# Patterns (strict then relax)
df = apply_patterns(
    df,
    HAMMER_LOWER_SHADOW_MIN, HAMMER_UPPER_SHADOW_MAX, HAMMER_BODY_MAX,
    STAR_UPPER_SHADOW_MIN, STAR_LOWER_SHADOW_MAX, STAR_BODY_MAX
)

hammer_count = int(df["Hammer"].sum())
star_count = int(df["ShootingStar"].sum())

if hammer_count == 0 and star_count == 0:
    print("⚠ 0 signals with strict thresholds. Auto-relaxing thresholds...")
    df = apply_patterns(
        df,
        RELAX_HAMMER_LOWER_SHADOW_MIN, RELAX_HAMMER_UPPER_SHADOW_MAX, RELAX_HAMMER_BODY_MAX,
        RELAX_STAR_UPPER_SHADOW_MIN, RELAX_STAR_LOWER_SHADOW_MAX, RELAX_STAR_BODY_MAX
    )
    hammer_count = int(df["Hammer"].sum())
    star_count = int(df["ShootingStar"].sum())

print(f"\nUsable rows: {len(df)} | Hammer: {hammer_count} | ShootingStar: {star_count}")

# -----------------------------
# 5) Build tables
# -----------------------------
table_3_1 = pd.DataFrame({
    "Variable": ["Daily Return", "Daily Range"],
    "Mean (%)": [df["Return"].mean() * 100, df["RangePct"].mean() * 100],
    "Std Dev (%)": [df["Return"].std(ddof=1) * 100, df["RangePct"].std(ddof=1) * 100],
    "Minimum (%)": [df["Return"].min() * 100, df["RangePct"].min() * 100],
    "Maximum (%)": [df["Return"].max() * 100, df["RangePct"].max() * 100],
}).round(3)

total_days = len(df)
table_3_2 = pd.DataFrame({
    "Pattern": ["Hammer", "Shooting Star"],
    "Count": [hammer_count, star_count],
    "% of Sample": [hammer_count / total_days * 100, star_count / total_days * 100],
}).round(2)

uncond_5_mean = safe_mean(df["Forward_5"])
uncond_10_mean = safe_mean(df["Forward_10"])
uncond_5_pos = safe_rate(df["Forward_5"] > 0)
uncond_10_pos = safe_rate(df["Forward_10"] > 0)

table_3_3 = pd.DataFrame({
    "Horizon": ["5-Day", "10-Day"],
    "Avg Return (%)": [uncond_5_mean * 100, uncond_10_mean * 100],
    "Positive Probability (%)": [uncond_5_pos * 100, uncond_10_pos * 100],
}).round(3)

hammer_df = df[df["Hammer"]].copy()
star_df = df[df["ShootingStar"]].copy()

hammer_5_mean = safe_mean(hammer_df["Forward_5"])
hammer_10_mean = safe_mean(hammer_df["Forward_10"])
hammer_5_std = safe_std(hammer_df["Forward_5"])
hammer_10_std = safe_std(hammer_df["Forward_10"])
hammer_5_pos = safe_rate(hammer_df["Forward_5"] > 0)
hammer_10_pos = safe_rate(hammer_df["Forward_10"] > 0)

table_3_4 = pd.DataFrame({
    "Horizon": ["5-Day", "10-Day"],
    "Avg Return (%)": [hammer_5_mean * 100, hammer_10_mean * 100],
    "Std Dev (%)": [hammer_5_std * 100, hammer_10_std * 100],
    "Positive %": [hammer_5_pos * 100, hammer_10_pos * 100],
    "N (signals)": [len(hammer_df), len(hammer_df)],
}).round(3)

star_5_mean = safe_mean(star_df["Forward_5"])
star_10_mean = safe_mean(star_df["Forward_10"])
star_5_std = safe_std(star_df["Forward_5"])
star_10_std = safe_std(star_df["Forward_10"])
star_5_neg = safe_rate(star_df["Forward_5"] < 0)
star_10_neg = safe_rate(star_df["Forward_10"] < 0)

table_3_5 = pd.DataFrame({
    "Horizon": ["5-Day", "10-Day"],
    "Avg Return (%)": [star_5_mean * 100, star_10_mean * 100],
    "Std Dev (%)": [star_5_std * 100, star_10_std * 100],
    "Negative %": [star_5_neg * 100, star_10_neg * 100],
    "N (signals)": [len(star_df), len(star_df)],
}).round(3)

t_h5, p_h5 = one_sample_ttest(hammer_df["Forward_5"], uncond_5_mean)
t_h10, p_h10 = one_sample_ttest(hammer_df["Forward_10"], uncond_10_mean)
t_s5, p_s5 = one_sample_ttest(star_df["Forward_5"], uncond_5_mean)
t_s10, p_s10 = one_sample_ttest(star_df["Forward_10"], uncond_10_mean)

table_3_6 = pd.DataFrame({
    "Pattern": ["Hammer", "Hammer", "Shooting Star", "Shooting Star"],
    "Horizon": ["5-Day", "10-Day", "5-Day", "10-Day"],
    "t-stat": [t_h5, t_h10, t_s5, t_s10],
    "p-value": [p_h5, p_h10, p_s5, p_s10],
}).round(4)
table_3_6["Significant (5%)"] = table_3_6["p-value"].apply(lambda p: "Yes" if pd.notna(p) and p < 0.05 else "No")

table_3_7 = pd.DataFrame({
    "Pattern": ["Hammer", "Hammer", "Shooting Star", "Shooting Star"],
    "Horizon": ["5-Day", "10-Day", "5-Day", "10-Day"],
    "Gross Return (%)": [hammer_5_mean * 100, hammer_10_mean * 100, star_5_mean * 100, star_10_mean * 100],
    "Cost (%)": [TX_COST * 100] * 4,
    "Net Return (%)": [
        (hammer_5_mean - TX_COST) * 100 if pd.notna(hammer_5_mean) else np.nan,
        (hammer_10_mean - TX_COST) * 100 if pd.notna(hammer_10_mean) else np.nan,
        (star_5_mean - TX_COST) * 100 if pd.notna(star_5_mean) else np.nan,
        (star_10_mean - TX_COST) * 100 if pd.notna(star_10_mean) else np.nan,
    ],
}).round(3)

df["Volatility"] = df["Return"].rolling(VOL_WINDOW).std(ddof=1)
median_vol = df["Volatility"].median()
high_vol_df = df[df["Volatility"] > median_vol]
low_vol_df = df[df["Volatility"] <= median_vol]

table_3_8 = pd.DataFrame({
    "Pattern": ["Hammer", "Shooting Star"],
    "High Volatility 5-Day Avg (%)": [
        safe_mean(high_vol_df[high_vol_df["Hammer"]]["Forward_5"]) * 100,
        safe_mean(high_vol_df[high_vol_df["ShootingStar"]]["Forward_5"]) * 100
    ],
    "Low Volatility 5-Day Avg (%)": [
        safe_mean(low_vol_df[low_vol_df["Hammer"]]["Forward_5"]) * 100,
        safe_mean(low_vol_df[low_vol_df["ShootingStar"]]["Forward_5"]) * 100
    ],
}).round(3)

df["MA200"] = df["Close"].rolling(MA_WINDOW).mean()
bull_df = df[df["Close"] > df["MA200"]]
bear_df = df[df["Close"] < df["MA200"]]

table_3_9 = pd.DataFrame({
    "Pattern": ["Hammer", "Shooting Star"],
    "Bull Market 5-Day Avg (%)": [
        safe_mean(bull_df[bull_df["Hammer"]]["Forward_5"]) * 100,
        safe_mean(bull_df[bull_df["ShootingStar"]]["Forward_5"]) * 100
    ],
    "Bear Market 5-Day Avg (%)": [
        safe_mean(bear_df[bear_df["Hammer"]]["Forward_5"]) * 100,
        safe_mean(bear_df[bear_df["ShootingStar"]]["Forward_5"]) * 100
    ],
}).round(3)

# -----------------------------
# 6) Print + export
# -----------------------------
print("\n=== TABLE 3.1 ==="); print(table_3_1.to_string(index=False))
print("\n=== TABLE 3.2 ==="); print(table_3_2.to_string(index=False))
print("\n=== TABLE 3.3 ==="); print(table_3_3.to_string(index=False))
print("\n=== TABLE 3.4 ==="); print(table_3_4.to_string(index=False))
print("\n=== TABLE 3.5 ==="); print(table_3_5.to_string(index=False))
print("\n=== TABLE 3.6 ==="); print(table_3_6.to_string(index=False))
print("\n=== TABLE 3.7 ==="); print(table_3_7.to_string(index=False))
print("\n=== TABLE 3.8 ==="); print(table_3_8.to_string(index=False))
print("\n=== TABLE 3.9 ==="); print(table_3_9.to_string(index=False))

try:
    with pd.ExcelWriter(OUT_XLSX, engine="openpyxl") as writer:
        table_3_1.to_excel(writer, sheet_name="Table_3_1_Descriptive", index=False)
        table_3_2.to_excel(writer, sheet_name="Table_3_2_Frequency", index=False)
        table_3_3.to_excel(writer, sheet_name="Table_3_3_Unconditional", index=False)
        table_3_4.to_excel(writer, sheet_name="Table_3_4_Hammer", index=False)
        table_3_5.to_excel(writer, sheet_name="Table_3_5_ShootingStar", index=False)
        table_3_6.to_excel(writer, sheet_name="Table_3_6_Ttests", index=False)
        table_3_7.to_excel(writer, sheet_name="Table_3_7_NetReturns", index=False)
        table_3_8.to_excel(writer, sheet_name="Table_3_8_Volatility", index=False)
        table_3_9.to_excel(writer, sheet_name="Table_3_9_BullBear", index=False)
    print(f"\n✅ Excel exported to: {OUT_XLSX.resolve()}")
except Exception as e:
    print(f"\n⚠ Excel export failed: {e}")
    print("You can still copy results from the console output.")
