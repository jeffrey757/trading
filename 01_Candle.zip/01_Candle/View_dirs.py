import os
from collections import Counter, defaultdict
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter

# ---------------------------------------------------
# 1) CONFIG
# ---------------------------------------------------
# Choose the extension you want to summarize (include the dot), e.g. ".csv", ".py", ".txt"
TARGET_EXTENSION = ".py"

# ---------------------------------------------------
# 2) Detect base directory (folder where this .py lives)
# ---------------------------------------------------
try:
    BASE_PATH = os.path.dirname(os.path.abspath(__file__))
except NameError:
    # For Jupyter / interactive runs
    BASE_PATH = os.getcwd()

# ---------------------------------------------------
# 3) Helpers
# ---------------------------------------------------
def parent_and_subfolder(base_path: str, file_dir: str):
    """
    Returns:
      parent_folder = first folder under base_path
      subfolder     = second folder under base_path (child of parent), else ""
    """
    rel_dir = os.path.relpath(file_dir, base_path)
    if rel_dir == ".":
        return ("", "")
    parts = rel_dir.split(os.sep)
    parent_folder = parts[0] if len(parts) >= 1 else ""
    subfolder = parts[1] if len(parts) >= 2 else ""
    return (parent_folder, subfolder)

def normalize_ext(filename: str) -> str:
    """
    Returns file extension in lowercase including the dot.
    For files without extension, returns "".
    """
    _, ext = os.path.splitext(filename)
    return ext.lower()

def style_header_row(ws, headers, row=1):
    header_fill = PatternFill("solid", fgColor="D9E1F2")
    header_font = Font(bold=True)
    for col_idx, title in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=col_idx, value=title)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")

def autofit_columns(ws, min_w=12, max_w=80):
    for col in range(1, ws.max_column + 1):
        letter = get_column_letter(col)
        max_len = 0
        for cell in ws[letter]:
            if cell.value is None:
                continue
            max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[letter].width = min(max(min_w, max_len + 2), max_w)

# ---------------------------------------------------
# 4) Scan directory (collect folders, files, extensions)
# ---------------------------------------------------
folder_set = set()
file_rows = []  # rows for Sheet 1
ext_counter = Counter()
files_by_ext = defaultdict(list)  # ext -> list of (filename, full_path)

for root, dirs, files in os.walk(BASE_PATH):
    # Count folders (include every discovered folder path)
    for d in dirs:
        folder_set.add(os.path.join(root, d))

    files.sort()
    for fname in files:
        full_path = os.path.join(root, fname)
        parent_folder, subfolder = parent_and_subfolder(BASE_PATH, root)
        ext = normalize_ext(fname)

        ext_counter[ext] += 1
        files_by_ext[ext].append((fname, full_path))

        file_rows.append([fname, parent_folder, subfolder, ext, full_path])

total_folders = len(folder_set)
total_files = len(file_rows)
unique_extensions = len([e for e in ext_counter.keys() if e != ""])  # ignore "" if you want

# Normalize target extension
TARGET_EXTENSION = (TARGET_EXTENSION or "").strip().lower()
if TARGET_EXTENSION and not TARGET_EXTENSION.startswith("."):
    TARGET_EXTENSION = "." + TARGET_EXTENSION

target_count = ext_counter.get(TARGET_EXTENSION, 0)
target_files = files_by_ext.get(TARGET_EXTENSION, [])

# ---------------------------------------------------
# 5) Build Excel
# ---------------------------------------------------
wb = Workbook()

# ---- Sheet 1: Files
ws_files = wb.active
ws_files.title = "Files"

headers_files = ["File Name", "Parent Folder", "Subfolder", "Extension", "Full Path"]
style_header_row(ws_files, headers_files, row=1)

for r in file_rows:
    ws_files.append(r)

ws_files.freeze_panes = "A2"
autofit_columns(ws_files)

# ---- Sheet 2: Summary
ws_sum = wb.create_sheet("Summary")

# Summary key metrics
ws_sum["A1"] = "Directory Summary"
ws_sum["A1"].font = Font(bold=True, size=14)

summary_rows = [
    ("Base Path", BASE_PATH),
    ("Total Folders", total_folders),
    ("Total Files", total_files),
    ("Total Unique Extensions", unique_extensions),
    ("Specific Extension", TARGET_EXTENSION),
    ("Count of Specific Extension Files", target_count),
]
start_row = 3
ws_sum["A2"] = "Metrics"
ws_sum["A2"].font = Font(bold=True)

for i, (k, v) in enumerate(summary_rows):
    ws_sum.cell(row=start_row + i, column=1, value=k).font = Font(bold=True)
    ws_sum.cell(row=start_row + i, column=2, value=v)

# Extension counts table
table_row = start_row + len(summary_rows) + 2
ws_sum.cell(row=table_row, column=1, value="Extension Counts").font = Font(bold=True)

table_row += 1
style_header_row(ws_sum, ["Extension", "Count"], row=table_row)

# Put no-extension files as "(no ext)" for readability
for ext, cnt in ext_counter.most_common():
    display_ext = ext if ext else "(no ext)"
    ws_sum.append([display_ext, cnt])

# Specific extension file list
list_row = ws_sum.max_row + 2
ws_sum.cell(row=list_row, column=1, value="Files for Specific Extension").font = Font(bold=True)

list_row += 1
style_header_row(ws_sum, ["Extension", "File Name", "Full Path"], row=list_row)

# Add all matching files (you can limit if you want)
for fname, fpath in target_files:
    ws_sum.append([TARGET_EXTENSION, fname, fpath])

ws_sum.freeze_panes = "A3"
autofit_columns(ws_sum)

# ---------------------------------------------------
# 6) Save next to the script
# ---------------------------------------------------
output_file = os.path.join(BASE_PATH, "directory_export_with_summary.xlsx")
wb.save(output_file)

print("Saved:", output_file)
