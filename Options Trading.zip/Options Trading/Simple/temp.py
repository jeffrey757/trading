# ============================================================
# VOLATILITY ANALYSIS GUI (Stable Version)
# GARCH + Realized + Optional Implied Vol
# ============================================================

import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq
from arch import arch_model
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from pandas_datareader import data as pdr
from datetime import datetime

# ============================================================
# BLACK-SCHOLES FUNCTIONS
# ============================================================

def black_scholes_call(S, K, T, r, sigma):
    if sigma <= 0 or T <= 0:
        return 0
    d1 = (np.log(S/K) + (r + 0.5*sigma**2)*T) / (sigma*np.sqrt(T))
    d2 = d1 - sigma*np.sqrt(T)
    return S * norm.cdf(d1) - K * np.exp(-r*T) * norm.cdf(d2)

def implied_vol_call(C_market, S, K, T, r):
    if C_market <= 0 or T <= 0:
        return np.nan
    def objective(sigma):
        return black_scholes_call(S, K, T, r, sigma) - C_market
    try:
        return brentq(objective, 1e-6, 5.0)
    except:
        return np.nan

# ============================================================
# MAIN ANALYSIS FUNCTION
# ============================================================

def run_analysis():

    ticker = ticker_entry.get().upper()
    risk_free = float(risk_entry.get())
    expiration = expiration_entry.get()

    try:
        status_label.config(text="Downloading price data...")
        root.update()

        # Download from Stooq
        data = pdr.DataReader(f"{ticker}.US", "stooq",
                              "2018-01-01",
                              datetime.today().strftime("%Y-%m-%d"))
        data = data.sort_index()

        if len(data) == 0:
            raise ValueError("No historical data found.")

        S = data["Close"].iloc[-1]
        returns = 100 * data["Close"].pct_change().dropna()

        # GARCH
        status_label.config(text="Fitting GARCH...")
        root.update()

        model = arch_model(returns, vol='GARCH', p=1, q=1)
        res = model.fit(disp="off")

        garch_daily = res.conditional_volatility
        garch_annual = garch_daily * np.sqrt(252) / 100
        latest_garch = garch_annual.iloc[-1]

        # Realized
        realized_vol = returns.rolling(252).std()
        realized_annual = realized_vol * np.sqrt(252) / 100
        latest_realized = realized_annual.iloc[-1]

        iv_atm = None
        vol_spread = None

        # Optional option file
        if option_file_path.get() != "":

            options = pd.read_csv(option_file_path.get())

            T = (pd.to_datetime(expiration) -
                 pd.Timestamp.today()).days / 365

            if "strike" in options.columns and "lastPrice" in options.columns:

                options["IV"] = options.apply(
                    lambda row: implied_vol_call(
                        row["lastPrice"], S,
                        row["strike"], T, risk_free),
                    axis=1
                )

                options = options.dropna(subset=["IV"])

                if len(options) > 0:
                    options["distance"] = abs(options["strike"] - S)
                    atm_row = options.loc[
                        options["distance"].idxmin()
                    ]
                    iv_atm = atm_row["IV"]
                    vol_spread = iv_atm - latest_garch

        # Update result text
        result_text.set(
            f"Price: {S:.4f}\n"
            f"GARCH Vol: {latest_garch:.4f}\n"
            f"Realized Vol: {latest_realized:.4f}\n"
            f"Implied Vol: {iv_atm if iv_atm else 'N/A'}\n"
            f"Vol Risk Premium: {vol_spread if vol_spread else 'N/A'}"
        )

        # Plot inside GUI
        fig.clear()
        ax = fig.add_subplot(111)

        ax.plot(garch_annual, label="GARCH")
        ax.plot(realized_annual, label="Realized")

        if iv_atm:
            ax.axhline(iv_atm, color="red",
                       linestyle="--", label="ATM IV")

        ax.set_title(f"{ticker} Volatility Comparison")
        ax.legend()

        canvas.draw()

        status_label.config(text="Analysis Complete")

    except Exception as e:
        messagebox.showerror("Error", str(e))
        status_label.config(text="Error")

# ============================================================
# FILE SELECTOR
# ============================================================

def select_option_file():
    file_path = filedialog.askopenfilename(
        title="Select Option CSV",
        filetypes=[("CSV Files", "*.csv")]
    )
    if file_path:
        option_file_path.set(file_path)

# ============================================================
# GUI SETUP
# ============================================================

root = tk.Tk()
root.title("Volatility Analysis Dashboard")
root.geometry("900x700")

# Inputs
tk.Label(root, text="Ticker:").pack()
ticker_entry = tk.Entry(root)
ticker_entry.insert(0, "AAPL")
ticker_entry.pack()

tk.Label(root, text="Option Expiration (YYYY-MM-DD):").pack()
expiration_entry = tk.Entry(root)
expiration_entry.insert(0, "2025-03-21")
expiration_entry.pack()

tk.Label(root, text="Risk-Free Rate:").pack()
risk_entry = tk.Entry(root)
risk_entry.insert(0, "0.05")
risk_entry.pack()

# Option file
option_file_path = tk.StringVar()
tk.Button(root, text="Select Option CSV (Optional)",
          command=select_option_file).pack()

tk.Label(root, textvariable=option_file_path).pack()

# Run button
tk.Button(root, text="Run Analysis",
          command=run_analysis,
          bg="green", fg="white").pack(pady=10)

# Results
result_text = tk.StringVar()
tk.Label(root, textvariable=result_text,
         justify="left", font=("Arial", 12)).pack()

# Chart area
fig = plt.Figure(figsize=(8,5))
canvas = FigureCanvasTkAgg(fig, master=root)
canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

status_label = tk.Label(root, text="Ready")
status_label.pack(pady=10)

root.mainloop()
