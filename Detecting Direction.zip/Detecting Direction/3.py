# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 08:46:25 2026

@author: Administrator
"""

# ==========================================================
# CHAPTER 3 – EMPIRICAL RESULTS GENERATION
# Logistic Regression vs Random Forest
# ==========================================================

import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    confusion_matrix,
    accuracy_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve
)
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from scipy import stats

# ==========================================================
# 1. LOAD DATA
# ==========================================================

df = pd.read_csv("data.csv")
df['Date'] = pd.to_datetime(df['time'])
df = df.sort_values("Date")

# ==========================================================
# 2. FEATURE CONSTRUCTION
# ==========================================================

# Daily return
df['Return'] = df['close'].pct_change()

# Lagged returns
df['Lag1'] = df['Return'].shift(1)
df['Lag2'] = df['Return'].shift(2)
df['Lag3'] = df['Return'].shift(3)

# Moving Average
df['MA5'] = df['close'].rolling(5).mean()

# Rolling volatility
df['Vol5'] = df['Return'].rolling(5).std()

# Drop NA values
df = df.dropna()

# ==========================================================
# 3. DEPENDENT VARIABLE
# ==========================================================

df['Direction'] = np.where(df['Return'] > 0, 1, 0)

# ==========================================================
# 4. TRAIN / TEST SPLIT
# ==========================================================

features = ['Lag1', 'Lag2', 'Lag3', 'MA5', 'Vol5']
X = df[features]
y = df['Direction']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.30, shuffle=False
)

# ==========================================================
# 5. STANDARDIZATION (Logistic only)
# ==========================================================

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ==========================================================
# 6. MODEL TRAINING
# ==========================================================

# Logistic Regression
log_model = LogisticRegression()
log_model.fit(X_train_scaled, y_train)

# Random Forest
rf_model = RandomForestClassifier(
    n_estimators=200,
    max_depth=5,
    min_samples_leaf=10,
    random_state=42
)
rf_model.fit(X_train, y_train)

# ==========================================================
# 7. PREDICTIONS
# ==========================================================

log_probs = log_model.predict_proba(X_test_scaled)[:, 1]
rf_probs = rf_model.predict_proba(X_test)[:, 1]

log_pred = (log_probs > 0.5).astype(int)
rf_pred = (rf_probs > 0.5).astype(int)

# ==========================================================
# 8. CONFUSION MATRICES
# ==========================================================

cm_log = confusion_matrix(y_test, log_pred)
cm_rf = confusion_matrix(y_test, rf_pred)

print("\n=== TABLE 3.1 Logistic Confusion Matrix ===")
print(cm_log)

print("\n=== TABLE 3.2 Random Forest Confusion Matrix ===")
print(cm_rf)

# ==========================================================
# 9. CLASSIFICATION METRICS
# ==========================================================

def evaluate_model(y_true, y_pred, y_prob):
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred)
    rec = recall_score(y_true, y_pred)
    auc = roc_auc_score(y_true, y_prob)
    return acc, prec, rec, auc

log_metrics = evaluate_model(y_test, log_pred, log_probs)
rf_metrics = evaluate_model(y_test, rf_pred, rf_probs)

results_table = pd.DataFrame({
    "Metric": ["Accuracy", "Precision", "Recall", "ROC-AUC"],
    "Logistic Regression": log_metrics,
    "Random Forest": rf_metrics
})

print("\n=== TABLE 3.3–3.5 Classification Metrics ===")
print(results_table)

# ==========================================================
# 10. STATISTICAL SIGNIFICANCE TEST
# ==========================================================

# Paired comparison of prediction errors
log_errors = (log_pred != y_test).astype(int)
rf_errors = (rf_pred != y_test).astype(int)

t_stat, p_value = stats.ttest_rel(log_errors, rf_errors)

print("\n=== Accuracy Difference Test ===")
print("t-statistic:", t_stat)
print("p-value:", p_value)

# ==========================================================
# 11. TRADING STRATEGY
# ==========================================================

returns_test = df.loc[y_test.index, 'Return']

def trading_performance(probs, returns, cost=0.001):
    positions = np.where(probs > 0.5, 1, -1)
    strategy_returns = positions * returns.values

    # transaction cost
    trades = np.abs(np.diff(positions))
    trades = np.insert(trades, 0, 0)
    strategy_returns -= trades * cost

    cumulative_return = np.prod(1 + strategy_returns) - 1
    annualized_return = (1 + cumulative_return) ** (252/len(strategy_returns)) - 1
    sharpe = np.mean(strategy_returns) / np.std(strategy_returns) * np.sqrt(252)

    # Max drawdown
    cumulative_curve = np.cumprod(1 + strategy_returns)
    peak = np.maximum.accumulate(cumulative_curve)
    drawdown = (cumulative_curve - peak) / peak
    max_drawdown = np.min(drawdown)

    return cumulative_return, annualized_return, sharpe, max_drawdown

log_trading = trading_performance(log_probs, returns_test)
rf_trading = trading_performance(rf_probs, returns_test)

trading_table = pd.DataFrame({
    "Metric": ["Cumulative Return", "Annualized Return", "Sharpe Ratio", "Max Drawdown"],
    "Logistic Regression": log_trading,
    "Random Forest": rf_trading
})

print("\n=== TABLE 3.6–3.7 Trading Performance ===")
print(trading_table)

# ==========================================================
# 12. TRANSACTION COST SENSITIVITY
# ==========================================================

log_cost_high = trading_performance(log_probs, returns_test, cost=0.002)
rf_cost_high = trading_performance(rf_probs, returns_test, cost=0.002)

cost_table = pd.DataFrame({
    "Metric": ["Cumulative Return (0.2% cost)", "Sharpe Ratio (0.2% cost)"],
    "Logistic Regression": [log_cost_high[0], log_cost_high[2]],
    "Random Forest": [rf_cost_high[0], rf_cost_high[2]]
})

print("\n=== TABLE 3.8 Transaction Cost Sensitivity ===")
print(cost_table)

# ==========================================================
# END
# ==========================================================
