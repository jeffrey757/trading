# -*- coding: utf-8 -*-
"""
Created on Mon Feb 16 08:49:02 2026

@author: Administrator
"""

# ==========================================================
# CHAPTER 2 – TABLE GENERATION (DATA + METHODOLOGY TABLES)
# Logistic Regression vs Random Forest (binary direction)
# ==========================================================
# INPUT FILE EXPECTED:
#   data.csv with at least columns: Date, Close
# OPTIONAL columns (used if present): Open, High, Low, Volume, Adj Close
#
# OUTPUT:
#   Prints Chapter 2 tables to console
#   Saves each table as CSV under ./chapter2_tables/
# ==========================================================

import os
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

# -----------------------------
# Settings
# -----------------------------
DATA_PATH = "data.csv"
OUT_DIR = "chapter2_tables"
TEST_SIZE = 0.30          # 70/30 split (as Chapter 2)
SHUFFLE = False           # IMPORTANT for time series
RF_PARAMS = {
    "n_estimators": 200,
    "max_depth": 5,
    "min_samples_leaf": 10,
    "random_state": 42
}

os.makedirs(OUT_DIR, exist_ok=True)

def safe_to_csv(df: pd.DataFrame, filename: str) -> None:
    """Save DataFrame as CSV with a consistent path."""
    path = os.path.join(OUT_DIR, filename)
    df.to_csv(path, index=True)

# ==========================================================
# 1) Load & basic cleaning
# ==========================================================
df = pd.read_csv(DATA_PATH)

# Basic validation
required = {"time", "close"}
missing = required - set(df.columns)
if missing:
    raise ValueError(f"Missing required column(s): {sorted(list(missing))}. "
                     f"Your CSV must include at least: Date, Close")

df["time"] = pd.to_datetime(df["time"], errors="coerce")
df = df.dropna(subset=["time", "close"]).copy()
df = df.sort_values("time").reset_index(drop=True)

# ==========================================================
# 2) Feature construction (Chapter 2)
# ==========================================================
# Daily return (simple return)
df["Return"] = df["close"].pct_change()

# Lagged returns
df["Lag1"] = df["Return"].shift(1)
df["Lag2"] = df["Return"].shift(2)
df["Lag3"] = df["Return"].shift(3)

# Moving average (MA5)
df["MA5"] = df["close"].rolling(5).mean()

# Rolling volatility (Vol5)
df["Vol5"] = df["Return"].rolling(5).std()

# Direction (dependent variable)
df["Direction"] = np.where(df["Return"] > 0, 1, 0)

# Drop rows with NA created by rolling/lags
df_model = df.dropna(subset=["Return", "Lag1", "Lag2", "Lag3", "MA5", "Vol5", "Direction"]).copy()

# ==========================================================
# TABLE 2.1 – Data Summary Statistics
# (Return and Volume if present)
# ==========================================================
summary_vars = ["Return"]
if "Volume" in df_model.columns:
    summary_vars.append("Volume")

table_2_1 = df_model[summary_vars].agg(["mean", "std", "min", "max"]).T
table_2_1.columns = ["Mean", "Std Dev", "Min", "Max"]
table_2_1.index.name = "Variable"

print("\n=== TABLE 2.1 Data Summary Statistics ===")
print(table_2_1.round(6))
safe_to_csv(table_2_1.round(6), "Table_2_1_Data_Summary_Statistics.csv")

# ==========================================================
# TABLE 2.2 – Distribution of Up and Down Days
# ==========================================================
counts = df_model["Direction"].value_counts().sort_index()
total_n = int(counts.sum())

# Ensure both classes exist in table display
up_count = int(counts.get(1, 0))
down_count = int(counts.get(0, 0))

table_2_2 = pd.DataFrame({
    "Direction": ["Up (1)", "Down (0)"],
    "Count": [up_count, down_count],
    "Percentage": [
        (up_count / total_n) if total_n else np.nan,
        (down_count / total_n) if total_n else np.nan
    ]
})
table_2_2["Percentage"] = (table_2_2["Percentage"] * 100).round(2).astype(str) + "%"

print("\n=== TABLE 2.2 Distribution of Up and Down Days ===")
print(table_2_2.to_string(index=False))
safe_to_csv(table_2_2, "Table_2_2_Up_Down_Distribution.csv")

# ==========================================================
# TABLE 2.3 – Variable Construction Summary
# (Formula text + economic meaning)
# ==========================================================
table_2_3 = pd.DataFrame([
    {
        "Variable": "Return",
        "Formula": "r_t = (Close_t - Close_{t-1}) / Close_{t-1}",
        "Economic Meaning": "Daily percentage price change"
    },
    {
        "Variable": "Direction",
        "Formula": "1 if r_t > 0 else 0",
        "Economic Meaning": "Binary up/down outcome to predict"
    },
    {
        "Variable": "Lag1",
        "Formula": "r_{t-1}",
        "Economic Meaning": "1-day momentum / short-term autocorrelation"
    },
    {
        "Variable": "Lag2",
        "Formula": "r_{t-2}",
        "Economic Meaning": "2-day lag return signal"
    },
    {
        "Variable": "Lag3",
        "Formula": "r_{t-3}",
        "Economic Meaning": "3-day lag return signal"
    },
    {
        "Variable": "MA5",
        "Formula": "MA5_t = (1/5) * Σ_{i=0..4} Close_{t-i}",
        "Economic Meaning": "Short-term trend / smoothing"
    },
    {
        "Variable": "Vol5",
        "Formula": "Vol5_t = StdDev(Return over last 5 days)",
        "Economic Meaning": "Recent risk / uncertainty"
    }
])

print("\n=== TABLE 2.3 Variable Construction Summary ===")
print(table_2_3.to_string(index=False))
safe_to_csv(table_2_3, "Table_2_3_Variable_Construction_Summary.csv")

# ==========================================================
# 3) Train/Test Split (Chapter 2)
# ==========================================================
features = ["Lag1", "Lag2", "Lag3", "MA5", "Vol5"]
X = df_model[features].copy()
y = df_model["Direction"].astype(int).copy()

# Time-series split: shuffle=False
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=TEST_SIZE, shuffle=SHUFFLE
)

# ==========================================================
# TABLE 2.6 – Sample Split
# ==========================================================
table_2_6 = pd.DataFrame({
    "Sample": ["Training", "Testing", "Total"],
    "Observations": [len(X_train), len(X_test), len(X_train) + len(X_test)]
})

print("\n=== TABLE 2.6 Sample Split ===")
print(table_2_6.to_string(index=False))
safe_to_csv(table_2_6, "Table_2_6_Sample_Split.csv")

# ==========================================================
# 4) Standardization (mainly for Logistic Regression)
# ==========================================================
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Optional: show scaling parameters as a “preprocessing table”
table_2_preproc = pd.DataFrame({
    "Feature": features,
    "Train Mean (μ)": scaler.mean_,
    "Train Std (σ)": np.sqrt(scaler.var_)
}).set_index("Feature")

print("\n=== (Optional) Preprocessing Summary: Standardization Parameters ===")
print(table_2_preproc.round(6))
safe_to_csv(table_2_preproc.round(6), "Table_2_Preprocessing_Standardization.csv")

# ==========================================================
# 5) Fit models (to generate Chapter 2 model tables)
# ==========================================================
# Logistic Regression (simple baseline)
log_model = LogisticRegression(max_iter=1000)
log_model.fit(X_train_scaled, y_train)

# Random Forest (with thesis parameters)
rf_model = RandomForestClassifier(**RF_PARAMS)
rf_model.fit(X_train, y_train)

# ==========================================================
# TABLE 2.4 – Logistic Regression Coefficients
# (Coefficient interpretation: positive increases odds of Up)
# ==========================================================
coef = log_model.coef_.ravel()
intercept = float(log_model.intercept_[0])

table_2_4 = pd.DataFrame({
    "Variable": ["Intercept"] + features,
    "Coefficient": [intercept] + list(coef)
})

# A simple “directional” interpretation text column
def coef_interpretation(c: float) -> str:
    if c > 0:
        return "Positive: increases probability of Up"
    elif c < 0:
        return "Negative: decreases probability of Up"
    return "Near zero: weak effect"

table_2_4["Interpretation"] = table_2_4["Coefficient"].apply(coef_interpretation)

print("\n=== TABLE 2.4 Logistic Regression Coefficients ===")
print(table_2_4.round(6).to_string(index=False))
safe_to_csv(table_2_4.round(6), "Table_2_4_Logistic_Coefficients.csv")

# ==========================================================
# TABLE 2.5 – Random Forest Parameters
# ==========================================================
table_2_5 = pd.DataFrame({
    "Parameter": list(RF_PARAMS.keys()),
    "Value": list(RF_PARAMS.values())
})

print("\n=== TABLE 2.5 Random Forest Parameters ===")
print(table_2_5.to_string(index=False))
safe_to_csv(table_2_5, "Table_2_5_Random_Forest_Parameters.csv")

# ==========================================================
# (Optional but useful) Feature Importance Table (RF)
# Not always in Chapter 2, but many theses include it early.
# ==========================================================
if hasattr(rf_model, "feature_importances_"):
    table_rf_imp = pd.DataFrame({
        "Feature": features,
        "Importance": rf_model.feature_importances_
    }).sort_values("Importance", ascending=False).set_index("Feature")

    print("\n=== (Optional) Random Forest Feature Importances ===")
    print(table_rf_imp.round(6))
    safe_to_csv(table_rf_imp.round(6), "Table_2_Optional_RF_Feature_Importances.csv")

# ==========================================================
# Done
# ==========================================================
print(f"\nAll Chapter 2 tables saved to: ./{OUT_DIR}/")
