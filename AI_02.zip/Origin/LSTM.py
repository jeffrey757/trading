# Step 1: Import necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from sklearn.model_selection import train_test_split
import time

# Step 2: Load the dataset
print("Step 1: Loading data...")
data = pd.read_csv('GOLD.csv', date_parser=True)

# Ensure 'datetime' column is in datetime format and set it as the index
data['datetime'] = pd.to_datetime(data['Date'])
data.set_index('datetime', inplace=True)

# Step 3: Visualize the data (optional)
print("Step 2: Visualizing data...")
data['Close'].plot(figsize=(12, 6))
plt.title('GOLD Price')
plt.xlabel('Time')
plt.ylabel('Price')
plt.show()

# Step 4: Prepare the data for LSTM (Scaling)
print("Step 3: Scaling data...")
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(data[['Close']])

# Step 5: Create a function to prepare data for LSTM
def create_dataset(data, time_step=60):
    X, y = [], []
    for i in range(time_step, len(data)):
        X.append(data[i-time_step:i, 0])  # Use last 'time_step' prices as input features
        y.append(data[i, 0])  # Predict the next price
    return np.array(X), np.array(y)

# Step 6: Prepare the training and test datasets
print("Step 4: Preparing dataset...")
time_step = 60  # Use 60 minutes (1 hour) to predict the next price

X, y = create_dataset(scaled_data, time_step)

# Reshape X to be [samples, time_step, features] for LSTM input
X = np.reshape(X, (X.shape[0], X.shape[1], 1))

# Step 7: Split data into training and testing sets
print("Step 5: Splitting data into train and test sets...")
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# Step 8: Build the LSTM model
print("Step 6: Building the LSTM model...")
model = Sequential()

# Add LSTM layers
model.add(LSTM(units=50, return_sequences=True, input_shape=(X_train.shape[1], 1)))
model.add(Dropout(0.2))  # Dropout to avoid overfitting
model.add(LSTM(units=50, return_sequences=False))
model.add(Dropout(0.2))

# Output layer
model.add(Dense(units=1))  # Predict the next price

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

# Step 9: Train the model
print("Step 7: Training the model...")
start_time = time.time()
history = model.fit(X_train, y_train, epochs=20, batch_size=32)
end_time = time.time()
elapsed_time = end_time - start_time
print(f"Training completed in {elapsed_time:.2f} seconds.")

# Step 10: Predict on test data
print("Step 8: Making predictions...")
predicted_price = model.predict(X_test)

# Step 11: Inverse transform the predicted values and the actual values
predicted_price = scaler.inverse_transform(predicted_price)
y_test_actual = scaler.inverse_transform(y_test.reshape(-1, 1))

# Step 12: Visualize the results
print("Step 9: Visualizing results...")
plt.figure(figsize=(12, 6))
plt.plot(y_test_actual, color='blue', label='Actual Price')
plt.plot(predicted_price, color='red', label='Predicted Price')
plt.title('GOLD Price Prediction using LSTM')
plt.xlabel('Time')
plt.ylabel('Price')
plt.legend()
plt.show()

# Step 13: Save the model (optional)
print("Step 10: Saving the model...")
model.save('gold_price_lstm_model.h5')

# You can load the model back with this:
# from tensorflow.keras.models import load_model
# loaded_model = load_model('gold_price_lstm_model.h5')
