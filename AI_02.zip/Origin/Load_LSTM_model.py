# Step 1: Import necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import load_model
import time

# Step 2: Load the dataset
print("Step 1: Loading data...")
data = pd.read_csv('GOLD.csv', date_parser=True)

# Ensure 'datetime' column is in datetime format and set it as the index
data['datetime'] = pd.to_datetime(data['Date'])  # Adjust the column name if needed
data.set_index('datetime', inplace=True)

# Step 3: Visualize the data (optional)
print("Step 2: Visualizing data...")
data['Close'].plot(figsize=(12, 6))
plt.title('GOLD Price')
plt.xlabel('Time')
plt.ylabel('Price')
plt.show()

# Step 4: Scaling the data
print("Step 3: Scaling data...")
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(data[['Close']])

# Step 5: Prepare the data for prediction (using the last 60 minutes for prediction)
def create_dataset(data, time_step=60):
    X = data[-time_step:].reshape(1, time_step, 1)
    return X

# Get the most recent 60 minutes of data
recent_data = create_dataset(scaled_data, time_step=60)

# Step 6: Load the trained LSTM model
print("Step 4: Loading the trained LSTM model...")
model = load_model('gold_price_lstm_model.h5')  # Load the saved model

# Step 7: Predict the next GOLD price
print("Step 5: Making predictions...")
predicted_price = model.predict(recent_data)

# Step 8: Inverse transform the prediction to get the actual price
predicted_price = scaler.inverse_transform(predicted_price)
print(f"Predicted GOLD Price for the next minute: {predicted_price[0][0]}")

# Step 9: Predict multiple future prices (for the next 10 minutes, for example)
n_predictions = 10
predicted_prices = []

# Loop to predict the next 10 prices
for _ in range(n_predictions):
    predicted_price = model.predict(recent_data)
    predicted_prices.append(predicted_price[0, 0])  # Append the predicted value
    # Update the input for the next prediction
    recent_data = np.append(recent_data[:, 1:, :], predicted_price.reshape(1, 1, 1), axis=1)

# Inverse transform the predicted prices
predicted_prices = scaler.inverse_transform(np.array(predicted_prices).reshape(-1, 1))

print("Predicted GOLD Prices for the next 10 minutes:", predicted_prices)

# Step 10: Visualize the predicted prices
plt.figure(figsize=(12, 6))
plt.plot(predicted_prices, color='red', label='Predicted Prices')
plt.title('GOLD Price Prediction for Next 10 Minutes')
plt.xlabel('Time (minutes)')
plt.ylabel('Price')
plt.legend()
plt.show()

# Step 11: Save the model for future use (if not already done)
print("Step 6: Saving the model (if required)...")
model.save('gold_price_lstm_model.h5')  # Saving the model again (if you made any changes)
