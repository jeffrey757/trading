import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime
import time

# Initialize connection to MetaTrader 5
mt5.initialize()

# Define parameters
symbol = "GOLD"  # Example symbol for GOLD
timeframe = mt5.TIMEFRAME_M1  # 1-minute data
data_points = 100  # Number of data points to fetch

# Check if the CSV exists and load it if present
csv_file = "XAUUSD_live_price_data.csv"
try:
    # If the file exists, load the existing data
    data = pd.read_csv(csv_file)
    print(f"Loaded existing data from {csv_file}")
except FileNotFoundError:
    # If the file does not exist, create a new DataFrame
    data = pd.DataFrame()

# Start the loop to update data every minute
while True:
    # Request the latest 1-minute data
    rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, data_points)

    if rates is None or len(rates) == 0:
        print("Failed to retrieve data.")
        time.sleep(60)  # Sleep for 1 minute before trying again
        continue

    # Convert the data into a pandas DataFrame
    new_data = pd.DataFrame(rates)

    # Convert the 'time' column from UNIX timestamp to datetime
    new_data['datetime'] = pd.to_datetime(new_data['time'], unit='s')

    # Drop the original 'time' column
    new_data.drop(columns=['time'], inplace=True, errors='ignore')

    # Concatenate the new data to the existing data
    data = pd.concat([data, new_data], ignore_index=True)

    # Remove duplicates (if any) based on the datetime column (in case of overlapping data)
    data = data.drop_duplicates(subset=['datetime'], keep='last')

    # Save the updated data to the CSV file
    data.to_csv(csv_file, index=False)

    print(f"Data updated and saved at {datetime.now()}")

    # Sleep for 1 minute before fetching the new data
    time.sleep(60)

# Shutdown MT5 connection after the loop (optional, but useful when you stop the loop manually)
mt5.shutdown()
