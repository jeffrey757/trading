# -*- coding: utf-8 -*-
"""
Created on Fri Feb 13 09:53:46 2026

@author: Administrator
"""

# -*- coding: utf-8 -*-
"""
FULLY ALGORITHMIC MT5 TRADING BOT (Python / MetaTrader5)

Features
- Live loop (M1) with robust MT5 init + symbol select
- Regime classification: TRENDING / SIDEWAYS / CHOPPY
- TRENDING entries: EMA(21/55) + ATR separation filter
- SIDEWAYS entries: Bollinger+RSI mean reversion (optional re-entry confirmation)
- SIDEWAYS exits (your rules):
    * close at BB midline
    * SL at outer band ± ATR
    * TP at opposite band
- Risk-based position sizing (% equity)
- Execution filters:
    * max spread filter
    * trading session filter
    * optional news blackout via Finnhub economic calendar
- Trade management:
    * only 1 position at a time
    * "one signal per regime change" (debounced)
    * cooldown between trades
    * close logic differs for TRENDING vs SIDEWAYS (tagged by comment)
- Logging prints with key metrics

Requirements:
  pip install MetaTrader5 pandas numpy requests

Notes:
- PAPER_MODE=True prints orders instead of sending.
- Make sure MT5 terminal is running and logged in to your broker.
"""

import os
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
import requests
import MetaTrader5 as mt5

# ============================================================
# CONFIG
# ============================================================

SYMBOL = "GOLD"
TIMEFRAME = mt5.TIMEFRAME_M1
BARS = 800                 # warmup bars
MIN_BARS_READY = 150       # stability threshold

PAPER_MODE = True          # set False to trade
MAGIC = 20260213

# Risk & trade constraints
RISK_PER_TRADE = 0.005     # 0.5% equity risk per trade
MAX_LOT = 5.0
MIN_LOT = 0.01
LOT_STEP_FALLBACK = 0.01   # used if broker does not provide volume_step
DEVIATION = 20
COOLDOWN_SECONDS = 60
ONE_POSITION_ONLY = True

# Execution filters
MAX_SPREAD_POINTS = 250    # points (broker-dependent; tune for GOLD)
USE_SESSION_FILTER = True
SESSION_START_HHMM = "01:00"   # UTC by default
SESSION_END_HHMM = "22:00"     # UTC by default

# ATR/EMA parameters
ATR_LEN = 14
EMA_FAST = 21
EMA_SLOW = 55

# TRENDING SL/TP (ATR multiples)
TREND_SL_ATR = 1.5
TREND_TP_ATR = 2.0

# Regime thresholds (tune per symbol)
ADX_TREND = 28
ADX_WEAK = 18
ADX_EXIT = 20
ER_TREND = 0.35
ER_WEAK = 0.25
WHIP_CHOP = 0.30

# TRENDING quality gate
MIN_SEP_ATR = 0.10   # |ema_fast - ema_slow| / ATR

# SIDEWAYS mean reversion
SIDEWAYS_BB_LEN = 20
SIDEWAYS_BB_STD = 2.0
SIDEWAYS_RSI_LEN = 14
SIDEWAYS_RSI_BUY = 30
SIDEWAYS_RSI_SELL = 70
SIDEWAYS_REQUIRE_REENTRY = True
SIDEWAYS_COMMENT = "ALGOBOT_SW"   # tag for sideways positions
TREND_COMMENT = "ALGOBOT_TR"      # tag for trending positions

# One-signal-per-regime-change
ENFORCE_ONE_SIGNAL_PER_REGIME_CHANGE = True

# Optional news blackout via Finnhub economic calendar
USE_NEWS_BLACKOUT = False
ONLY_IMPACTS = ("high",)
FINNHUB_API_KEY = os.getenv("FINNHUB_API_KEY", "")

MAJOR_15_KEYS = [
    "cpi", "consumer price",
    "non-farm", "nfp",
    "fomc", "fed rate", "interest rate decision",
    "powell", "press conference"
]

# ============================================================
# STATE
# ============================================================

@dataclass
class BotState:
    last_trade_time: datetime
    last_regime: str
    last_regime_signal_sent: bool

STATE = BotState(
    last_trade_time=datetime.min.replace(tzinfo=timezone.utc),
    last_regime="UNKNOWN",
    last_regime_signal_sent=False
)

# ============================================================
# MT5 HELPERS
# ============================================================

def mt5_init():
    if not mt5.initialize():
        raise SystemExit(f"MT5 initialize failed: {mt5.last_error()}")
    if not mt5.symbol_select(SYMBOL, True):
        raise SystemExit(f"symbol_select({SYMBOL}) failed: {mt5.last_error()}")

def mt5_shutdown():
    mt5.shutdown()

def get_bars(symbol: str, count: int) -> pd.DataFrame:
    rates = mt5.copy_rates_from_pos(symbol, TIMEFRAME, 0, count)
    if rates is None or len(rates) == 0:
        return pd.DataFrame()
    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time")
    df.rename(columns={"open":"Open","high":"High","low":"Low","close":"Close","tick_volume":"Volume"}, inplace=True)
    return df[["Open","High","Low","Close","Volume"]]

def last_tick(symbol: str):
    return mt5.symbol_info_tick(symbol)

def get_positions(symbol: str):
    return mt5.positions_get(symbol=symbol)

def symbol_info(symbol: str):
    return mt5.symbol_info(symbol)

def account_info():
    return mt5.account_info()

def spread_points(symbol: str) -> int | None:
    tick = last_tick(symbol)
    if tick is None:
        return None
    info = symbol_info(symbol)
    if info is None or info.point is None or info.point <= 0:
        return None
    return int(round((tick.ask - tick.bid) / info.point))

def in_session(now_utc: datetime) -> bool:
    if not USE_SESSION_FILTER:
        return True
    sh, sm = map(int, SESSION_START_HHMM.split(":"))
    eh, em = map(int, SESSION_END_HHMM.split(":"))
    start = now_utc.replace(hour=sh, minute=sm, second=0, microsecond=0)
    end = now_utc.replace(hour=eh, minute=em, second=0, microsecond=0)

    # handle overnight sessions
    if end <= start:
        return (now_utc >= start) or (now_utc < end)
    return (start <= now_utc < end)

# ============================================================
# INDICATORS
# ============================================================

def rma(x: pd.Series, length: int) -> pd.Series:
    return x.ewm(alpha=1/length, adjust=False).mean()

def ema(x: pd.Series, length: int) -> pd.Series:
    return x.ewm(span=length, adjust=False).mean()

def atr(df: pd.DataFrame, length: int = 14) -> pd.Series:
    h, l, c = df["High"], df["Low"], df["Close"]
    pc = c.shift(1)
    tr = pd.concat([(h-l), (h-pc).abs(), (l-pc).abs()], axis=1).max(axis=1)
    return rma(tr, length)

def adx(df: pd.DataFrame, length: int = 14) -> pd.Series:
    h, l = df["High"], df["Low"]
    up = h.diff()
    dn = -l.diff()
    plus_dm  = np.where((up > dn) & (up > 0), up, 0.0)
    minus_dm = np.where((dn > up) & (dn > 0), dn, 0.0)
    a = atr(df, length)
    plus_di  = 100 * rma(pd.Series(plus_dm, index=df.index), length) / a
    minus_di = 100 * rma(pd.Series(minus_dm, index=df.index), length) / a
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
    return rma(dx, length)

def efficiency_ratio(close: pd.Series, length: int = 10) -> pd.Series:
    change = close.diff(length).abs()
    vol = close.diff().abs().rolling(length).sum()
    return change / vol

def whipsaw_rate(bool_signal: pd.Series, length: int = 10) -> pd.Series:
    flips = bool_signal.astype(int).diff().abs()
    return flips.rolling(length).sum() / length

def rsi(close: pd.Series, length: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = (-delta).clip(lower=0)
    avg_gain = rma(gain, length)
    avg_loss = rma(loss, length)
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def bollinger(close: pd.Series, length: int = 20, stdev: float = 2.0):
    mid = close.rolling(length).mean()
    sd = close.rolling(length).std(ddof=0)
    upper = mid + stdev * sd
    lower = mid - stdev * sd
    return mid, upper, lower

# ============================================================
# REGIME
# ============================================================

def classify_regime(df: pd.DataFrame) -> tuple[str, dict]:
    d = df.copy()
    d["ATR"] = atr(d, ATR_LEN)
    d["ADX"] = adx(d, 14)
    d["ER"] = efficiency_ratio(d["Close"], 10)
    d["WHIP"] = whipsaw_rate(d["Close"] > d["Close"].rolling(3).mean(), 10)

    last = d.iloc[-1]
    adx_v = float(last["ADX"]) if pd.notna(last["ADX"]) else np.nan
    er_v  = float(last["ER"]) if pd.notna(last["ER"]) else np.nan
    whip  = float(last["WHIP"]) if pd.notna(last["WHIP"]) else np.nan

    if not np.isfinite(adx_v) or not np.isfinite(er_v) or not np.isfinite(whip):
        return "UNKNOWN", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

    if adx_v >= ADX_TREND and er_v >= ER_TREND:
        return "TRENDING", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

    if adx_v < ADX_WEAK:
        if er_v < ER_WEAK or whip > WHIP_CHOP:
            return "CHOPPY", {"ADX": adx_v, "ER": er_v, "WHIP": whip}
        return "SIDEWAYS", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

    # mid zone
    if er_v >= 0.40 and whip <= 0.25:
        return "TRENDING", {"ADX": adx_v, "ER": er_v, "WHIP": whip}
    if whip > WHIP_CHOP:
        return "CHOPPY", {"ADX": adx_v, "ER": er_v, "WHIP": whip}
    return "SIDEWAYS", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

# ============================================================
# SIGNALS
# ============================================================

def trending_signal(df: pd.DataFrame) -> tuple[str, str]:
    d = df.copy()
    d["EMA_fast"] = ema(d["Close"], EMA_FAST)
    d["EMA_slow"] = ema(d["Close"], EMA_SLOW)
    fast = float(d["EMA_fast"].iloc[-1])
    slow = float(d["EMA_slow"].iloc[-1])

    a = float(atr(d, ATR_LEN).iloc[-1])
    if not np.isfinite(a) or a <= 0:
        return "FLAT", "NO_TRADE"
    sep = abs(fast - slow) / a
    if sep < MIN_SEP_ATR:
        return "FLAT", "NO_TRADE"
    return ("UPTREND", "BUY") if fast > slow else ("DOWNTREND", "SELL")

def sideways_levels(df: pd.DataFrame) -> dict | None:
    d = df.copy()
    d["ATR"] = atr(d, ATR_LEN)
    d["RSI"] = rsi(d["Close"], SIDEWAYS_RSI_LEN)
    mid, upper, lower = bollinger(d["Close"], SIDEWAYS_BB_LEN, SIDEWAYS_BB_STD)
    d["BB_MID"], d["BB_UPPER"], d["BB_LOWER"] = mid, upper, lower

    need = max(SIDEWAYS_BB_LEN, SIDEWAYS_RSI_LEN) + 5
    if len(d) < need:
        return None

    last = d.iloc[-1]
    prev = d.iloc[-2]

    for k in ["ATR","RSI","BB_MID","BB_UPPER","BB_LOWER","Close"]:
        if not np.isfinite(float(last[k])):
            return None

    return {
        "c": float(last["Close"]),
        "pc": float(prev["Close"]),
        "atr": float(last["ATR"]),
        "rsi": float(last["RSI"]),
        "mid": float(last["BB_MID"]),
        "up": float(last["BB_UPPER"]),
        "lo": float(last["BB_LOWER"]),
        "prev_up": float(prev["BB_UPPER"]) if np.isfinite(float(prev["BB_UPPER"])) else np.nan,
        "prev_lo": float(prev["BB_LOWER"]) if np.isfinite(float(prev["BB_LOWER"])) else np.nan,
    }

def sideways_signal(df: pd.DataFrame) -> str:
    lv = sideways_levels(df)
    if not lv:
        return "NO_TRADE"

    c, r, up, lo = lv["c"], lv["rsi"], lv["up"], lv["lo"]
    pc, prev_up, prev_lo = lv["pc"], lv["prev_up"], lv["prev_lo"]

    buy_stretch  = (c < lo) and (r <= SIDEWAYS_RSI_BUY)
    sell_stretch = (c > up) and (r >= SIDEWAYS_RSI_SELL)

    if not SIDEWAYS_REQUIRE_REENTRY:
        if buy_stretch:  return "BUY"
        if sell_stretch: return "SELL"
        return "NO_TRADE"

    buy_confirm  = np.isfinite(prev_lo) and (pc < prev_lo) and (c >= lo)
    sell_confirm = np.isfinite(prev_up) and (pc > prev_up) and (c <= up)

    if buy_stretch and buy_confirm:
        return "BUY"
    if sell_stretch and sell_confirm:
        return "SELL"
    return "NO_TRADE"

# ============================================================
# NEWS BLACKOUT (optional)
# ============================================================

def normalize_impact(x: str) -> str:
    x = (x or "").lower()
    if "high" in x: return "high"
    if "medium" in x: return "medium"
    if "low" in x: return "low"
    return "unknown"

def is_us_event(country: str) -> bool:
    c = (country or "").strip().upper()
    return c in {"US","UNITED STATES","USA"}

def blackout_minutes(event_name: str) -> int:
    name = (event_name or "").lower()
    return 15 if any(k in name for k in MAJOR_15_KEYS) else 10

def fetch_calendar_finnhub(start_utc_date: str, end_utc_date: str) -> list[dict]:
    if not FINNHUB_API_KEY:
        return []
    url = "https://finnhub.io/api/v1/calendar/economic"
    r = requests.get(url, params={"from": start_utc_date, "to": end_utc_date, "token": FINNHUB_API_KEY}, timeout=30)
    r.raise_for_status()
    data = r.json()
    items = data.get("economicCalendar", []) or []

    events = []
    for e in items:
        t_raw = e.get("time") or e.get("date") or e.get("datetime")
        if not t_raw:
            continue
        t = pd.to_datetime(t_raw, utc=True)
        events.append({
            "time": t,
            "type": (e.get("event") or e.get("name") or "").strip(),
            "impact": normalize_impact(e.get("impact") or e.get("importance") or ""),
            "country": (e.get("country") or "").strip(),
        })
    return events

def in_blackout(now_utc: datetime, events: list[dict]) -> tuple[bool, str]:
    for ev in events:
        if not is_us_event(ev.get("country","")):
            continue
        if ev.get("impact","unknown") not in ONLY_IMPACTS:
            continue
        t = pd.to_datetime(ev["time"], utc=True).to_pydatetime()
        mins = blackout_minutes(ev.get("type",""))
        if t <= now_utc < (t + timedelta(minutes=mins)):
            return True, f"{ev.get('type','NEWS')} ({mins}m blackout)"
    return False, ""

# ============================================================
# RISK / POSITION SIZING
# ============================================================

def clamp_to_step(value: float, step: float) -> float:
    if step <= 0:
        step = LOT_STEP_FALLBACK
    return round(round(value / step) * step, 10)

def calc_lot_for_risk(symbol: str, entry_price: float, sl_price: float) -> float:
    """
    Risk per trade in account currency, using symbol trade_tick_value / trade_tick_size.
    Approximation is standard for MT5 risk sizing.
    """
    acc = account_info()
    info = symbol_info(symbol)
    if acc is None or info is None:
        return MIN_LOT

    equity = float(acc.equity)
    risk_money = max(0.0, equity * RISK_PER_TRADE)

    tick_size = float(info.trade_tick_size) if info.trade_tick_size else 0.0
    tick_value = float(info.trade_tick_value) if info.trade_tick_value else 0.0
    if tick_size <= 0 or tick_value <= 0:
        return MIN_LOT

    sl_dist = abs(entry_price - sl_price)
    if sl_dist <= 0:
        return MIN_LOT

    # money risk per 1 lot = (sl_dist / tick_size) * tick_value
    money_per_lot = (sl_dist / tick_size) * tick_value
    if money_per_lot <= 0:
        return MIN_LOT

    raw_lot = risk_money / money_per_lot

    # clamp to broker constraints
    min_vol = float(info.volume_min) if info.volume_min else MIN_LOT
    max_vol = float(info.volume_max) if info.volume_max else MAX_LOT
    step = float(info.volume_step) if info.volume_step else LOT_STEP_FALLBACK

    lot = max(min_vol, min(max_vol, raw_lot))
    lot = clamp_to_step(lot, step)
    return float(max(min_vol, min(max_vol, lot)))

# ============================================================
# ORDER SEND / CLOSE
# ============================================================

def send_market_order(symbol: str, side: str, lot: float, sl: float, tp: float, comment: str):
    tick = last_tick(symbol)
    if tick is None:
        print("No tick:", mt5.last_error())
        return None

    price = tick.ask if side == "BUY" else tick.bid
    order_type = mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": float(lot),
        "type": order_type,
        "price": float(price),
        "sl": float(sl),
        "tp": float(tp),
        "deviation": int(DEVIATION),
        "magic": int(MAGIC),
        "comment": str(comment)[:31],
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    if PAPER_MODE:
        print("[PAPER] OPEN:", request)
        return {"retcode": "PAPER"}

    return mt5.order_send(request)

def close_position(position, reason: str = ""):
    symbol = position.symbol
    volume = position.volume
    side = "SELL" if position.type == mt5.POSITION_TYPE_BUY else "BUY"

    tick = last_tick(symbol)
    if tick is None:
        print("No tick:", mt5.last_error())
        return None

    price = tick.bid if side == "SELL" else tick.ask
    order_type = mt5.ORDER_TYPE_SELL if side == "SELL" else mt5.ORDER_TYPE_BUY

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "position": int(position.ticket),
        "volume": float(volume),
        "type": order_type,
        "price": float(price),
        "deviation": int(DEVIATION),
        "magic": int(MAGIC),
        "comment": f"ALGOBOT close: {reason}"[:31],
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    if PAPER_MODE:
        print("[PAPER] CLOSE:", request)
        return {"retcode": "PAPER"}

    return mt5.order_send(request)

# ============================================================
# SIDEWAYS SL/TP + MIDLINE CLOSE
# ============================================================

def sideways_sl_tp(df: pd.DataFrame, side: str) -> tuple[float, float] | None:
    lv = sideways_levels(df)
    if not lv:
        return None
    atr_v, up, lo = lv["atr"], lv["up"], lv["lo"]
    if not np.isfinite(atr_v) or atr_v <= 0:
        return None

    if side == "BUY":
        sl = lo - atr_v        # outer band - ATR
        tp = up                # opposite band
    else:
        sl = up + atr_v        # outer band + ATR
        tp = lo                # opposite band
    return float(sl), float(tp)

def should_close_position(df: pd.DataFrame, regime: str, position) -> tuple[bool, str]:
    pos_side = "BUY" if position.type == mt5.POSITION_TYPE_BUY else "SELL"
    pos_comment = getattr(position, "comment", "") or ""
    is_sideways_trade = (SIDEWAYS_COMMENT in pos_comment)

    if is_sideways_trade:
        # if regime changed away from sideways, exit
        if regime != "SIDEWAYS":
            return True, "Regime changed (not SIDEWAYS)"

        lv = sideways_levels(df)
        if not lv:
            return False, ""
        c, mid = lv["c"], lv["mid"]

        # Close at BB midline
        if pos_side == "BUY" and c >= mid:
            return True, "BB midline hit (BUY exit)"
        if pos_side == "SELL" and c <= mid:
            return True, "BB midline hit (SELL exit)"
        return False, ""

    # TRENDING position management
    if regime != "TRENDING":
        return True, "Regime changed (not TRENDING)"

    d = df.copy()
    d["EMA_fast"] = ema(d["Close"], EMA_FAST)
    d["EMA_slow"] = ema(d["Close"], EMA_SLOW)
    fast = float(d["EMA_fast"].iloc[-1])
    slow = float(d["EMA_slow"].iloc[-1])

    if pos_side == "BUY" and fast < slow:
        return True, "EMA flip against BUY"
    if pos_side == "SELL" and fast > slow:
        return True, "EMA flip against SELL"

    current_adx = float(adx(df, 14).iloc[-1])
    if np.isfinite(current_adx) and current_adx < ADX_EXIT:
        return True, f"ADX weak ({current_adx:.1f} < {ADX_EXIT})"

    return False, ""

# ============================================================
# MAIN
# ============================================================

def reset_regime_debounce_if_changed(new_regime: str):
    if new_regime != STATE.last_regime:
        STATE.last_regime = new_regime
        STATE.last_regime_signal_sent = False

def allow_signal_in_regime() -> bool:
    if not ENFORCE_ONE_SIGNAL_PER_REGIME_CHANGE:
        return True
    return not STATE.last_regime_signal_sent

def mark_signal_sent():
    if ENFORCE_ONE_SIGNAL_PER_REGIME_CHANGE:
        STATE.last_regime_signal_sent = True

def main():
    mt5_init()
    print(f"ALGOBOT started | SYMBOL={SYMBOL} | PAPER_MODE={PAPER_MODE}")

    events = []
    last_cal_fetch = datetime.min.replace(tzinfo=timezone.utc)

    try:
        while True:
            now_utc = datetime.now(timezone.utc)

            # --- Session filter
            if not in_session(now_utc):
                time.sleep(1)
                continue

            # --- Spread filter
            sp = spread_points(SYMBOL)
            if sp is None:
                time.sleep(1)
                continue
            if sp > MAX_SPREAD_POINTS:
                print(f"{now_utc.isoformat()} | SPREAD_FILTER: {sp} > {MAX_SPREAD_POINTS}")
                time.sleep(1)
                continue

            # --- News blackout (optional)
            if USE_NEWS_BLACKOUT and FINNHUB_API_KEY:
                if now_utc - last_cal_fetch > timedelta(minutes=30):
                    start = (now_utc - timedelta(days=1)).strftime("%Y-%m-%d")
                    end = (now_utc + timedelta(days=2)).strftime("%Y-%m-%d")
                    try:
                        events = fetch_calendar_finnhub(start, end)
                        last_cal_fetch = now_utc
                    except Exception as e:
                        print("[CAL] fetch error:", e)

                blocked, reason = in_blackout(now_utc, events)
                if blocked:
                    print(f"{now_utc.isoformat()} | NEWS_BLACKOUT: {reason}")
                    time.sleep(1)
                    continue

            # --- Pull bars
            df = get_bars(SYMBOL, BARS)
            if df.empty or len(df) < MIN_BARS_READY:
                print("Waiting for bars...")
                time.sleep(1)
                continue

            # --- Regime
            regime, m = classify_regime(df)
            reset_regime_debounce_if_changed(regime)

            # --- Signal logic
            trend_dir = ""
            signal = "NO_TRADE"

            if regime == "TRENDING":
                trend_dir, signal = trending_signal(df)
            elif regime == "SIDEWAYS":
                trend_dir = "RANGE"
                signal = sideways_signal(df)

            # --- Position status
            pos = get_positions(SYMBOL)
            have_pos = (pos is not None) and (len(pos) > 0)

            # --- Print status
            print(
                f"{now_utc.isoformat()} | regime={regime} {f'({trend_dir})' if trend_dir else ''} | "
                f"SIGNAL={signal} | ADX={m.get('ADX',np.nan):.1f} ER={m.get('ER',np.nan):.2f} WHIP={m.get('WHIP',np.nan):.2f} | "
                f"spread={sp} | pos={'YES' if have_pos else 'NO'}"
            )

            # --- Close management
            if have_pos:
                p = pos[0]
                close_now, reason = should_close_position(df, regime, p)
                if close_now:
                    print(f"CLOSE SIGNAL: {reason} | ticket={p.ticket}")
                    res = close_position(p, reason)
                    print("CLOSE:", res)
                    STATE.last_trade_time = now_utc
                    time.sleep(1)
                    continue

            # --- Open logic
            if ONE_POSITION_ONLY and have_pos:
                time.sleep(1)
                continue

            # must be in tradable regime
            if regime not in ("TRENDING", "SIDEWAYS") or signal not in ("BUY", "SELL"):
                time.sleep(1)
                continue

            # one-signal-per-regime-change debounce
            if not allow_signal_in_regime():
                time.sleep(1)
                continue

            # cooldown
            if (now_utc - STATE.last_trade_time).total_seconds() < COOLDOWN_SECONDS:
                time.sleep(1)
                continue

            tick = last_tick(SYMBOL)
            if tick is None:
                time.sleep(1)
                continue

            # Build SL/TP per regime
            entry_price = tick.ask if signal == "BUY" else tick.bid

            if regime == "TRENDING":
                a = float(atr(df, ATR_LEN).iloc[-1])
                if not np.isfinite(a) or a <= 0:
                    time.sleep(1)
                    continue

                if signal == "BUY":
                    sl = entry_price - TREND_SL_ATR * a
                    tp = entry_price + TREND_TP_ATR * a
                else:
                    sl = entry_price + TREND_SL_ATR * a
                    tp = entry_price - TREND_TP_ATR * a

                comment = TREND_COMMENT

            else:  # SIDEWAYS
                st = sideways_sl_tp(df, signal)
                if not st:
                    time.sleep(1)
                    continue
                sl, tp = st
                comment = SIDEWAYS_COMMENT

            # Risk-based lot size
            lot = calc_lot_for_risk(SYMBOL, entry_price, sl)
            lot = max(MIN_LOT, min(MAX_LOT, lot))

            # Place order
            res = send_market_order(SYMBOL, signal, lot, sl, tp, comment=comment)
            print("OPEN:", res)

            # update state
            STATE.last_trade_time = now_utc
            mark_signal_sent()

            time.sleep(1)

    except KeyboardInterrupt:
        print("Stopping bot...")
    finally:
        mt5_shutdown()

if __name__ == "__main__":
    main()
