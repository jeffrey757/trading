# -*- coding: utf-8 -*-
"""
Created on Fri Feb 13 06:16:44 2026

@author: Administrator
"""

import time
import numpy as np
import pandas as pd
import MetaTrader5 as mt5

SYMBOL = "GOLD"           # Your broker symbol
TIMEFRAME = mt5.TIMEFRAME_M1
LOOKBACK_MINUTES = 10
REFRESH_SECONDS = 1       # Change to 0.5 for faster

# -----------------------------
# Indicators
# -----------------------------
def rma(x, length):
    return x.ewm(alpha=1/length, adjust=False).mean()

def atr(df, length=14):
    h, l, c = df["High"], df["Low"], df["Close"]
    pc = c.shift(1)
    tr = pd.concat([(h - l), (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    return rma(tr, length)

def adx(df, length=14):
    h, l, c = df["High"], df["Low"], df["Close"]
    up = h.diff()
    dn = -l.diff()

    plus_dm = np.where((up > dn) & (up > 0), up, 0.0)
    minus_dm = np.where((dn > up) & (dn > 0), dn, 0.0)

    a = atr(df, length)
    plus_di = 100 * rma(pd.Series(plus_dm, index=df.index), length) / a
    minus_di = 100 * rma(pd.Series(minus_dm, index=df.index), length) / a

    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
    return rma(dx, length)

def efficiency_ratio(close, length=10):
    change = close.diff(length).abs()
    vol = close.diff().abs().rolling(length).sum()
    return change / vol

# -----------------------------
# Market Detection
# -----------------------------
def classify_market(df):
    df = df.copy()
    df["ADX"] = adx(df, 14)
    df["ER"] = efficiency_ratio(df["Close"], 10)

    last = df.iloc[-1]
    adx_v = last["ADX"]
    er_v = last["ER"]

    if pd.isna(adx_v) or pd.isna(er_v):
        return "WAITING_FOR_DATA"

    if adx_v >= 28 and er_v >= 0.35:
        return "TRENDING"
    if adx_v < 18:
        if er_v < 0.25:
            return "CHOPPY"
        return "SIDEWAYS"

    if er_v >= 0.4:
        return "TRENDING"
    return "SIDEWAYS"

# -----------------------------
# Fetch last 10 min
# -----------------------------
def fetch_data():
    bars_needed = 60  # enough for indicator warmup
    rates = mt5.copy_rates_from_pos(SYMBOL, TIMEFRAME, 0, bars_needed)

    if rates is None or len(rates) == 0:
        return None

    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time")

    df.rename(columns={
        "open": "Open",
        "high": "High",
        "low": "Low",
        "close": "Close"
    }, inplace=True)

    cutoff = df.index.max() - pd.Timedelta(minutes=LOOKBACK_MINUTES)
    return df[df.index >= cutoff]

# -----------------------------
# Main Loop
# -----------------------------
def run_live():
    if not mt5.initialize():
        print("MT5 init failed:", mt5.last_error())
        return

    if not mt5.symbol_select(SYMBOL, True):
        print("Symbol error:", mt5.last_error())
        return

    last_state = None

    print("Running live detection...\n")

    try:
        while True:
            df = fetch_data()
            if df is None or len(df) < 20:
                time.sleep(REFRESH_SECONDS)
                continue

            state = classify_market(df)

            if state != last_state:
                last_price = df["Close"].iloc[-1]
                print(f"{pd.Timestamp.utcnow()} | Price: {last_price:.2f} | Market: {state}")
                last_state = state

            time.sleep(REFRESH_SECONDS)

    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        mt5.shutdown()

if __name__ == "__main__":
    run_live()
