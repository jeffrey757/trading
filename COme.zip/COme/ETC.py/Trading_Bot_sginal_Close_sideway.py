# -*- coding: utf-8 -*-
"""
Created on Fri Feb 13 09:30:32 2026

@author: Administrator
"""

# -*- coding: utf-8 -*-
"""
MT5 Regime Trading Bot (M1) — FULL UPDATED VERSION
- Regime: TRENDING / SIDEWAYS / CHOPPY
- TRENDING signals: EMA(21/55) with ATR separation filter + ADX/ER/WHIP regime gate
- SIDEWAYS signals: Bollinger + RSI mean-reversion (optional re-entry confirmation)
- SIDEWAYS exits:
    * CLOSE at BB midline
    * SL at outer band ± ATR
    * TP at opposite band
- Only 1 open position at a time
- CLOSE SIGNAL applies per-trade type (TRENDING vs SIDEWAYS) using position.comment tag

Requirements:
  pip install MetaTrader5 pandas numpy requests
"""

import os
import time
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
import requests
import MetaTrader5 as mt5

# ============================================================
# CONFIG
# ============================================================
SYMBOL = "GOLD"
TIMEFRAME = mt5.TIMEFRAME_M1
BARS = 500

PAPER_MODE = True          # set False to actually trade
MAGIC = 20260213

LOT = 0.01
DEVIATION = 20
COOLDOWN_SECONDS = 60

ATR_LEN = 14
EMA_FAST = 21
EMA_SLOW = 55

# TRENDING SL/TP via ATR
SL_ATR = 1.5
TP_ATR = 2.0

# Regime thresholds (tune per symbol)
ADX_TREND = 28             # classify TRENDING if ADX >= this (plus ER condition)
ADX_WEAK = 18              # classify weak regime if ADX < this
ADX_EXIT = 20              # CLOSE SIGNAL for TRENDING trade if ADX < this

ER_TREND = 0.35
ER_WEAK = 0.25
WHIP_CHOP = 0.30

# EMA separation filter (avoid weak TRENDING signals)
MIN_SEP_ATR = 0.10         # if |EMA_fast-EMA_slow|/ATR < this => NO_TRADE

# ----------------------------
# SIDEWAYS mean-reversion
# ----------------------------
SIDEWAYS_BB_LEN = 20
SIDEWAYS_BB_STD = 2.0
SIDEWAYS_RSI_LEN = 14
SIDEWAYS_RSI_BUY = 30
SIDEWAYS_RSI_SELL = 70
SIDEWAYS_REQUIRE_REENTRY = True

# Tag used to detect SIDEWAYS trades later (for close logic)
SIDEWAYS_COMMENT = "RegimeBot_SW"

# Econ calendar (optional)
USE_NEWS_BLACKOUT = False
ONLY_IMPACTS = ("high",)
FINNHUB_API_KEY = os.getenv("FINNHUB_API_KEY", "")

MAJOR_15_KEYS = [
    "cpi", "consumer price",
    "non-farm", "nfp",
    "fomc", "fed rate", "interest rate decision",
    "powell", "press conference"
]

# ============================================================
# MT5 HELPERS
# ============================================================
def mt5_init():
    if not mt5.initialize():
        raise SystemExit(f"MT5 initialize failed: {mt5.last_error()}")
    if not mt5.symbol_select(SYMBOL, True):
        raise SystemExit(f"symbol_select({SYMBOL}) failed: {mt5.last_error()}")

def mt5_shutdown():
    mt5.shutdown()

def get_m1_bars(symbol: str, count: int) -> pd.DataFrame:
    rates = mt5.copy_rates_from_pos(symbol, TIMEFRAME, 0, count)
    if rates is None or len(rates) == 0:
        return pd.DataFrame()

    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time")
    df.rename(
        columns={"open": "Open", "high": "High", "low": "Low", "close": "Close", "tick_volume": "Volume"},
        inplace=True
    )
    return df[["Open", "High", "Low", "Close", "Volume"]]

def last_tick(symbol: str):
    return mt5.symbol_info_tick(symbol)

def positions(symbol: str):
    return mt5.positions_get(symbol=symbol)

# ============================================================
# INDICATORS
# ============================================================
def rma(x: pd.Series, length: int) -> pd.Series:
    return x.ewm(alpha=1 / length, adjust=False).mean()

def atr(df: pd.DataFrame, length: int = 14) -> pd.Series:
    h, l, c = df["High"], df["Low"], df["Close"]
    pc = c.shift(1)
    tr = pd.concat([(h - l), (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    return rma(tr, length)

def ema(x: pd.Series, length: int) -> pd.Series:
    return x.ewm(span=length, adjust=False).mean()

def adx(df: pd.DataFrame, length: int = 14) -> pd.Series:
    h, l = df["High"], df["Low"]
    up = h.diff()
    dn = -l.diff()

    plus_dm = np.where((up > dn) & (up > 0), up, 0.0)
    minus_dm = np.where((dn > up) & (dn > 0), dn, 0.0)

    a = atr(df, length)
    plus_di = 100 * rma(pd.Series(plus_dm, index=df.index), length) / a
    minus_di = 100 * rma(pd.Series(minus_dm, index=df.index), length) / a

    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
    return rma(dx, length)

def efficiency_ratio(close: pd.Series, length: int = 10) -> pd.Series:
    change = close.diff(length).abs()
    vol = close.diff().abs().rolling(length).sum()
    return change / vol

def whipsaw_rate(bool_signal: pd.Series, length: int = 10) -> pd.Series:
    flips = bool_signal.astype(int).diff().abs()
    return flips.rolling(length).sum() / length

def rsi(close: pd.Series, length: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = (-delta).clip(lower=0)
    avg_gain = rma(gain, length)
    avg_loss = rma(loss, length)
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def bollinger(close: pd.Series, length: int = 20, stdev: float = 2.0):
    mid = close.rolling(length).mean()
    sd = close.rolling(length).std(ddof=0)
    upper = mid + stdev * sd
    lower = mid - stdev * sd
    return mid, upper, lower

# ============================================================
# REGIME CLASSIFIER
# ============================================================
def classify_regime(df: pd.DataFrame) -> tuple[str, dict]:
    d = df.copy()
    d["ATR"] = atr(d, ATR_LEN)
    d["ADX"] = adx(d, 14)
    d["ER"] = efficiency_ratio(d["Close"], 10)
    d["WHIP"] = whipsaw_rate(d["Close"] > d["Close"].rolling(3).mean(), 10)

    last = d.iloc[-1]
    adx_v = float(last["ADX"]) if pd.notna(last["ADX"]) else np.nan
    er_v  = float(last["ER"]) if pd.notna(last["ER"]) else np.nan
    whip  = float(last["WHIP"]) if pd.notna(last["WHIP"]) else np.nan

    if not np.isfinite(adx_v) or not np.isfinite(er_v) or not np.isfinite(whip):
        return "UNKNOWN", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

    # Strong trend
    if adx_v >= ADX_TREND and er_v >= ER_TREND:
        return "TRENDING", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

    # Weak trend zone
    if adx_v < ADX_WEAK:
        if er_v < ER_WEAK or whip > WHIP_CHOP:
            return "CHOPPY", {"ADX": adx_v, "ER": er_v, "WHIP": whip}
        return "SIDEWAYS", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

    # Mid zone
    if er_v >= 0.40 and whip <= 0.25:
        return "TRENDING", {"ADX": adx_v, "ER": er_v, "WHIP": whip}
    if whip > WHIP_CHOP:
        return "CHOPPY", {"ADX": adx_v, "ER": er_v, "WHIP": whip}
    return "SIDEWAYS", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

# ============================================================
# TRENDING: DIRECTION + SIGNAL
# ============================================================
def trend_direction_and_signal(df2: pd.DataFrame) -> tuple[str, str]:
    fast = float(df2["EMA_fast"].iloc[-1])
    slow = float(df2["EMA_slow"].iloc[-1])

    a = float(atr(df2, ATR_LEN).iloc[-1])
    if not np.isfinite(a) or a <= 0:
        return "FLAT", "NO_TRADE"

    sep = abs(fast - slow) / a
    if sep < MIN_SEP_ATR:
        return "FLAT", "NO_TRADE"

    return ("UPTREND", "BUY") if fast > slow else ("DOWNTREND", "SELL")

# ============================================================
# SIDEWAYS: SIGNAL + SL/TP LEVELS
# ============================================================
def sideways_levels(df: pd.DataFrame) -> dict | None:
    d = df.copy()
    d["ATR"] = atr(d, ATR_LEN)
    d["RSI"] = rsi(d["Close"], SIDEWAYS_RSI_LEN)
    mid, upper, lower = bollinger(d["Close"], SIDEWAYS_BB_LEN, SIDEWAYS_BB_STD)
    d["BB_MID"], d["BB_UPPER"], d["BB_LOWER"] = mid, upper, lower

    need = max(SIDEWAYS_BB_LEN, SIDEWAYS_RSI_LEN) + 5
    if len(d) < need:
        return None

    last = d.iloc[-1]
    prev = d.iloc[-2]

    # validate
    keys_last = ["ATR", "RSI", "BB_MID", "BB_UPPER", "BB_LOWER", "Close"]
    for k in keys_last:
        if not np.isfinite(float(last[k])):
            return None

    return {
        "close": float(last["Close"]),
        "prev_close": float(prev["Close"]),
        "atr": float(last["ATR"]),
        "rsi": float(last["RSI"]),
        "mid": float(last["BB_MID"]),
        "upper": float(last["BB_UPPER"]),
        "lower": float(last["BB_LOWER"]),
        "prev_upper": float(prev["BB_UPPER"]) if np.isfinite(float(prev["BB_UPPER"])) else np.nan,
        "prev_lower": float(prev["BB_LOWER"]) if np.isfinite(float(prev["BB_LOWER"])) else np.nan,
    }

def sideways_signal(df: pd.DataFrame) -> str:
    lv = sideways_levels(df)
    if not lv:
        return "NO_TRADE"

    c, r, up, lo = lv["close"], lv["rsi"], lv["upper"], lv["lower"]
    pc = lv["prev_close"]
    prev_lo, prev_up = lv["prev_lower"], lv["prev_upper"]

    buy_stretch  = (c < lo) and (r <= SIDEWAYS_RSI_BUY)
    sell_stretch = (c > up) and (r >= SIDEWAYS_RSI_SELL)

    if not SIDEWAYS_REQUIRE_REENTRY:
        if buy_stretch:
            return "BUY"
        if sell_stretch:
            return "SELL"
        return "NO_TRADE"

    # Re-entry confirmation: previous outside, current back inside
    buy_confirm  = np.isfinite(prev_lo) and (pc < prev_lo) and (c >= lo)
    sell_confirm = np.isfinite(prev_up) and (pc > prev_up) and (c <= up)

    if buy_stretch and buy_confirm:
        return "BUY"
    if sell_stretch and sell_confirm:
        return "SELL"
    return "NO_TRADE"

def sideways_sl_tp(df: pd.DataFrame, side: str) -> tuple[float, float] | None:
    """
    User rules:
    - SL at outer band ± ATR
      BUY: SL = lower - ATR
      SELL: SL = upper + ATR
    - TP at opposite band
      BUY: TP = upper
      SELL: TP = lower
    """
    lv = sideways_levels(df)
    if not lv:
        return None

    atr_v, up, lo = lv["atr"], lv["upper"], lv["lower"]
    if not np.isfinite(atr_v) or atr_v <= 0:
        return None

    if side == "BUY":
        sl = lo - atr_v
        tp = up
    else:
        sl = up + atr_v
        tp = lo

    return float(sl), float(tp)

# ============================================================
# CLOSE SIGNAL (SPECIFIC TRADE EXIT LOGIC)
# ============================================================
def should_close_position(df: pd.DataFrame, regime: str, position) -> tuple[bool, str]:
    """
    SIDEWAYS trades:
      - Close if regime != SIDEWAYS
      - Close at BB midline
    TRENDING trades:
      - Close if regime != TRENDING
      - Close if EMA direction flips against position
      - Close if ADX drops below ADX_EXIT
    """
    pos_side = "BUY" if position.type == mt5.POSITION_TYPE_BUY else "SELL"
    pos_comment = getattr(position, "comment", "") or ""
    is_sideways_trade = (SIDEWAYS_COMMENT in pos_comment)

    # ----- SIDEWAYS exits -----
    if is_sideways_trade:
        if regime != "SIDEWAYS":
            return True, "Regime changed (not SIDEWAYS)"

        lv = sideways_levels(df)
        if not lv:
            return False, ""

        c, mid = lv["close"], lv["mid"]

        # Close at BB midline
        if pos_side == "BUY" and c >= mid:
            return True, "BB midline hit (BUY exit)"
        if pos_side == "SELL" and c <= mid:
            return True, "BB midline hit (SELL exit)"

        return False, ""

    # ----- TRENDING exits -----
    if regime != "TRENDING":
        return True, "Regime changed (not TRENDING)"

    d = df.copy()
    d["EMA_fast"] = ema(d["Close"], EMA_FAST)
    d["EMA_slow"] = ema(d["Close"], EMA_SLOW)

    fast = float(d["EMA_fast"].iloc[-1])
    slow = float(d["EMA_slow"].iloc[-1])

    # EMA flip exit
    if pos_side == "BUY" and fast < slow:
        return True, "EMA flip against BUY"
    if pos_side == "SELL" and fast > slow:
        return True, "EMA flip against SELL"

    # ADX weakening exit
    current_adx = float(adx(df, 14).iloc[-1])
    if np.isfinite(current_adx) and current_adx < ADX_EXIT:
        return True, f"ADX weak ({current_adx:.1f} < {ADX_EXIT})"

    return False, ""

# ============================================================
# NEWS BLACKOUT (optional, Finnhub)
# ============================================================
def normalize_impact(x: str) -> str:
    x = (x or "").lower()
    if "high" in x: return "high"
    if "medium" in x: return "medium"
    if "low" in x: return "low"
    return "unknown"

def is_us_event(country: str) -> bool:
    c = (country or "").strip().upper()
    return c in {"US", "UNITED STATES", "USA"}

def blackout_minutes(event_name: str) -> int:
    name = (event_name or "").lower()
    return 15 if any(k in name for k in MAJOR_15_KEYS) else 10

def fetch_calendar_finnhub(start_utc_date: str, end_utc_date: str) -> list[dict]:
    if not FINNHUB_API_KEY:
        return []

    url = "https://finnhub.io/api/v1/calendar/economic"
    r = requests.get(url, params={"from": start_utc_date, "to": end_utc_date, "token": FINNHUB_API_KEY}, timeout=30)
    r.raise_for_status()
    data = r.json()
    items = data.get("economicCalendar", []) or []

    events = []
    for e in items:
        t_raw = e.get("time") or e.get("date") or e.get("datetime")
        if not t_raw:
            continue
        t = pd.to_datetime(t_raw, utc=True)
        events.append({
            "time": t,
            "type": (e.get("event") or e.get("name") or "").strip(),
            "impact": normalize_impact(e.get("impact") or e.get("importance") or ""),
            "country": (e.get("country") or "").strip(),
        })
    return events

def in_blackout(now_utc: datetime, events: list[dict]) -> tuple[bool, str]:
    for ev in events:
        if not is_us_event(ev.get("country", "")):
            continue
        if ev.get("impact", "unknown") not in ONLY_IMPACTS:
            continue

        t = pd.to_datetime(ev["time"], utc=True).to_pydatetime()
        mins = blackout_minutes(ev.get("type", ""))
        if t <= now_utc < (t + timedelta(minutes=mins)):
            return True, f"{ev.get('type','NEWS')} ({mins}m blackout)"
    return False, ""

# ============================================================
# TRADING
# ============================================================
def send_market_order(symbol: str, side: str, lot: float, sl: float, tp: float, comment: str):
    tick = last_tick(symbol)
    if tick is None:
        print("No tick:", mt5.last_error())
        return None

    price = tick.ask if side == "BUY" else tick.bid
    order_type = mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": float(lot),
        "type": order_type,
        "price": float(price),
        "sl": float(sl),
        "tp": float(tp),
        "deviation": int(DEVIATION),
        "magic": int(MAGIC),
        "comment": str(comment)[:31],
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    if PAPER_MODE:
        print("[PAPER] OPEN order:", request)
        return {"retcode": "PAPER"}

    return mt5.order_send(request)

def close_position(position, reason: str = ""):
    """
    Close a specific open trade (position.ticket).
    """
    symbol = position.symbol
    volume = position.volume
    side = "SELL" if position.type == mt5.POSITION_TYPE_BUY else "BUY"

    tick = last_tick(symbol)
    if tick is None:
        print("No tick:", mt5.last_error())
        return None

    price = tick.bid if side == "SELL" else tick.ask
    order_type = mt5.ORDER_TYPE_SELL if side == "SELL" else mt5.ORDER_TYPE_BUY

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "position": int(position.ticket),
        "volume": float(volume),
        "type": order_type,
        "price": float(price),
        "deviation": int(DEVIATION),
        "magic": int(MAGIC),
        "comment": f"RegimeBot close: {reason}"[:31],
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    if PAPER_MODE:
        print("[PAPER] CLOSE order:", request)
        return {"retcode": "PAPER"}

    return mt5.order_send(request)

# ============================================================
# MAIN LOOP
# ============================================================
def main():
    mt5_init()
    print(f"Bot started | SYMBOL={SYMBOL} | PAPER_MODE={PAPER_MODE}")

    last_trade_time = datetime.min.replace(tzinfo=timezone.utc)

    # Calendar cache
    events = []
    last_cal_fetch = datetime.min.replace(tzinfo=timezone.utc)

    try:
        while True:
            now_utc = datetime.now(timezone.utc)

            # (A) News blackout
            if USE_NEWS_BLACKOUT and FINNHUB_API_KEY:
                if now_utc - last_cal_fetch > timedelta(minutes=30):
                    start = (now_utc - timedelta(days=1)).strftime("%Y-%m-%d")
                    end = (now_utc + timedelta(days=2)).strftime("%Y-%m-%d")
                    try:
                        events = fetch_calendar_finnhub(start, end)
                        last_cal_fetch = now_utc
                    except Exception as e:
                        print("[CAL] fetch error:", e)

                blocked, reason = in_blackout(now_utc, events)
                if blocked:
                    print(f"{now_utc.isoformat()} | NEWS_BLACKOUT: {reason}")
                    time.sleep(1)
                    continue

            # (B) Pull bars
            df = get_m1_bars(SYMBOL, BARS)
            if df.empty or len(df) < 120:
                print("Waiting for bars...")
                time.sleep(1)
                continue

            # (C) Regime
            regime, metrics = classify_regime(df)

            # (D) Build EMA frame for TRENDING logic
            df2 = df.copy()
            df2["EMA_fast"] = ema(df2["Close"], EMA_FAST)
            df2["EMA_slow"] = ema(df2["Close"], EMA_SLOW)

            # (E) Signals
            trend_dir, signal = ("", "NO_TRADE")

            if regime == "TRENDING":
                trend_dir, signal = trend_direction_and_signal(df2)
            elif regime == "SIDEWAYS":
                trend_dir = "RANGE"
                signal = sideways_signal(df)

            # (F) Position status
            pos = positions(SYMBOL)
            have_pos = (pos is not None) and (len(pos) > 0)

            # Print status
            if regime == "TRENDING":
                print(
                    f"{now_utc.isoformat()} | regime=TRENDING ({trend_dir}) | SIGNAL={signal} | "
                    f"ADX={metrics.get('ADX'):.1f} ER={metrics.get('ER'):.2f} WHIP={metrics.get('WHIP'):.2f} | "
                    f"pos={'YES' if have_pos else 'NO'}"
                )
            elif regime == "SIDEWAYS":
                print(
                    f"{now_utc.isoformat()} | regime=SIDEWAYS (RANGE) | SIGNAL={signal} | "
                    f"ADX={metrics.get('ADX'):.1f} ER={metrics.get('ER'):.2f} WHIP={metrics.get('WHIP'):.2f} | "
                    f"pos={'YES' if have_pos else 'NO'}"
                )
            else:
                print(
                    f"{now_utc.isoformat()} | regime={regime} | SIGNAL=NO_TRADE | "
                    f"ADX={metrics.get('ADX'):.1f} ER={metrics.get('ER'):.2f} WHIP={metrics.get('WHIP'):.2f} | "
                    f"pos={'YES' if have_pos else 'NO'}"
                )

            # ------------------------------------------------------------
            # (G) CLOSE SIGNAL for the specific open trade
            # ------------------------------------------------------------
            if have_pos:
                p = pos[0]
                close_now, reason = should_close_position(df, regime, p)
                if close_now:
                    print(f"CLOSE SIGNAL: {reason} | ticket={p.ticket}")
                    res = close_position(p, reason=reason)
                    print("CLOSE:", res)
                    last_trade_time = now_utc
                    time.sleep(1)
                    continue

            # ------------------------------------------------------------
            # (H) OPEN LOGIC (TRENDING or SIDEWAYS)
            # ------------------------------------------------------------
            if regime not in ("TRENDING", "SIDEWAYS") or signal not in ("BUY", "SELL"):
                time.sleep(1)
                continue

            # Cooldown
            if (now_utc - last_trade_time).total_seconds() < COOLDOWN_SECONDS:
                time.sleep(1)
                continue

            # Only open if no position
            if not have_pos:
                tick = last_tick(SYMBOL)
                if tick is None:
                    time.sleep(1)
                    continue

                if regime == "TRENDING":
                    a = float(atr(df2, ATR_LEN).iloc[-1])
                    if not np.isfinite(a) or a <= 0:
                        time.sleep(1)
                        continue

                    price_mid = (tick.bid + tick.ask) / 2.0
                    if signal == "BUY":
                        sl = price_mid - SL_ATR * a
                        tp = price_mid + TP_ATR * a
                    else:
                        sl = price_mid + SL_ATR * a
                        tp = price_mid - TP_ATR * a

                    comment = "RegimeBot"

                else:  # SIDEWAYS
                    st = sideways_sl_tp(df, signal)
                    if not st:
                        time.sleep(1)
                        continue
                    sl, tp = st
                    comment = SIDEWAYS_COMMENT

                res = send_market_order(SYMBOL, signal, LOT, sl, tp, comment=comment)
                print("OPEN:", res)
                last_trade_time = now_utc

            time.sleep(1)

    except KeyboardInterrupt:
        print("Stopping bot...")
    finally:
        mt5_shutdown()

if __name__ == "__main__":
    main()
