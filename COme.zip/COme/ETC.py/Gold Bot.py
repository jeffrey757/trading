# -*- coding: utf-8 -*-
"""
Created on Fri Feb 13 06:23:05 2026

@author: Administrator
"""

import os
import time
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
import requests
import MetaTrader5 as mt5

# ============================================================
# CONFIG
# ============================================================
SYMBOL = "GBPUSD"                 # your broker symbol
TIMEFRAME = mt5.TIMEFRAME_M1
BARS = 500                      # warmup bars for indicators
LOOKBACK_MINUTES = 10           # regime decision window

PAPER_MODE = True               # <-- set False to actually trade
MAGIC = 20260213                # any int identifier for your bot

LOT = 0.01                      # adjust per account
DEVIATION = 20                  # slippage points
COOLDOWN_SECONDS = 60           # minimum seconds between new trades

ATR_LEN = 14
EMA_FAST = 21
EMA_SLOW = 55

# SL/TP in ATR multiples (tune)
SL_ATR = 1.5
TP_ATR = 2.0

# Econ calendar (optional)
USE_NEWS_BLACKOUT = False       # set True if you add API key & want blackout
ONLY_IMPACTS = ("high",)        # ("high","medium") if you want

# Finnhub econ calendar API key (optional)
FINNHUB_API_KEY = os.getenv("FINNHUB_API_KEY", "")

MAJOR_15_KEYS = [
    "cpi", "consumer price",
    "non-farm", "nfp",
    "fomc", "fed rate", "interest rate decision",
    "powell", "press conference"
]

# ============================================================
# MT5 HELPERS
# ============================================================
def mt5_init():
    if not mt5.initialize():
        raise SystemExit(f"MT5 initialize failed: {mt5.last_error()}")
    if not mt5.symbol_select(SYMBOL, True):
        raise SystemExit(f"symbol_select({SYMBOL}) failed: {mt5.last_error()}")

def mt5_shutdown():
    mt5.shutdown()

def get_m1_bars(symbol: str, count: int) -> pd.DataFrame:
    rates = mt5.copy_rates_from_pos(symbol, TIMEFRAME, 0, count)
    if rates is None or len(rates) == 0:
        return pd.DataFrame()

    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time")
    df.rename(columns={"open":"Open","high":"High","low":"Low","close":"Close","tick_volume":"Volume"}, inplace=True)
    return df[["Open","High","Low","Close","Volume"]]

def last_tick(symbol: str):
    return mt5.symbol_info_tick(symbol)  # :contentReference[oaicite:1]{index=1}

def positions(symbol: str):
    return mt5.positions_get(symbol=symbol)  # :contentReference[oaicite:2]{index=2}

# ============================================================
# INDICATORS
# ============================================================
def rma(x: pd.Series, length: int) -> pd.Series:
    return x.ewm(alpha=1/length, adjust=False).mean()

def atr(df: pd.DataFrame, length: int = 14) -> pd.Series:
    h, l, c = df["High"], df["Low"], df["Close"]
    pc = c.shift(1)
    tr = pd.concat([(h - l), (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    return rma(tr, length)

def ema(x: pd.Series, length: int) -> pd.Series:
    return x.ewm(span=length, adjust=False).mean()

def adx(df: pd.DataFrame, length: int = 14) -> pd.Series:
    h, l = df["High"], df["Low"]
    up = h.diff()
    dn = -l.diff()

    plus_dm = np.where((up > dn) & (up > 0), up, 0.0)
    minus_dm = np.where((dn > up) & (dn > 0), dn, 0.0)

    a = atr(df, length)
    plus_di = 100 * rma(pd.Series(plus_dm, index=df.index), length) / a
    minus_di = 100 * rma(pd.Series(minus_dm, index=df.index), length) / a

    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
    return rma(dx, length)

def efficiency_ratio(close: pd.Series, length: int = 10) -> pd.Series:
    change = close.diff(length).abs()
    vol = close.diff().abs().rolling(length).sum()
    return change / vol

def whipsaw_rate(bool_signal: pd.Series, length: int = 10) -> pd.Series:
    flips = bool_signal.astype(int).diff().abs()
    return flips.rolling(length).sum() / length

# ============================================================
# REGIME CLASSIFIER (Trending / Sideways / Choppy)
# ============================================================
def classify_regime(df: pd.DataFrame) -> tuple[str, dict]:
    """
    Returns: (regime, debug_metrics)
    Uses last bar of computed indicators; tuned for 1m noise.
    """
    d = df.copy()
    d["ATR"] = atr(d, ATR_LEN)
    d["ADX"] = adx(d, 14)
    d["ER"] = efficiency_ratio(d["Close"], 10)
    d["WHIP"] = whipsaw_rate(d["Close"] > d["Close"].rolling(3).mean(), 10)

    last = d.iloc[-1]
    adx_v = float(last["ADX"]) if pd.notna(last["ADX"]) else np.nan
    er_v = float(last["ER"]) if pd.notna(last["ER"]) else np.nan
    whip = float(last["WHIP"]) if pd.notna(last["WHIP"]) else np.nan

    if np.isnan(adx_v) or np.isnan(er_v) or np.isnan(whip):
        return "UNKNOWN", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

    # Simple rules (works well for a bot scaffold; tune later)
    if adx_v >= 28 and er_v >= 0.35:
        return "TRENDING", {"ADX": adx_v, "ER": er_v, "WHIP": whip}
    if adx_v < 18:
        if er_v < 0.25 or whip > 0.30:
            return "CHOPPY", {"ADX": adx_v, "ER": er_v, "WHIP": whip}
        return "SIDEWAYS", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

    # mid zone
    if er_v >= 0.40 and whip <= 0.25:
        return "TRENDING", {"ADX": adx_v, "ER": er_v, "WHIP": whip}
    if whip > 0.30:
        return "CHOPPY", {"ADX": adx_v, "ER": er_v, "WHIP": whip}
    return "SIDEWAYS", {"ADX": adx_v, "ER": er_v, "WHIP": whip}

# ============================================================
# NEWS BLACKOUT (optional, Finnhub)
# ============================================================
def normalize_impact(x: str) -> str:
    x = (x or "").lower()
    if "high" in x: return "high"
    if "medium" in x: return "medium"
    if "low" in x: return "low"
    return "unknown"

def is_us_event(country: str) -> bool:
    c = (country or "").strip().upper()
    return c in {"US", "UNITED STATES", "USA"}

def blackout_minutes(event_name: str) -> int:
    name = (event_name or "").lower()
    return 15 if any(k in name for k in MAJOR_15_KEYS) else 10

def fetch_calendar_finnhub(start_utc_date: str, end_utc_date: str) -> list[dict]:
    if not FINNHUB_API_KEY:
        return []

    url = "https://finnhub.io/api/v1/calendar/economic"
    r = requests.get(url, params={"from": start_utc_date, "to": end_utc_date, "token": FINNHUB_API_KEY}, timeout=30)
    r.raise_for_status()
    data = r.json()
    items = data.get("economicCalendar", []) or []

    events = []
    for e in items:
        t_raw = e.get("time") or e.get("date") or e.get("datetime")
        if not t_raw:
            continue
        t = pd.to_datetime(t_raw, utc=True)
        events.append({
            "time": t,
            "type": (e.get("event") or e.get("name") or "").strip(),
            "impact": normalize_impact(e.get("impact") or e.get("importance") or ""),
            "country": (e.get("country") or "").strip(),
        })
    return events

def in_blackout(now_utc: datetime, events: list[dict]) -> tuple[bool, str]:
    """
    Returns (blocked, reason)
    """
    for ev in events:
        if not is_us_event(ev.get("country", "")):
            continue
        if ev.get("impact", "unknown") not in ONLY_IMPACTS:
            continue

        t = pd.to_datetime(ev["time"], utc=True).to_pydatetime()
        mins = blackout_minutes(ev.get("type", ""))
        if t <= now_utc < (t + timedelta(minutes=mins)):
            return True, f"{ev.get('type','NEWS')} ({mins}m blackout)"
    return False, ""

# ============================================================
# TRADING (order_send)
# ============================================================
def send_market_order(symbol: str, side: str, lot: float, sl: float, tp: float, comment: str):
    tick = last_tick(symbol)
    if tick is None:
        print("No tick:", mt5.last_error())
        return None

    price = tick.ask if side == "BUY" else tick.bid
    order_type = mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": float(lot),
        "type": order_type,
        "price": float(price),
        "sl": float(sl),
        "tp": float(tp),
        "deviation": int(DEVIATION),
        "magic": int(MAGIC),
        "comment": comment,
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    if PAPER_MODE:
        print("[PAPER] order_send:", request)
        return {"retcode": "PAPER"}

    result = mt5.order_send(request)  # :contentReference[oaicite:3]{index=3}
    return result

def close_position(position):
    """
    Closes a position by sending an opposite DEAL.
    """
    symbol = position.symbol
    volume = position.volume
    side = "SELL" if position.type == mt5.POSITION_TYPE_BUY else "BUY"

    tick = last_tick(symbol)
    if tick is None:
        print("No tick:", mt5.last_error())
        return None

    price = tick.bid if side == "SELL" else tick.ask
    order_type = mt5.ORDER_TYPE_SELL if side == "SELL" else mt5.ORDER_TYPE_BUY

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "position": position.ticket,
        "volume": float(volume),
        "type": order_type,
        "price": float(price),
        "deviation": int(DEVIATION),
        "magic": int(MAGIC),
        "comment": "Bot close",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    if PAPER_MODE:
        print("[PAPER] close:", request)
        return {"retcode": "PAPER"}

    return mt5.order_send(request)  # :contentReference[oaicite:4]{index=4}

# ============================================================
# MAIN BOT LOOP
# ============================================================
def main():
    mt5_init()
    print(f"Bot started | SYMBOL={SYMBOL} | PAPER_MODE={PAPER_MODE}")

    last_trade_time = datetime.min.replace(tzinfo=timezone.utc)

    # Calendar cache
    events = []
    last_cal_fetch = datetime.min.replace(tzinfo=timezone.utc)

    try:
        while True:
            now_utc = datetime.now(timezone.utc)

            # Refresh econ calendar occasionally
            if USE_NEWS_BLACKOUT and FINNHUB_API_KEY:
                if now_utc - last_cal_fetch > timedelta(minutes=30):
                    start = (now_utc - timedelta(days=1)).strftime("%Y-%m-%d")
                    end = (now_utc + timedelta(days=2)).strftime("%Y-%m-%d")
                    try:
                        events = fetch_calendar_finnhub(start, end)
                        last_cal_fetch = now_utc
                    except Exception as e:
                        print("[CAL] fetch error:", e)

                blocked, reason = in_blackout(now_utc, events)
                if blocked:
                    print(f"{now_utc.isoformat()} | NEWS_BLACKOUT: {reason}")
                    time.sleep(1)
                    continue

            # Pull data
            df = get_m1_bars(SYMBOL, BARS)
            if df.empty or len(df) < 100:
                print("Waiting for bars...")
                time.sleep(1)
                continue

            # Use last 10 minutes for reporting (regime uses full df for warmup)
            cutoff = df.index.max() - pd.Timedelta(minutes=LOOKBACK_MINUTES)
            last10 = df[df.index >= cutoff]
            if last10.empty:
                time.sleep(1)
                continue

            regime, metrics = classify_regime(df)

            # Strategy signal (simple example): EMA trend direction
            df2 = df.copy()
            df2["EMA_fast"] = ema(df2["Close"], EMA_FAST)
            df2["EMA_slow"] = ema(df2["Close"], EMA_SLOW)

            fast = df2["EMA_fast"].iloc[-1]
            slow = df2["EMA_slow"].iloc[-1]
            direction = "BUY" if fast > slow else "SELL"

            # Risk/SL/TP from ATR
            a = float(atr(df2, ATR_LEN).iloc[-1])
            tick = last_tick(SYMBOL)
            if tick is None or a <= 0:
                time.sleep(1)
                continue

            price_mid = (tick.bid + tick.ask) / 2.0
            if direction == "BUY":
                sl = price_mid - SL_ATR * a
                tp = price_mid + TP_ATR * a
            else:
                sl = price_mid + SL_ATR * a
                tp = price_mid - TP_ATR * a

            # Position management
            pos = positions(SYMBOL)
            have_pos = (pos is not None) and (len(pos) > 0)

            print(
                f"{now_utc.isoformat()} | regime={regime} dir={direction} "
                f"ADX={metrics.get('ADX'):.1f} ER={metrics.get('ER'):.2f} WHIP={metrics.get('WHIP'):.2f}"
            )

            # Only trade if TRENDING
            if regime != "TRENDING":
                time.sleep(1)
                continue

            # Cooldown
            if (now_utc - last_trade_time).total_seconds() < COOLDOWN_SECONDS:
                time.sleep(1)
                continue

            # If no open position: open one in trend direction
            if not have_pos:
                res = send_market_order(SYMBOL, direction, LOT, sl, tp, comment="RegimeBot")
                print("OPEN:", res)
                last_trade_time = now_utc
                time.sleep(1)
                continue

            # If have position but opposite direction: close it (simple reversal logic)
            p = pos[0]
            pos_side = "BUY" if p.type == mt5.POSITION_TYPE_BUY else "SELL"
            if pos_side != direction:
                res = close_position(p)
                print("CLOSE:", res)
                last_trade_time = now_utc

            time.sleep(1)

    except KeyboardInterrupt:
        print("Stopping bot...")
    finally:
        mt5_shutdown()

if __name__ == "__main__":
    main()
