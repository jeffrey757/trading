import numpy as np
import pandas as pd

# -----------------------------
# Helpers / indicators
# -----------------------------
def rma(x: pd.Series, length: int) -> pd.Series:
    """Wilder's moving average (RMA)."""
    return x.ewm(alpha=1/length, adjust=False).mean()

def ema(x: pd.Series, length: int) -> pd.Series:
    return x.ewm(span=length, adjust=False).mean()

def atr(df: pd.DataFrame, length: int = 14) -> pd.Series:
    h, l, c = df["High"], df["Low"], df["Close"]
    pc = c.shift(1)
    tr = pd.concat([(h - l), (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    return rma(tr, length)

def adx(df: pd.DataFrame, length: int = 14) -> pd.DataFrame:
    """Wilder ADX. Returns +DI, -DI, ADX."""
    h, l, c = df["High"], df["Low"], df["Close"]
    up = h.diff()
    dn = -l.diff()

    plus_dm = np.where((up > dn) & (up > 0), up, 0.0)
    minus_dm = np.where((dn > up) & (dn > 0), dn, 0.0)

    a = atr(df, length)
    plus_di = 100 * rma(pd.Series(plus_dm, index=df.index), length) / a
    minus_di = 100 * rma(pd.Series(minus_dm, index=df.index), length) / a

    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
    adx_val = rma(dx, length)

    return pd.DataFrame({"+DI": plus_di, "-DI": minus_di, "ADX": adx_val})

def linreg_slope(x: pd.Series, length: int) -> pd.Series:
    """Rolling linear regression slope."""
    idx = np.arange(length)

    def _slope(window: np.ndarray) -> float:
        y = window
        x_ = idx
        xm, ym = x_.mean(), y.mean()
        num = ((x_ - xm) * (y - ym)).sum()
        den = ((x_ - xm) ** 2).sum()
        return num / den if den != 0 else 0.0

    return x.rolling(length).apply(lambda w: _slope(w.values), raw=False)

def efficiency_ratio(close: pd.Series, length: int = 20) -> pd.Series:
    """Kaufman Efficiency Ratio: 0 choppy .. 1 trendy."""
    change = close.diff(length).abs()
    vol = close.diff().abs().rolling(length).sum()
    return change / vol

def whipsaw_rate(bool_signal: pd.Series, length: int = 30) -> pd.Series:
    """Flip rate in last N bars. Higher = choppier."""
    flips = bool_signal.astype(int).diff().abs()
    return flips.rolling(length).sum() / length

# -----------------------------
# GOLD 1m classifier
# -----------------------------
def classify_gold_1m(df: pd.DataFrame) -> pd.DataFrame:
    """
    Input df must have: Open, High, Low, Close (Volume optional).
    Returns df with added columns and 'state' for each bar:
      TRENDING_UP / TRENDING_DOWN / SIDEWAYS / CHOPPY / UNKNOWN
    """

    required = {"Open", "High", "Low", "Close"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {missing}")

    out = df.copy()

    # 1m-friendly lengths
    ATR_LEN = 14
    ADX_LEN = 14

    FAST = 21     # EMA21
    SLOW = 55     # EMA55 (common intraday)
    SLOPE_LEN = 20

    ER_LEN = 25
    WHIP_LEN = 30
    VOL_LOOKBACK = 60  # 1 hour in 1m bars

    # Indicators
    out["ATR"] = atr(out, ATR_LEN)
    d = adx(out, ADX_LEN)
    out["+DI"], out["-DI"], out["ADX"] = d["+DI"], d["-DI"], d["ADX"]

    out["EMA_fast"] = ema(out["Close"], FAST)
    out["EMA_slow"] = ema(out["Close"], SLOW)

    # Normalize slope by ATR (scale-free)
    out["slope_fast"] = linreg_slope(out["EMA_fast"], SLOPE_LEN) / out["ATR"]

    out["ER"] = efficiency_ratio(out["Close"], ER_LEN)
    above_slow = out["Close"] > out["EMA_slow"]
    out["whip"] = whipsaw_rate(above_slow, WHIP_LEN)

    # ATR zscore to detect “chaos spikes”
    atr_mean = out["ATR"].rolling(VOL_LOOKBACK).mean()
    atr_std = out["ATR"].rolling(VOL_LOOKBACK).std()
    out["atr_z"] = (out["ATR"] - atr_mean) / atr_std

    # -----------------------------
    # Rules tuned for GOLD 1m
    # -----------------------------
    # Trend threshold higher to avoid noise
    STRONG_TREND = out["ADX"] >= 30
    WEAK_TREND = out["ADX"] < 18
    MID = (out["ADX"] >= 18) & (out["ADX"] < 30)

    bull_dir = (
        (out["EMA_fast"] > out["EMA_slow"])
        & (out["slope_fast"] > 0.03)
        & (out["+DI"] > out["-DI"])
    )
    bear_dir = (
        (out["EMA_fast"] < out["EMA_slow"])
        & (out["slope_fast"] < -0.03)
        & (out["-DI"] > out["+DI"])
    )

    # Sideways: low ADX + not too whippy + moderate ER + not volatility-spiking
    sideways = (
        WEAK_TREND
        & (out["ER"].between(0.22, 0.40))
        & (out["whip"] <= 0.18)
        & (out["atr_z"] <= 0.8)
    )

    # Choppy: low ADX + (very low ER OR high whipsaw OR volatility spikes)
    choppy = (
        WEAK_TREND
        & (
            (out["ER"] < 0.22)
            | (out["whip"] > 0.18)
            | (out["atr_z"] > 1.0)
        )
    )

    trend_up = STRONG_TREND & bull_dir
    trend_down = STRONG_TREND & bear_dir

    # If ADX is mid, require higher ER and cleaner slope
    mid_up = MID & bull_dir & (out["ER"] >= 0.35)
    mid_down = MID & bear_dir & (out["ER"] >= 0.35)

    state = pd.Series("UNKNOWN", index=out.index, dtype="object")
    state[trend_up | mid_up] = "TRENDING_UP"
    state[trend_down | mid_down] = "TRENDING_DOWN"
    state[sideways] = "SIDEWAYS"
    state[choppy] = "CHOPPY"

    out["state"] = state
    return out

def latest_gold_state(df: pd.DataFrame) -> str:
    return classify_gold_1m(df)["state"].iloc[-1]

# -----------------------------
# Example
# -----------------------------
if __name__ == "__main__":
    df = pd.read_csv("GOLD.csv", parse_dates=["Date"]).set_index("Date")
    out = classify_gold_1m(df)
    print(out[["Close","ADX","ER","whip","atr_z","state"]].tail(30))
    pass
