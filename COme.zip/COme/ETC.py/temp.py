# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt


df = pd.read_csv("EURUSD.csv")
df.head()
df.tail()
df.describe()
df["Return"] = df["Close"].pct_change()
df[df["Close"] > 1.10]
df["MA20"] = df["Close"].rolling(20).mean()

plt.plot(df["Close"])
plt.show()