# -*- coding: utf-8 -*-
"""
Created on Wed Feb 11 02:53:49 2026

@author: Administrator
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd

url = "https://quotes.toscrape.com"
#url = "https://www.forex.com"
r = requests.get(url)
soup = BeautifulSoup(r.text, "html.parser")

quotes = []
for q in soup.find_all("span", class_="text"):
    quotes.append(q.text)

df = pd.DataFrame(quotes, columns=["Quotes"])
df.to_csv("quotes.csv", index=False)
