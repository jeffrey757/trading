# -*- coding: utf-8 -*-
"""
Created on Tue Feb 10 20:10:32 2026

@author: Administrator
"""

import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime

# connect to MT5
mt5.initialize()

# choose symbol and timeframe
symbol = "GOLD"
timeframe = mt5.TIMEFRAME_H1   # 1 hour candles

# date range
start = datetime(2026, 2, 1)
end   = datetime.now()

# download data
rates = mt5.copy_rates_range(symbol, timeframe, start, end)

# convert to dataframe
df = pd.DataFrame(rates)

# convert time format
df['time'] = pd.to_datetime(df['time'], unit='s')

# rename columns (optional but nice)
df.rename(columns={
    'time':'Date',
    'open':'Open',
    'high':'High',
    'low':'Low',
    'close':'Close',
    'tick_volume':'Volume'
}, inplace=True)

# save file
df.to_csv("GOLD.csv", index=False)

print("EURUSD.csv created successfully!")
