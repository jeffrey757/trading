# -*- coding: utf-8 -*-
"""
Created on Tue Feb 10 20:21:07 2026

@author: Administrator
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("EURUSD.csv")
print(df.head())
window=100
account_balance = 10000
risk_per_trade = 0.01

df["Date"] = pd.to_datetime(df["Date"])
df.set_index("Date", inplace=True)
df["Return"] = df["Close"].pct_change()
print(df[["Close","Return"]].head())
df["MA20"] = df["Close"].rolling(window=20).mean()
plt.figure(figsize=(12,6))
plt.plot(df["Close"], label="Close Price")
plt.plot(df["MA20"], label="MA20")
plt.legend()
plt.title("My First Trading Chart")
plt.show()
df["MA50"] = df["Close"].rolling(window=50).mean()
df["Signal"] = 0

df.loc[df["MA20"] > df["MA50"], "Signal"] = 1
df.loc[df["MA20"] < df["MA50"], "Signal"] = -1
df["Strategy_Return"] = df["Signal"].shift(1) * df["Return"]
df["Cumulative_Market"] = (1 + df["Return"]).cumprod()
df["Cumulative_Strategy"] = (1 + df["Strategy_Return"]).cumprod()

print("Final Market Return:", df["Cumulative_Market"].iloc[-1])
print("Final Strategy Return:", df["Cumulative_Strategy"].iloc[-1])
plt.figure(figsize=(12,6))
plt.plot(df["Cumulative_Market"], label="Buy & Hold")
plt.plot(df["Cumulative_Strategy"], label="Strategy")
plt.legend()
plt.title("Strategy vs Market")
plt.show()

stop_loss = -0.02
take_profit = 0.04
position = 0
entry_price = 0
strategy_returns = []

for i in range(len(df)):
    price = df["Close"].iloc[i]
    signal = df["Signal"].iloc[i]

    # If no open trade
    if position == 0:
        if signal == 1:
            position = 1
            entry_price = price
        elif signal == -1:
            position = -1
            entry_price = price
        strategy_returns.append(0)
        continue

    # Calculate trade return
    trade_return = (price - entry_price) / entry_price * position

    # Check SL or TP
    if trade_return <= stop_loss or trade_return >= take_profit:
        strategy_returns.append(trade_return)
        position = 0
        entry_price = 0
    else:
        strategy_returns.append(0)
    profit = account_balance * risk_per_trade * trade_return
    account_balance += profit

df["Strategy_Return"] = strategy_returns
df["MA10"] = df["Close"].rolling(10).mean()
df["MA50"] = df["Close"].rolling(50).mean()

df["RSI"] = 100 - (100 / (1 + df["Close"].pct_change().rolling(14).mean()))

df["Volatility"] = df["Return"].rolling(10).std()
df["Target"] = (df["Close"].shift(-1) > df["Close"]).astype(int)
df.dropna(inplace=True)
features = ["MA10","MA50","RSI","Volatility"]
X = df[features]
y = df["Target"]

split = int(len(df)*0.8)

X_train = X[:split]
X_test = X[split:]
y_train = y[:split]
y_test = y[split:]
from sklearn.ensemble import RandomForestClassifier

model = RandomForestClassifier(n_estimators=100)
model.fit(X_train, y_train)
accuracy = model.score(X_test, y_test)
print("AI Accuracy:", accuracy)

df["AI_Prediction"] = model.predict(X)
df["AI_Return"] = df["AI_Prediction"].shift(1) * df["Return"]
df["AI_Cumulative"] = (1 + df["AI_Return"]).cumprod()
plt.figure(figsize=(12,6))
plt.plot(df["Cumulative_Market"], label="Market")
plt.plot(df["AI_Cumulative"], label="AI Strategy")
plt.legend()
plt.title("AI Trading vs Market")
plt.show()
latest_prediction = df["AI_Prediction"].iloc[-1]

if latest_prediction == 1:
    signal = "BUY"
else:
    signal = "SELL"

file = open("signal.txt", "w")
file.write(signal)
file.close()

print("Signal sent:", signal)
