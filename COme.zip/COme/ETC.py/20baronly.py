# -*- coding: utf-8 -*-
"""
Created on Fri Feb 13 09:58:25 2026

@author: Administrator
"""

# -*- coding: utf-8 -*-
"""
GOLD M1 Market Regime Detection (last 20 CLOSED bars) - Live Console Textbox

Regimes:
- TREND_UP
- TREND_DOWN
- RANGE
- VOLATILE

Logic (simple + robust):
- ADX avg over last 20 closed bars -> trend strength
- EMA fast vs slow + EMA slope -> direction
- ATR short vs ATR long ratio -> volatility regime

Requirements:
  pip install MetaTrader5 pandas numpy

How to use:
  1) Open MetaTrader 5 terminal and log in to your broker
  2) Ensure GOLD is visible in Market Watch
  3) Run this script
"""

import os
import time
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import MetaTrader5 as mt5


# =========================
# CONFIG
# =========================
SYMBOL = "GOLD"                 # change if your broker uses XAUUSD / XAUUSDm etc.
TIMEFRAME = mt5.TIMEFRAME_M1
LOOKBACK = 5                   # last 20 CLOSED bars
WARMUP_BARS = 250               # enough bars for indicators

ADX_PERIOD = 14
ATR_PERIOD = 14
EMA_FAST = 21
EMA_SLOW = 50
ATR_LONG_BARS = 60              # baseline for vol ratio

# thresholds (tune for your broker's GOLD)
ADX_TREND = 25.0
ADX_RANGE = 18.0
VOL_RATIO_HIGH = 1.30           # ATR_short / ATR_long_avg
SLOPE_PTS_MIN = 80.0            # EMA_FAST slope over 20 bars (in points)

REFRESH_SEC = 1.0               # continuous update frequency


# =========================
# INDICATORS
# =========================
def wilder_smooth(series: pd.Series, period: int) -> pd.Series:
    """Wilder smoothing (RMA). Equivalent to EMA with alpha=1/period."""
    return series.ewm(alpha=1/period, adjust=False).mean()

def compute_atr(df: pd.DataFrame, period: int) -> pd.Series:
    high = df["high"]
    low = df["low"]
    close = df["close"]

    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low),
        (high - prev_close).abs(),
        (low - prev_close).abs()
    ], axis=1).max(axis=1)

    atr = wilder_smooth(tr, period)
    return atr

def compute_adx(df: pd.DataFrame, period: int):
    """
    Returns: adx, plus_di, minus_di
    """
    high = df["high"]
    low = df["low"]
    close = df["close"]

    up_move = high.diff()
    down_move = -low.diff()

    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)

    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low),
        (high - prev_close).abs(),
        (low - prev_close).abs()
    ], axis=1).max(axis=1)

    tr_sm = wilder_smooth(tr, period)
    plus_dm_sm = wilder_smooth(pd.Series(plus_dm, index=df.index), period)
    minus_dm_sm = wilder_smooth(pd.Series(minus_dm, index=df.index), period)

    plus_di = 100.0 * (plus_dm_sm / tr_sm.replace(0, np.nan))
    minus_di = 100.0 * (minus_dm_sm / tr_sm.replace(0, np.nan))

    dx = 100.0 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    adx = wilder_smooth(dx, period)

    return adx, plus_di, minus_di

def compute_ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


# =========================
# REGIME CLASSIFICATION
# =========================
def classify_regime(df_closed: pd.DataFrame, point: float) -> dict:
    """
    df_closed: dataframe of CLOSED bars (no current forming bar)
    Must have at least (WARMUP_BARS-1) rows ideally.
    Returns dict with regime + metrics.
    """
    close = df_closed["close"]

    atr = compute_atr(df_closed, ATR_PERIOD)
    adx, plus_di, minus_di = compute_adx(df_closed, ADX_PERIOD)

    ema_fast = compute_ema(close, EMA_FAST)
    ema_slow = compute_ema(close, EMA_SLOW)

    # Use last LOOKBACK closed bars for ADX avg
    adx_avg_lookback = float(adx.tail(LOOKBACK).mean())

    # last closed +DI/-DI
    pdi_last = float(plus_di.iloc[-1])
    mdi_last = float(minus_di.iloc[-1])

    # ATR short: last closed
    atr_short = float(atr.iloc[-1])

    # ATR long avg baseline
    long_n = max(ATR_LONG_BARS, LOOKBACK)
    atr_long_avg = float(atr.tail(long_n).mean())
    vol_ratio = (atr_short / atr_long_avg) if (atr_long_avg and atr_long_avg > 0) else np.nan

    # EMA slope over LOOKBACK bars, in "points"
    ema_fast_last = float(ema_fast.iloc[-1])
    ema_fast_prev = float(ema_fast.iloc[-LOOKBACK])
    slope_pts = (ema_fast_last - ema_fast_prev) / (point if point > 0 else 1.0)

    # EMA spread (fast - slow) in points
    spread_pts = (ema_fast_last - float(ema_slow.iloc[-1])) / (point if point > 0 else 1.0)

    # Regime logic
    if np.isfinite(vol_ratio) and vol_ratio >= VOL_RATIO_HIGH:
        regime = "VOLATILE"
    else:
        trending = (adx_avg_lookback >= ADX_TREND) and (abs(slope_pts) >= SLOPE_PTS_MIN)
        if trending:
            # direction bias
            if (pdi_last > mdi_last) and (spread_pts > 0):
                regime = "TREND_UP"
            elif (mdi_last > pdi_last) and (spread_pts < 0):
                regime = "TREND_DOWN"
            else:
                regime = "TREND_UP" if slope_pts > 0 else "TREND_DOWN"
        else:
            if adx_avg_lookback <= ADX_RANGE:
                regime = "RANGE"
            else:
                # neutral default
                regime = "RANGE"

    return {
        "regime": regime,
        "adx_avg_20": adx_avg_lookback,
        "+di": pdi_last,
        "-di": mdi_last,
        "atr_short": atr_short,
        "atr_long_avg": atr_long_avg,
        "vol_ratio": vol_ratio,
        "ema_slope_pts_20": slope_pts,
        "ema_spread_pts": spread_pts,
        "last_bar_time": df_closed.index[-1],
        "last_close": float(close.iloc[-1]),
    }


# =========================
# MT5 DATA
# =========================
def mt5_init() -> None:
    if not mt5.initialize():
        raise RuntimeError(f"MT5 initialize() failed: {mt5.last_error()}")

def mt5_shutdown() -> None:
    mt5.shutdown()

def get_point(symbol: str) -> float:
    info = mt5.symbol_info(symbol)
    if info is None:
        raise RuntimeError(f"Symbol info not found for {symbol}. Is it in Market Watch?")
    return float(info.point)

def ensure_symbol(symbol: str) -> None:
    if not mt5.symbol_select(symbol, True):
        raise RuntimeError(f"symbol_select({symbol}) failed: {mt5.last_error()}")

def fetch_rates(symbol: str, timeframe, n_bars: int) -> pd.DataFrame:
    rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, n_bars)
    if rates is None or len(rates) == 0:
        raise RuntimeError(f"copy_rates_from_pos returned no data: {mt5.last_error()}")

    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time")
    return df

def get_bid_ask(symbol: str):
    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        return np.nan, np.nan
    return float(tick.bid), float(tick.ask)


# =========================
# CONSOLE UI
# =========================
def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

def render_box(symbol: str, tf_label: str, stats: dict, bid: float, ask: float):
    # simple color tags (no ANSI to keep it universally compatible)
    regime = stats["regime"]
    color_hint = {
        "TREND_UP":   "GREEN",
        "TREND_DOWN": "RED",
        "RANGE":      "BLUE",
        "VOLATILE":   "ORANGE",
        "UNKNOWN":    "GRAY",
    }.get(regime, "GRAY")

    now_local = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    last_time = stats["last_bar_time"].strftime("%Y-%m-%d %H:%M:%S UTC")

    lines = [
        "+" + "-"*70 + "+",
        f"|  {symbol} {tf_label}  Regime Detector (last {LOOKBACK} CLOSED bars)".ljust(71) + "|",
        "+" + "-"*70 + "+",
        f"|  Regime: {regime}   (Color: {color_hint})".ljust(71) + "|",
        f"|  Bid: {bid:.2f}   Ask: {ask:.2f}   LastClose: {stats['last_close']:.2f}".ljust(71) + "|",
        f"|  Last closed bar: {last_time}".ljust(71) + "|",
        "|" + " "*70 + "|",
        f"|  ADX_avg(20): {stats['adx_avg_20']:.2f}   +DI: {stats['+di']:.2f}   -DI: {stats['-di']:.2f}".ljust(71) + "|",
        f"|  ATR_short: {stats['atr_short']:.4f}   ATR_long_avg: {stats['atr_long_avg']:.4f}".ljust(71) + "|",
        f"|  VolRatio: {stats['vol_ratio']:.2f}   (>= {VOL_RATIO_HIGH:.2f} => VOLATILE)".ljust(71) + "|",
        f"|  EMA slope pts(20): {stats['ema_slope_pts_20']:.1f}   Spread pts: {stats['ema_spread_pts']:.1f}".ljust(71) + "|",
        "|" + " "*70 + "|",
        f"|  Updated: {now_local}".ljust(71) + "|",
        "+" + "-"*70 + "+",
    ]
    return "\n".join(lines)


# =========================
# MAIN LOOP
# =========================
def main():
    mt5_init()
    try:
        ensure_symbol(SYMBOL)
        point = get_point(SYMBOL)

        tf_label = "M1"

        last_closed_time = None

        while True:
            # Pull enough data, then drop the *current forming bar* (shift 0)
            df = fetch_rates(SYMBOL, TIMEFRAME, WARMUP_BARS)

            # df includes current forming bar at the end; use only CLOSED bars:
            df_closed = df.iloc[:-1].copy()
            if len(df_closed) < max(LOOKBACK + 5, ATR_LONG_BARS + 5, 100):
                clear_screen()
                print(f"Not enough history yet. Closed bars: {len(df_closed)}")
                time.sleep(REFRESH_SEC)
                continue

            current_closed_time = df_closed.index[-1]

            # Always refresh the textbox continuously,
            # but only recompute stats when a NEW closed bar arrives:
            recompute = (last_closed_time is None) or (current_closed_time != last_closed_time)

            if recompute:
                stats = classify_regime(df_closed, point)
                last_closed_time = current_closed_time
                main.last_stats = stats
            else:
                stats = getattr(main, "last_stats", classify_regime(df_closed, point))

            bid, ask = get_bid_ask(SYMBOL)

            clear_screen()
            print(render_box(SYMBOL, tf_label, stats, bid, ask))

            time.sleep(REFRESH_SEC)

    finally:
        mt5_shutdown()

if __name__ == "__main__":
    main()
