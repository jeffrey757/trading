#pragma once
#include <QString>

bool isAdminValid(const QString& id, const QString& pass);

 
